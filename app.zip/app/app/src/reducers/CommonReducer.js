const initialState = {
    routerNavigation: null,
    currentScreen: null
};
const CommonReducer = (state = initialState, action) => {
    const _s = Object.assign({}, state);
    switch (action.type) {
        case 'ADD_ROUTER_NAVIGATION':
            _s.routerNavigation = action.payload;
            return _s;
        case 'SET_CURRENT_SCREEN':
            _s.currentScreen = action.payload;
            return _s;
        default:
            return _s
    }
}
export default CommonReducer;