const initialState = { services: null };
const ServicesReducer = (state = initialState, action) => {
    return state;
    // switch (action.type) {
    //     case 'SAVE_SERVICE':
    //         return action.payload;
    //     default:
    //         return state
    // }
}
export default ServicesReducer;