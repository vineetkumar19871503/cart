const initialState = {
    activeStream: null,
    callType: 'call',    // call | conf
    callState: null,
    joinState: 'ready',
    roomId: null,
    streams: [],
    remoteUser: null,
    localStream: null
};
const CallReducer = (state = initialState, action) => {
    const _s = Object.assign({}, state);
    switch (action.type) {
        case 'ADD_LOCAL_STREAM':
            _s.localStream = action.payload;
            return _s;
        case 'UPDATE_REMOTE_USER':
            _s.remoteUser = action.payload;
            return _s;
        case 'UPDATE_CALL_STATE':
            _s.callState = action.payload;
            return _s;
        case 'UPDATE_CALL_TYPE':
            _s.callType = action.payload;
            return _s;
        case 'UPDATE_JOIN_STATE':
            _s.joinState = action.payload;
            return _s;
        case 'UPDATE_ROOM_ID':
            _s.roomId = action.payload;
            return _s;
        case 'RESET_STATES':
            return initialState;
        default:
            return _s
    }
}
export default CallReducer;