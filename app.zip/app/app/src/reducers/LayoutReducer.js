const initialState = {
    showPopup: false
};
const LayoutReducer = (state = initialState, action) => {
    const _s = Object.assign({}, state);
    switch (action.type) {
        case 'SHOW_POPUP':
            _s.showPopup = action.payload;
            return _s;
        default:
            return state
    }
}
export default LayoutReducer;