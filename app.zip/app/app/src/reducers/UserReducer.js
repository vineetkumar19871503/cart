const UsersReducer = (state = {}, action) => {
    const _s = Object.assign({}, state);
    switch (action.type) {
        case 'LOGIN':
            action.payload.isLoggedIn = true;
            return Object.assign({}, _s, action.payload);
        case 'LOGOUT':
            const location = Object.assign({}, _s.location);
            return { isLoggedIn: false, location };
        case 'UPDATE_LOCATION':
            _s.location = action.payload;
            return _s;
        case 'CHAT_DATA':
            if (!_s.userChat) {
                _s.userChat = {};
                _s.userChat[action.payload.senderEmail] = [action.payload];
            } else {

                if (typeof _s.userChat[action.payload.senderEmail] == 'undefined') {
                    _s.userChat[action.payload.senderEmail] = [action.payload];
                } else {
                    _s.userChat[action.payload.senderEmail].push(action.payload);
                }
            }
            return _s;
        case 'DELETE_CHAT_DATA':
            if (typeof _s.userChat != 'undefined' && typeof _s.userChat[action.payload] != 'undefined') {
                delete _s.userChat[action.payload];
            }
            return _s;
        case 'HEADER_TITLE':
            _s.headerTitle = action.payload;
            return _s;
        default:
            return state
    }
}
export default UsersReducer;