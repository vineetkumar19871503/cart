const NotificationReducer = (state = null, action) => {
    switch (action.type) {
        case 'ADD_NAV_DATA':
            return action.payload;
        default:
            return state
    }
}
export default NotificationReducer;