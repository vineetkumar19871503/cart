import { combineReducers } from 'redux';
import UsersReducer from './UserReducer';
import ServicesReducer from './ServicesReducer';
import NavigationReducer from './NotificationReducer';
import CallReducer from './CallReducer';
import CommonReducer from './CommonReducer';
import LayoutReducer from './LayoutReducer';
const rootReducer = combineReducers({
    call: CallReducer,
    common: CommonReducer,
    notificationNav: NavigationReducer,
    users: UsersReducer,
    services: ServicesReducer,
    layout: LayoutReducer,
});
export default rootReducer;