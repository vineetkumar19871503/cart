import React from 'react';
import { StyleSheet, Text, View, ScrollView } from 'react-native';
import { createDrawerNavigator } from 'react-navigation';
import SideMenu from '../components/SideMenu/SideMenu';
import Routes from './routes';
export default createDrawerNavigator({
  Routes: {
    screen: Routes
  }
},
  {
    contentComponent: (props) => (
      <SideMenu nav={props.navigation} />
    ),
    drawerWidth: 300,
    // headerMode: 'none',
    initialRouteName: 'Routes',
  },
  {
    // define customComponent here
    contentComponent: props =>
      <ScrollView>
        <DrawerItems {...props} />
        <Text>Your Own Footer Area After</Text>
      </ScrollView>
  });

export const drawerRoutes = {
  'Home': 'Home',
  'UsersListing': 'UsersListing',
  'SendAudio': 'UsersListing',
  'UserDetail': 'UsersListing',
  'UserChat': 'UsersListing',
  'ConferenceList': 'Conference',
  'CreateConference': 'Conference',
  'JoinConference': 'Conference',
  'RecordedVideos':'RecordedVideos',
  'Vmail': 'Vmail',
  'VmailAll': 'Vmail',
  'Policy': 'Policy',
  'About': 'About'
}
