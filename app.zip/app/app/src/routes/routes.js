import React from 'react';
import { AsyncStorage } from 'react-native';
import { createStackNavigator } from 'react-navigation';
import Layout from '../components/Layout';
import Login from '../components/Login';
import { CreateConference, ConferenceList, JoinConference } from '../components/Conference/index.js';
import Home from '../components/Home';
import PlayAudio from '../components/PlayAudio';
import UserDetail from '../components/UserDetail';
import UsersListing from '../components/UsersListing';
import Registration from '../components/Registration';
import Policy from '../components/Policy';
import About from '../components/About';
import Header from '../components/Header';
import RecordedVideos from '../components/RecordedVideos';
import SendAudio from '../components/SendAudio';
import ForgotPassword from '../components/ForgotPassword';
import UserChat from '../components/UserChat';
import { Vmail, VmailAll } from '../components/Vmail/';
const Routes = createStackNavigator({
    Login: {
        screen: Login,
        navigationOptions: { header: null, drawerLockMode: 'locked-closed' }
    },
    UserDetail: { screen: UserDetail, navigationOptions: ({ navigation }) => ({ header: props => <Header nav={navigation} headerTitle={{ title: "User Detail" }} /> }) },
    UsersListing: { screen: UsersListing, navigationOptions: ({ navigation }) => ({ header: props => <Header nav={navigation} headerTitle="Listing" hamburger={true} /> }) },
    ConferenceList: { screen: ConferenceList, navigationOptions: ({ navigation }) => ({ header: props => <Header nav={navigation} headerTitle="Conferences" /> }) },
    CreateConference: { screen: CreateConference, navigationOptions: ({ navigation }) => ({ header: props => <Header nav={navigation} headerTitle="Create Conference" /> }) },
    JoinConference: { screen: JoinConference, navigationOptions: ({ navigation }) => ({ header: props => <Header nav={navigation} headerTitle="Conference" /> }) },
    Home: { screen: Home, navigationOptions: ({ navigation }) => ({ header: props => <Header nav={navigation} headerTitle="Home" /> }) },
    Registration: { screen: Registration, navigationOptions: ({ navigation }) => ({ header: props => <Header nav={navigation} headerTitle="SignUp" /> }) },
    Layout: { screen: Layout },
    PlayAudio: { screen: PlayAudio, navigationOptions: ({ navigation }) => ({ header: props => <Header nav={navigation} headerTitle="Play Audio" /> }) },
    Policy: { screen: Policy, navigationOptions: ({ navigation }) => ({ header: props => <Header nav={navigation} headerTitle="Policy" /> }) },
    About: { screen: About, navigationOptions: ({ navigation }) => ({ header: props => <Header nav={navigation} headerTitle="About" /> }) },
    ForgotPassword: { screen: ForgotPassword, navigationOptions: ({ navigation }) => ({ header: props => <Header nav={navigation} headerTitle="Password Recovery" /> }) },
    RecordedVideos: { screen: RecordedVideos, navigationOptions: ({ navigation }) => ({ header: props => <Header nav={navigation} headerTitle="Recorded Videos" /> }) },
    UserChat: { screen: UserChat, navigationOptions: ({ navigation }) => ({ header: props => <Header nav={navigation} headerTitle={{ title: "User Chat" }} /> }) },
    Vmail: { screen: Vmail, navigationOptions: ({ navigation }) => ({ header: props => <Header nav={navigation} headerTitle={{ title: "V-mail" }} /> }) },
    VmailAll: { screen: VmailAll, navigationOptions: ({ navigation }) => ({ header: props => <Header nav={navigation} headerTitle={{ title: "V-mail" }} /> }) },
    SendAudio: { screen: SendAudio, navigationOptions: ({ navigation }) => ({ header: props => <Header nav={navigation} headerTitle="Send Recorded Audios" /> }) }
},
    {
        navigationOptions: {
            gesturesEnabled: false
        }
    });
Routes.navigationOptions = ({ navigation }) => {
    let drawerLockMode = 'unlocked';
    if (navigation.state.routes[0].routeName === 'Login') {
        drawerLockMode = 'locked-closed';
    }
    return { drawerLockMode };
};
export default Routes;
