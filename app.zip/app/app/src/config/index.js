import { Dimensions } from 'react-native';
const window = Dimensions.get('window');
export default {
  conferenceName: 'twa_conference',
  // socketServerUrl: 'https://oney-webrtc-server.herokuapp.com',
  socketServerUrl: 'https://twaapi.herokuapp.com',
  apiUrl: 'https://twaapi.herokuapp.com/api/v1/',
  mobApiUrl: 'https://twaapi.herokuapp.com/api/v1.0/',
  screenWidth: window.width,
  screenHeight: window.height,
  thumbnailHeight: 60,
  thumbnailWidth: 60,
  useRCTView: true, //debug or not?
  paypal: {
    signature: 'A6Wl-dV.Rl9HlgUaUiaylqrnaEu-ANlEbHObY.WvC3oXXFGVea-S5iLm',
    client_id: 'ATqNPvJlJzb3ip7IcJ_FRTN9E3KP0mV9qsveqfuys8UN6MBJb1bXjZ2L0iVv0sGS-DYnMXWbeQepCxGd',
    secret: 'ENDZV7ZAljN_nLNugHMkHOS4MZoQ-4BZuPhedd5xXRj0cdgo7Z3JXEzX4hhmZHFwHKeJHDqyreJObf-6'
  },
  fcm: {
    'server_key': 'key=AAAACFPbAdU:APA91bEatsZdeIhrZwn893ODKirxfXAsdYJxF-Dw22OGbxgfjYdywsR_Z66GyxBMqt2tkAhXBHvM02ytcVsmpZLiX-PtOJtidh3WLqqvjcCZWzFpN-56Kx7pkf4XENnskO-ljXGjrrYD5We4Ks-EwBHjjavE8sPxCQ',
  },
  video: {
    minWidth: 500,
    minHeight: 300,
    minFrameRate: 30
  }
}