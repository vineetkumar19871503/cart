import React, { Component } from 'react';
import {
  Platform,
  Button,
  StyleSheet,
  Text,
  View,
  Image,
  TextInput,
  TouchableHighlight,
  ScrollView,
  BackHandler,
  Keyboard,
  AsyncStorage,
  Modal,
  Linking,
  TouchableWithoutFeedback
} from 'react-native';
import config from '../config/';
import FilePickerModule from './FilePickerModule';
import Loader from './Loader';
import { updateHeaderTitle, deleteChatData } from '../actions/UserAction';
import axios from 'axios';
import { connect } from 'react-redux';
import { NavigationActions } from 'react-navigation';
import IconMaterial from 'react-native-vector-icons/MaterialCommunityIcons';
// import { DocumentPicker, DocumentPickerUtil } from 'react-native-document-picker';
// import ImagePicker from 'react-native-image-picker';
import NoImageAvailable from '../../image/NoImageAvailable.png';
import RNFetchBlob from 'react-native-fetch-blob';
import Toast from 'react-native-easy-toast';

class UserChat extends React.Component {

  static navigationOptions = {
    title: 'demo',
  };

  constructor(props) {
    super(props);

    this.state = {
      loading: true,
      usersInfo: null,
      chatMsg: [],
      message: null,
      messageFile: null,
      curTime: this._getCurrentTime(),
      socketIO: null,
      imagePreview: false,
      imageUrl: '',
      localStoragePath: RNFetchBlob.fs.dirs.DocumentDir,
      liveImageUrl: 'https://twaapi.herokuapp.com/attachments/'
    }
    // this.props.updateHeaderTitle(this.state.usersInfo.to.fname);
    // this.props.deleteChatData(this.state.usersInfo.to.email);
    this.onFileSelect = this.onFileSelect.bind(this);

  }

  onFileSelect(promise) {
    const self = this;
    promise
      .then((res) => {
        self.setState({ messageFile: res.data[0] }, () => {
          self.sendMessage('file');
        });
      })
      .catch((err) => {
        console.warn("error occurred", err);
        // self._showToast('An unexpected error occurred. Please try again!');
      });

    // DocumentPicker.show({
    //   filetype: [DocumentPickerUtil.allFiles()],
    // }, (error, res) => {
    //   console.warn(error);
    //   this.setState({ messageFile: res });
    //   this.sendMessage('file');
    // });
  }

  async getValueByRoomId(user) {
    const self = this;
    self.setState({
      loading: true
    });
    const _p = this.props;
    const from = {
      _id: _p.user._id,
      type: _p.user.type,
      email: _p.user.email,
      fname: _p.user.fname,
      deviceInfo: _p.user.deviceInfo
    };
    const to = {
      _id: user._id,
      type: user.type,
      email: user.email,
      fname: user.fname,
      deviceInfo: user.deviceInfo
    };
    const userInfo = { from, to };
    if (_p.user.type == 'citizen' && user.type=='leo') {
      self.props.updateHeaderTitle('LEO');
    } else {
      self.props.updateHeaderTitle(userInfo.to.fname);
    }

    self.props.deleteChatData(userInfo.to.email);
    await AsyncStorage.setItem('currentChatUserEmail', userInfo.to.email);

    //update read status
    axios.post(config.mobApiUrl + 'chat_message/updateReadStatus', {
      user_id: userInfo.from._id,
      other_user_id: userInfo.to._id
    })
      .then(function (response) {
      })
      .catch(function (error) {
        // console.log(error)
      });

    _p.services.getValueByRoomId(userInfo, function (roomData) {
      // userInfo.roomData = roomData;
      self.setState({
        loading: false,
        usersInfo: userInfo,
        chatMsg: roomData,
      });
      setTimeout(function () {
        self.refs._scrollView.scrollToEnd({ animated: true });
      }, 500);
    });
  }

  // _openMediaLibrary() {

  //   var options = {
  //     title: 'Select Avatar',
  //     customButtons: [
  //       //{ name: 'iCloud', title: 'Choose Photo from iCloud' },
  //     ],
  //     storageOptions: {
  //       skipBackup: true,
  //       path: 'images'
  //     }
  //   };
  //   ImagePicker.showImagePicker(options, (response) => {
  //     // console.warn('Response = ', response);

  //     if (response.didCancel) {
  //       //'User cancelled image picker'
  //     }
  //     else if (response.error) {
  //       //'ImagePicker Error: ', response.error
  //     }
  //     else if (response.customButton) {
  //       // 'User tapped custom button: ', response.customButton
  //       // DocumentPicker.show({
  //       //   filetype: [DocumentPickerUtil.allFiles()],
  //       // }, (error, res) => {
  //       //   this.setState({ messageFile: res.uri });
  //       //   this.sendMessage('file');
  //       // });
  //     }
  //     else {
  //       let source = { uri: response.uri };
  //       this.setState({ messageFile: source });
  //       this.sendMessage('file');
  //     }
  //   });
  // }

  _getTime(date) {
    return new Date(date).toLocaleTimeString('en-US', { hour12: true });
  }

  _getCurrentTime() {
    return Date();
  }

  sendMessage(fileType) {
    const self = this;
    const _p = this.props;
    const fromId = self.state.usersInfo.from._id;
    const toId = self.state.usersInfo.to._id;
    const localPathObj = {};
    localPathObj[fromId] = null;
    localPathObj[toId] = null;
    const datavalue = {
      "senderId": self.state.usersInfo.from._id,
      "senderEmail": self.state.usersInfo.from.email,
      "receiverId": self.state.usersInfo.to._id,
      "receiverEmail": self.state.usersInfo.to.email,
      "type": fileType,
      "time": self._getCurrentTime(),
      "localPath": localPathObj
    }
    let usersInfoToServer = self.state.usersInfo;
    delete usersInfoToServer.roomData;
    if (fileType === 'text' && self.state.message) {
      datavalue.message = self.state.message;
      self.setState({ message: null });
      self.state.chatMsg.push(datavalue);
      if (self.refs._scrollView) {
        setTimeout(function () {
          self.refs._scrollView.scrollToEnd({ animated: true });
        }, 500);
      }
      _p.services.saveChatMessage(datavalue, usersInfoToServer, function (data) {
      });

    } else if (fileType === 'file' && self.state.messageFile) {

      datavalue.message = self.state.messageFile;
      datavalue['localPath'][fromId] = self.state.messageFile;
      self.state.chatMsg.push(datavalue);
      self.setState({ messageFile: null });

      if (Platform.OS === 'ios') {
        var uri = datavalue.message.uri,
          type = 'mimeType',
          fileName = datavalue.message.uri;
      } else {
        var { uri, type: mimeType, fileName } = datavalue.message;
      }

      const formData = new FormData();
      formData.append('file', { uri, type, name: fileName });
      axios.post(config.apiUrl + 'uploadAttachmentsWithThumb',
        formData, {
          headers: { 'content-type': 'multipart/form-data' }
        }
      )
        .then(function (response) {
          datavalue.message = response.data.fileName;
          // self.state.chatMsg.push(datavalue);
          self.setState({ chatMsg: self.state.chatMsg });
          if (self.refs._scrollView) {
            setTimeout(function () {
              self.refs._scrollView.scrollToEnd({ animated: true });
            }, 500);
          }
          _p.services.saveChatMessage(datavalue, usersInfoToServer, function (data) {
          });
        })
        .catch(function (err) {
          self._showToast('err');
          //console.warn('ERROR OCCURRED =====>', err);
        });
    }
  }
  _showToast(msg, duration = 750) {
    this.refs.toast.show(msg, duration);
  }

  componentDidMount() {
    const self = this;
    this.getValueByRoomId(this.props.navigation.state.params);

    self.keyboardDidShowListener = Keyboard.addListener('keyboardDidShow', self._keyboardDidShow);
    self.keyboardDidHideListener = Keyboard.addListener('keyboardDidHide', self._keyboardDidHide);
    self.setState({ socketIO: this.props.services.getSocket() }, () => self._getChatMessage());
  }

  _getChatMessage() {
    const socket = this.state.socketIO,
      self = this;
    socket.on('getChatMessage', function (datavalue) {
      self.state.chatMsg.push(datavalue.results);
      self.setState({ chatMsg: self.state.chatMsg });
      if (self.refs._scrollView) {
        setTimeout(function () {
          self.refs._scrollView.scrollToEnd({ animated: true });
        }, 500);
      }
    });
  }

  _keyboardDidShow() {
    const self = this;
  }

  _keyboardDidHide() {
    const self = this;
  }

  componentWillMount() {
    const self = this;
    BackHandler.addEventListener('hardwareBackPress', self.backPressed);

  }

  componentWillUnmount() {
    this.refs._scrollView = null;
    AsyncStorage.removeItem('currentChatUserEmail');
    BackHandler.removeEventListener('hardwareBackPress', this.backPressed);
    this.setState({ chatMsg: null });
  }

  backPressed = () => {
    AsyncStorage.removeItem('currentChatUserEmail');
    return;
  }

  // _uodateLocalPath(path, i) {
  //   const self = this;
  //   self.state.chatMsg[i]['localPath'][self.state.usersInfo.from._id] = path;
  //   self.setState({ chatMsg:self.state.chatMsg });
  //   axios.post(config.mobApiUrl + 'chat_message/updateLocalPathAttachment', {
  //     id: self.state.chatMsg[i]._id,
  //     path: path,
  //     user_id:self.state.usersInfo.from._id
  //   })
  //     .then(function (response) {
  //       // console.warn(response)
  //     })
  //     .catch(function (error) {
  //       // console.warn(error)
  //   });
  // }

  _downloadDoc(source) {
    Linking.openURL(source);
  }

  _downloadToLocal(item, isSender = false) {
    const self = this;
    let source = item.message;
    let fileExt = source.split('.').pop();
    if (isSender) {
      //check file exist to local storage from uploaded path


      RNFetchBlob.fs.exists(item['localPath'][self.state.usersInfo.from._id]['uri'])
        .then((existFromUploadpath) => {
          if (existFromUploadpath) {
            self._imageViewModal(item['localPath'][self.state.usersInfo.from._id]);
          } else {
            //check file exist to local storage from downloded path
            RNFetchBlob.fs.exists(self.state.localStoragePath + '/' + item.message)
              .then((exist) => {
                if (exist) {
                  self._imageViewModal(self.state.localStoragePath + '/' + item.message);
                } else {
                  RNFetchBlob
                    .config({
                      fileCache: true,
                      appendExt: fileExt,
                      path: self.state.localStoragePath + '/' + item.message
                    })
                    .fetch('GET', self.state.liveImageUrl + source, {
                      //some headers ..
                    })
                    .then((res) => {
                      self._imageViewModal(self.state.localStoragePath + '/' + item.message);
                      // self._uodateLocalPath(res.path(),i);
                    })
                    .catch((err) => {
                      console.warn('err', err);
                    })
                }
              })
              .catch((err) => {
                console.warn(err);
              })
          }
        })
    } else {
      RNFetchBlob.fs.exists(self.state.localStoragePath + '/' + item.message)
        .then((exist) => {
          if (exist) {
            self._imageViewModal(self.state.localStoragePath + '/' + item.message);
          } else {
            RNFetchBlob
              .config({
                fileCache: true,
                appendExt: fileExt,
                path: self.state.localStoragePath + '/' + item.message
              })
              .fetch('GET', self.state.liveImageUrl + source, {
                //some headers ..
              })
              .then((res) => {
                self._imageViewModal(self.state.localStoragePath + '/' + item.message);
                // self._uodateLocalPath(res.path(),i);
              })
              .catch((err) => {
                console.warn('err', err);
              })
          }
        })
        .catch((err) => {
          console.warn(err);
        })
    }
  }

  _imageViewModal(src) {
    this.setState({ imagePreview: true, imageUrl: src });
  }

  _renderFileIcon(item, i) {
    let source = item.message;
    if (source) {
      let fileExt;
      let thumbUri = this.state.liveImageUrl + 'thumb-' + source;
      if (this.state.usersInfo.from._id == item.senderId) {

        let fileUri = item.localPath[this.state.usersInfo.from._id];
        if (['docx', 'doc', 'xls', 'xlsx'].indexOf(fileExt) > -1) {
          return (<IconMaterial onPress={() => this._downloadDoc(fileUri)} name="file-document" size={40} color="#000" />)
        } else if (fileExt == 'pdf') {
          return (<IconMaterial onPress={() => this._downloadDoc(fileUri)} name="file-pdf" size={40} color="#000" />)
        } else {
          return (
            <TouchableHighlight onPress={() => this._downloadToLocal(item, true)} >
              <Image source={fileUri} defaultSource={{ thumbUri }} style={{ width: 80, height: 120 }} />
            </TouchableHighlight>
          )
        }
      } else {

        fileExt = source.split('.').pop();

        if (['docx', 'doc', 'xls', 'xlsx'].indexOf(fileExt) > -1) {
          return (<IconMaterial onPress={() => this._downloadDoc(fileUri)} name="file-document" size={40} color="#000" />)
        } else if (fileExt == 'pdf') {
          return (<IconMaterial onPress={() => this._downloadDoc(fileUri)} name="file-pdf" size={40} color="#000" />)
        } else {
          return (
            <TouchableHighlight onPress={() => this._downloadToLocal(item)} >
              <Image source={{ uri: thumbUri }} style={{ width: 120, height: 120 }} />
            </TouchableHighlight>
            // <IconMaterial onPress={() => this._downloadToLocal(fileUri, i, item)} name="download" size={20} color="#000" />
          )
        }
      }
    }
  }

  _renderChatMessages() {

    return (
      <ScrollView keyboardShouldPersistTaps="always"
        ref='_scrollView'>
        {this.state.chatMsg.map((item, i) =>
        (this.state.usersInfo ? 
          (
            item.type === 'text' ?

              <View key={i} style={[this.state.usersInfo.from._id == item.senderId ? styles.ownMsg : styles.otherMsg]} >
                <View style={[this.state.usersInfo.from._id == item.senderId ? styles.chatMsg : styles.chatMsg2]}>

                  <Text style={{ padding: 0, color: 'white', fontSize: 13 }}>{item.message}{"\n"}</Text>
                  <Text style={{ fontSize: 8, color: 'white', alignItems: 'flex-end', padding: 0 }}>{this._getTime(item.time)}</Text>
                </View>
              </View>
              :
              <View key={i} style={[this.state.usersInfo.from._id == item.senderId ? styles.ownMsg : styles.otherMsg]} >
                <View style={[this.state.usersInfo.from._id == item.senderId ? styles.chatMsg : styles.chatMsg2]}>
                  {(
                    this._renderFileIcon(item, i)
                  )}
                  <Text style={{ fontSize: 8, color: 'white', alignItems: 'flex-end', padding: 0 }}>{this._getTime(item.time)}</Text>
                </View>
              </View>)
        :''
      )
        )}
      </ScrollView>
    );
    return false;
  }
  render() {
    return (
      <View style={{ flex: 1, flexDirection: 'column', backgroundColor: 'white' }} keyboardShouldPersistTaps="always">
      <Toast ref="toast" />
        <Loader loading={this.state.loading} />
        <TouchableWithoutFeedback onPress={() => this.setState({ imagePreview: false })}>
          <Modal
            animationType="slide"
            transparent={true}
            visible={this.state.imagePreview}
            pageSheet={true}
            onRequestClose={() => { }}
          >
            <View style={{
              flex: 1,
              flexDirection: 'column',
              justifyContent: 'center',
              alignItems: 'center'
            }}>
              <View>
                <IconMaterial style={{ alignSelf: 'flex-end' }} size={30} name='close-circle' onPress={() => this.setState({ imagePreview: false })} />
                {(typeof this.state.imageUrl == 'string' ?
                  <Image source={{ uri: Platform.OS === 'android' ? 'file://' + this.state.imageUrl : '' + this.state.imageUrl }} defaultSource={NoImageAvailable} style={{ alignItems: 'stretch', width: 300, height: 300, borderWidth: 2, borderRadius: 4, borderColor: '#888' }} />
                  :
                  <Image source={this.state.imageUrl} defaultSource={NoImageAvailable} style={{ alignItems: 'stretch', width: 300, height: 300, borderWidth: 2, borderRadius: 4, borderColor: '#888' }} />
                )}
              </View>
            </View>
          </Modal>
        </TouchableWithoutFeedback>
        <View style={{ flex: 0.97, marginBottom: 2 }}>
          {this._renderChatMessages()}
        </View>
        <View style={{ flexDirection: 'row', paddingLeft: 10, paddingRight: 10, height: 50 }}>
          <View
            style={{ flex: 0.80, flexDirection: 'row', backgroundColor: '#f1f1f4', padding: 5, borderWidth: 0, paddingTop: 0, paddingBottom: 0, paddingRight: 10, paddingLeft: 10, borderRadius: 25, borderColor: 'gray' }}
          >
            <TextInput
              style={{ flex: 0.9 }}
              onChangeText={(message) => this.setState({ message })}
              value={this.state.message}
              underlineColorAndroid="transparent"
            />
            <FilePickerModule callback={this.onFileSelect} iconStyle={{ color: '#244576' }} iconSize={25} containerStyle={{ flex: 0.1, marginTop: 10 }} isMultiple={false} isVideo={false} />
          </View>
          <View style={{ flex: 0.04 }}>
          </View>
          <IconMaterial
            style={{ flex: 0.16, backgroundColor: '#244576', color: 'white', borderRadius: 100, textAlign: 'center', paddingTop: 15, alignItems: 'center', justifyContent: 'center' }}
            name="send" size={22}
            onPress={() => this.sendMessage('text')}
          />

        </View>
      </View>
    );
  }
}

var styles = StyleSheet.create({
  ownMsg: {
    flex: 1,
    alignItems: 'flex-end',
    marginLeft: 25,
    marginTop: 5,
    marginRight: 20,
  },
  otherMsg: {
    flex: 1,
    alignItems: 'flex-start',
    marginRight: 25,
    marginTop: 5,
    marginLeft: 20,
  },
  chatMsg: {
    borderRadius: 5,
    paddingTop: 5,
    paddingBottom: 5,
    paddingLeft: 10,
    paddingRight: 10,
    backgroundColor: '#cf9740',
  },
  chatMsg2: {
    borderRadius: 5,
    paddingTop: 5,
    paddingBottom: 5,
    paddingLeft: 10,
    paddingRight: 10,
    backgroundColor: '#244576'
  }
});

const mapStateToProps = (state) => {
  return {
    services: state.services,
    user: state.users
  }
}
const mapDispatchToProps = (dispatch) => {
  return {
    updateHeaderTitle: headerTitle => dispatch(updateHeaderTitle(headerTitle)),
    deleteChatData: toEmail => dispatch(deleteChatData(toEmail))
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(UserChat);