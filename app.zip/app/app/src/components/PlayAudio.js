import React from 'react';
import { Image, Text, TouchableOpacity, View, StyleSheet } from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome';
import Loader from './Loader';
import Sound from 'react-native-sound';
import Toast from 'react-native-easy-toast';

export default class SendAudio extends React.Component {
    constructor(props) {
        super(props);
        const self = this;
        self.state = {
            params: self.props.navigation.state.params,
            sound: null,
            error: null,
            isPlaying: false,
            loading: true
        }
        self.playAudio = self.playAudio.bind(self);
        self.pauseAudio = self.pauseAudio.bind(self);
        Sound.setCategory('Playback', true);
        //if (self.state.params.audioDetail) {
            const sound = new Sound('https://www.android-examples.com/wp-content/uploads/2016/04/Thunder-rumble.mp3', null,
                error => self.soundCallback(error, sound)
            );
        //}
    }

    playAudio() {
        const self = this,
            _st = this.state;
        if (_st.error) {
            this._showToast('Failed to load audio', _st.error);
        } else {
            this.setState({ isPlaying: true });
            _st.sound.play((success) => {
                if (success) {
                    self.setState({ isPlaying: false });
                } else {
                    self.setState();
                    self._showToast('playback failed due to audio decoding errors');
                    self.state.sound.reset();
                }
            });
        }
    }
    pauseAudio() {
        this.state.sound.pause();
        this.setState({ isPlaying: false });

    }

    soundCallback(error, sound) {
        if (error) {
            this._showToast('Failed to load audio');
            this.setState({ error, loading: false })
        } else {
            this.setState({ sound, loading: false });
        }
    }

    _showToast(msg, duration = 750) {
        this.refs.toast.show(msg, duration);
    }

    render() {
        let playText = 'Play',
            icon = 'play',
            playMethod = this.playAudio;
        if (this.state.isPlaying) {
            playText = 'pause';
            icon = 'pause';
            playMethod = this.pauseAudio;
        }
        const isPlaying = this.state.isPlaying;
        return (
            <View>
                <Loader loading={this.state.loading} />
                <Toast ref="toast" />
                <TouchableOpacity onPress={playMethod}>
                    <View style={styles.blockIcon}>
                        <Icon name={icon} size={100} color="#cf9740" />
                        <Text style={{ color: 'white' }}>{playText}</Text>
                    </View>
                </TouchableOpacity>
            </View>
        )
    }
}


const styles = StyleSheet.create({
    blockIcon: {
        backgroundColor: '#244576',
        borderRadius: 180,
        margin: 20,
        marginTop: 50,
        padding: 50,
        paddingRight: 60,
        paddingLeft: 60,
        borderWidth: 3,
        borderColor: '#cf9740',
        alignSelf: 'center',
        shadowColor: '#000',
        shadowOffset: { width: 2, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 5,
        elevation: 10,
    }
});
