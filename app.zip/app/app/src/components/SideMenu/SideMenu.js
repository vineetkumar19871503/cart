import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import React, { Component } from 'react';
import styles from './SideMenu.style';
import drawer, { drawerRoutes } from '../../routes/drawer';
import { NavigationActions, DrawerActions } from 'react-navigation';
import { StyleSheet, Text, View, ScrollView, TouchableOpacity, Image } from 'react-native';
import { setCurrentScreen } from '../../actions/CommonAction';
import profileImage from '../../../image/user-default-profile.png';
import LinearGradient from 'react-native-linear-gradient';
import IconMaterial from 'react-native-vector-icons/MaterialCommunityIcons';

class SideMenu extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      user: null,
      currentScreen: ''
    }
  }

  Capitalize(str, complete = false) {
    if (complete) {
      return str.toUpperCase();
    } else {
      return str.charAt(0).toUpperCase() + str.slice(1);
    }
  }

  navigateToScreen = (screen) => {
    // const navigateAction = NavigationActions.navigate({
    //   routeName: screen
    // });
    // this.props.nav.dispatch(navigateAction);
    this.props.nav.navigate(screen);
  }

  componentWillReceiveProps() {
    const routes = this.props.nav.getChildNavigation('Routes').state.routes;
    let currentScreen = routes[routes.length - 1].routeName;
    if (drawerRoutes[currentScreen]) {
      currentScreen = drawerRoutes[currentScreen];
    }
    if (this.props.commonReducer.currentScreen != currentScreen) {
      this.props.setCurrentScreen(currentScreen);
    }
  }

  render() {
    const _p = this.props,
      currScr = _p.commonReducer.currentScreen,
      isLoggedin = _p.user.isLoggedIn,
      isLEO = _p.user.type !== 'citizen' ? true : false;
    return (
      <LinearGradient colors={['#ffffff', '#eaeaea']} style={styles.linearGradient}>
        <View style={styles.container}>
          <ScrollView keyboardShouldPersistTaps="always">
            {
              isLoggedin === true
                ?
                <LinearGradient colors={['#244576', '#13253f']} style={styles.linearGradient2}>
                  <View style={styles.headerContainer}>
                    <View style={styles.imageContainer}>
                      <Image source={profileImage} style={styles.profileImage} />
                    </View>
                    <Text style={styles.profileName}>
                      {this.Capitalize(_p.user.fname + ' ' + _p.user.lname)}
                    </Text>
                    <Text style={styles.profileEmail}>
                      {_p.user.email}
                    </Text>
                  </View>
                  <Text style={styles.profileType}>
                    {this.Capitalize(_p.user.type, true)}
                  </Text>
                </LinearGradient>
                : null
            }
            <View>
              <View style={styles.navSectionStyle}>
                <Text style={currScr == 'Home' ? styles.activeItemStyle : styles.navItemStyle} onPress={() => this.navigateToScreen('Home')}>
                  <IconMaterial
                    name="home-map-marker"
                    style={currScr == 'Home' ? styles.activeSideIcons : styles.sideIcons}
                    size={20}
                  />&nbsp;&nbsp;
                      Home
                </Text>
                <Text style={currScr == 'UsersListing' ? styles.activeItemStyle : styles.navItemStyle} onPress={() => this.navigateToScreen('UsersListing')}>
                  <IconMaterial
                    name="map-marker-circle"
                    style={currScr == 'UsersListing' ? styles.activeSideIcons : styles.sideIcons}
                    size={20}
                  />&nbsp;&nbsp;
                      Contacts
                </Text>
                {
                  isLEO === true
                    ?
                    <View>
                      <Text style={currScr == 'Conference' ? styles.activeItemStyle : styles.navItemStyle} onPress={() => this.navigateToScreen('JoinConference')}>
                        <IconMaterial
                          name="message-video"
                          style={currScr == 'Conference' ? styles.activeSideIcons : styles.sideIcons}
                          size={20}
                        />&nbsp;&nbsp;
                          Conference
                      </Text>
                    </View>
                    :
                    null
                }
                
                <View>
                  <Text style={currScr == 'Vmail' ? styles.activeItemStyle : styles.navItemStyle} onPress={() => this.navigateToScreen('VmailAll')}>
                    <IconMaterial
                      name="gmail"
                      style={currScr == 'Vmail' ? styles.activeSideIcons : styles.sideIcons}
                      size={20}
                    />&nbsp;&nbsp;
                              V-Mail
                      </Text>
                </View>
                <View>
                  <Text style={currScr == 'RecordedVideos' ? styles.activeItemStyle : styles.navItemStyle} onPress={() => this.navigateToScreen('RecordedVideos')}>
                    <IconMaterial
                      name="video"
                      style={currScr == 'RecordedVideos' ? styles.activeSideIcons : styles.sideIcons}
                      size={20}
                    />&nbsp;&nbsp;
                              One Way Recording
                      </Text>
                </View>
              </View>
              <View style={styles.navSectionStyle2}>
                <Text style={currScr == 'Policy' ? styles.activeItemStyle : styles.navItemStyle} onPress={() => this.navigateToScreen('Policy')}>
                  <IconMaterial
                    name="note-multiple"
                    style={currScr == 'Policy' ? styles.activeSideIcons : styles.sideIcons}
                    size={20}
                  />&nbsp;&nbsp;
                      Privacy and Policy
                </Text>
                <Text style={currScr == 'About' ? styles.activeItemStyle : styles.navItemStyle} onPress={() => this.navigateToScreen('About')}>
                  <IconMaterial
                    name="information"
                    style={currScr == 'About' ? styles.activeSideIcons : styles.sideIcons}
                    size={20}
                  />&nbsp;&nbsp;
                      About
                </Text>
              </View>
            </View>
          </ScrollView>
          <View style={styles.bottomView} >
            <Text style={{ textAlign: 'center' }} >
              TWA@Copyright 2018
            </Text>
          </View>
        </View>
      </LinearGradient>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    user: state.users,
    commonReducer: state.common
  }
}

const mapDispatchToProps = (dispatch) => {
  return {
    setCurrentScreen: screen => dispatch(setCurrentScreen(screen))
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(SideMenu);
