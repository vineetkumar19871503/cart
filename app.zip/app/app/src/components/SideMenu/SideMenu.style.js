export default {
  linearGradient: {
    flex: 1,
    height: '100%'
  },
  linearGradient2: {
    flex: 1,
    paddingTop: 20,
    paddingBottom: 10,
    height: '100%',
    shadowColor: '#000',
    borderColor: '#ddd',
    borderBottomWidth: 1,
    shadowOffset: { width: 4, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 5,
  },
  container: {
    paddingTop: 0,
    flex: 1
  },
  navItemStyle: {
    color: 'black',
    padding: 10,
    fontSize: 15
  },
  activeItemStyle: {
    padding: 10,
    fontSize: 15,
    color: '#cf9740',
    fontWeight: 'bold'
  },
  sideIcons: {
    color: 'grey'
  },
  activeSideIcons: {
    color: '#cf9740'
  },
  navSectionStyle: {
    paddingVertical: 20,
    paddingHorizontal: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#cccccc'
    // backgroundColor: 'lightgrey'
  },
  navSectionStyle2: {
    paddingVertical: 20,
    paddingHorizontal: 10

    // backgroundColor: 'lightgrey'
  },
  sectionHeadingStyle: {
    color: '#fff',
    paddingVertical: 20,
    paddingHorizontal: 10,
  },
  footerContainer: {
    padding: 20,
    // backgroundColor: 'lightgrey'
  },
  headerContainer: {
    alignSelf: 'flex-start',
    justifyContent: 'flex-start',
    paddingLeft: 20
  },
  imageContainer: {
    width: 70,
    height: 70,
    borderRadius: 90,
    backgroundColor: '#fff',
    borderColor: '#cf9740',
    borderWidth: 3,
    alignSelf: 'flex-start',
    justifyContent: 'center'
  },
  profileImage: {
    width: 68,
    height: 68,
    borderRadius: 90,
    alignSelf: 'center',
  },
  profileType: {
    position: 'absolute',
    top: 10,
    alignSelf: 'flex-end',
    backgroundColor: '#cf9740',
    right: 20,
    color: 'white',
    borderRadius: 5,
    paddingTop: 2,
    paddingBottom: 2,
    paddingRight: 10,
    paddingLeft: 10,
    marginTop: 10,
    fontWeight: 'bold',
  },
  profileName: {
    alignSelf: 'flex-start',
    color: '#fff',
    fontWeight: 'bold',
    paddingTop: 10,
  },
  profileEmail: {
    alignSelf: 'flex-start',
    color: '#cf9740',
    fontWeight: 'bold',
  },
  bottomView: {
    width: '100%',
    height: 50,
    backgroundColor: '#dddddd',
    justifyContent: 'center',
    alignItems: 'center',
    position: 'absolute',
    bottom: 0,
    paddingBottom: 10,
    borderTopColor: '#ccc',
    borderTopWidth: 1
  },
};