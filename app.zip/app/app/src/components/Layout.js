import React, { Component } from 'react';
import {
    Alert,
    AppState,
    AsyncStorage,
    NativeAppEventEmitter,
    NativeModules,
    Modal,
    NetInfo,
    PermissionsAndroid,
    Platform,
    StyleSheet,
    Text,
    TouchableHighlight,
    Vibration,
    View,
    PushNotificationIOS
} from 'react-native';
import axios from 'axios';
import { connect } from 'react-redux';
import FullScreenVideo from "./FullScreenVideo.js";
import Home from './Home.js'
import Geocoder from 'react-native-geocoder';
import Geolocation from 'react-native-geolocation-service';
import Icon from 'react-native-vector-icons/FontAwesome';
import Loader from './Loader';
import { RTCView } from 'react-native-webrtc';
import { StackNavigator, StackActions, NavigationActions } from 'react-navigation';
import { showPopup } from '../actions/LayoutAction';
import { addNavigationData } from '../actions/NotificationAction';
import styles from '../../style/app';
import Thumbnails from "./Thumbnails.js";
import Toast from 'react-native-easy-toast';
import { updateLocation, updateChatData } from '../actions/UserAction';
import { addLocalStream, updateRemoteUser, updateCallState, updateJoinState, updateCallType, updateRoomId } from '../actions/CallAction';
import LinearGradient from 'react-native-linear-gradient';
import LoudSpeaker from 'react-native-loud-speaker';
import OpenAppSettings from 'react-native-app-settings';
import Permissions from 'react-native-permissions';
import { Button } from 'react-native-elements';
import { login } from '../actions/UserAction';
import InCallManager from 'react-native-incall-manager';
import { NotificationsAndroid } from 'react-native-notifications';
import PushNotification from 'react-native-push-notification';
import config from '../config/';

class Layout extends Component {
    outgoingCallTimout = null;
    constructor(props) {
        super(props);
        const self = this;
        this.state = {
            appState: AppState.currentState,
            navTransitionEventBound: false,
            activeStreamUrl: null,
            audioMuted: false,
            callbacks: {
                onMakeCall: this.onMakeCall.bind(this),
                participantStreamAdded: this.participantStreamAdded.bind(this)
            },
            callee: null,
            callState: null,
            scRecorder: NativeModules.RecordingManager,
            isFrontCamera: true, // front or rear camera for switching
            incomingCall: false,
            isCallInitiator: false,  // set to true if logged in user initiated the call
            isNetWorking: true,
            joinState: "ready", //ready/joining/joined
            loading: false,
            loaderMsg: null,
            notificationData: null,
            participants: [],
            permissionsGranted: false,
            permissionChecked: false,
            permissionDialogOpen: false,
            requiredPermissions: [],
            isRecording: false,
            selfStream: null,
            socketIO: null,
            ringTone: null,
            streams: [],
            videoMsg: null,
            videoMuted: false,
            appState: AppState.currentState
        };

        // binding methods
        this.acceptCall = this.acceptCall.bind(this);
        this.dropCall = this.dropCall.bind(this);
        this.playRingtone = this.playRingtone.bind(this);
        this.rejectCall = this.rejectCall.bind(this);
        this.toggleCamera = this.toggleCamera.bind(this);
        this._handleAppStateChange = this._handleAppStateChange.bind(this);
        // this.bindNotificationEvents = this.bindNotificationEvents.bind(this);
        this.navigateAfterLogin = this.navigateAfterLogin.bind(this);
        this.showIncomingCall = this.showIncomingCall.bind(this);
        this._pushLocalStream = this._pushLocalStream.bind(this);

        // configure & bind events when push notifications are opened
        PushNotification.configure({
            onNotification: function (notification) {
                const tmpNotification = Object.assign({}, notification);
                if (notification.data) {
                    notification = notification.data;
                    const params = notification.params;
                    if (notification.screen != 'none') {
                        if (self.state.appState == 'active') {
                            if (Platform.OS == 'android' && tmpNotification.data.screen != 'call') {
                                const notificationAndr = tmpNotification.notification;
                                NotificationsAndroid.localNotification({ title: notificationAndr.title, body: notificationAndr.body, extra: tmpNotification.data });
                            }
                        } else {
                            if (notification.screen == 'call') {
                                //if the user is logged in and app is minimized then don't initiate the call again
                                if (!self.state.incomingCall) {
                                    self.setState({ loading: true });
                                    axios.post(config.mobApiUrl + 'users/getById', { 'id': params.from })
                                        .then(async function (fromUser) {
                                            if (fromUser.data.data && fromUser.data.data.length) {
                                                params.from = fromUser.data.data[0];
                                                self.props.updateRemoteUser(params.from);
                                                let localUserInfo = await AsyncStorage.getItem('localUserInfo');
                                                localUserInfo = JSON.parse(localUserInfo);
                                                self.props.login(localUserInfo);
                                                self.props.services.mapUserWithSocketId(localUserInfo);
                                                self.navigateAfterLogin();
                                                setTimeout(function () {
                                                    self._getLocalStream(function () {
                                                        self.showIncomingCall(params);
                                                    });
                                                }, 500);
                                            }
                                        })
                                        .catch(function (error) {
                                            self._showToast('Error occurred while fetching login details!');
                                        });
                                }
                            } else {
                                self.redirectToNotificationUrl(notification.screen, params);
                            }
                            if (Platform.OS == 'ios' && typeof notification.finish == 'function') {
                                notification.finish(PushNotificationIOS.FetchResult.NoData);
                            }
                        }
                    }
                }

            },
            senderID: "35766600149", //sender id from firebase console
            permissions: {
                alert: true,
                badge: true,
                sound: true
            },
        });
    }
    componentWillMount() {
        const self = this;
        self.addNetEvent(function () {
            self._checkPermissions();
        });
        AppState.addEventListener('change', this._handleAppStateChange);
        //const ringtoneFile = Platform.OS === 'android' ? require('../assets/android.mp3') : require('../assets/iphone.mp3');
        // NativeAppEventEmitter.addListener('onVolumeButtonPressed', data => {
        //     if ((data == 'VOLUME_UP' || data == 'VOLUME_DOWN') && self.state.incomingCall) {
        //         self.stopRingtone();
        //     }
        // });
        // NativeAppEventEmitter.addListener('hardwareButtonPressed', data => {
        //     console.log(self.props.navigation);
        // });
    }

    componentWillUnmount() {
        // removing event listeners
        AppState.removeEventListener('change', this._handleAppStateChange);
        NetInfo.isConnected.removeEventListener('connectionChange');
        // NativeAppEventEmitter.removeListener('hardwareButtonPressed');
        if (this.props.common.routerNavigation && this.state.navTransitionEventBound) {
            this.props.common.routerNavigation.removeListener('willFocus');
        }
        navigator.geolocation.clearWatch(this.watchID);
        this._resetCall();
    }

    componentDidMount() {
        const self = this;
        self.props.services.bindComponentCallbacksToServices(this.state.callbacks);
        self.setState({ socketIO: this.props.services.getSocket() }, () => {
            //binding socket & it's notification events
            self.bindSocketEvents();
            // self.bindNotificationEvents();
            // redirect to screen according to notification url
            if (Platform.OS == 'android') {
                NotificationsAndroid.setNotificationOpenedListener((notification) => {
                    const data = notification.getData();
                    if (data.extra) {
                        const _e = data.extra;
                        _e.params ? self.redirectToNotificationUrl(_e.screen, _e.params) : self.redirectToNotificationUrl(_e.screen);
                    }
                });
            }
        });
    }

    addNetEvent(cb) {
        const self = this;
        NetInfo.isConnected.addEventListener('connectionChange', isNetWorking => {
            this.setState({ isNetWorking }, () => {
                if (typeof cb == 'function') {
                    cb();
                }
            });
        });
    }

    _handleAppStateChange(nextAppState) {
        if (this.state.appState.match(/background/) && nextAppState === 'active') {
            //' check permissions when app comes to the foreground'
            //if (Platform.OS == 'ios') {
            this._checkPermissions();
            //}
        }
        this.setState({ appState: nextAppState });
    }

    navigateAfterLogin() {
        const resetAction = StackActions.reset({
            index: 0,
            actions: [NavigationActions.navigate({ routeName: 'UsersListing' })],
        });
        this.props.common.routerNavigation.dispatch(resetAction);
    }

    // _showLocalNotification(title, body, extra = null) {
    //     if (Platform.OS == 'android') {
    //         NotificationsAndroid.localNotification({ title, body, extra });
    //     }
    // }

    // bindNotificationEvents() {
    //     const socket = this.state.socketIO,
    //         self = this;
    //     if (Platform.OS == 'android') {
    //         socket.on('getChatMessage', async function (datavalue) {
    //             const currentChatUserEmail = await AsyncStorage.getItem('currentChatUserEmail'),
    //                 title = datavalue.results.senderEmail,
    //                 body = datavalue.results.message;
    //             if (typeof currentChatUserEmail == 'undefined' || currentChatUserEmail == null) {
    //                 self._showLocalNotification(title, body, { screen: 'UserChat', params: datavalue.usersInfoToServer.from });
    //             }
    //             else if (currentChatUserEmail !== null && self.state.appState.match(/inactive|background/)) {
    //                 self._showLocalNotification(title, body, { screen: 'UserChat', params: datavalue.usersInfoToServer.from });
    //             }
    //             else if (currentChatUserEmail !== null && currentChatUserEmail != datavalue.results.senderEmail) {
    //                 self._showLocalNotification(title, body, { screen: 'UserChat', params: datavalue.usersInfoToServer.from });
    //             }
    //             self.props.updateChatData(datavalue.results);
    //         });
    //     }
    //     socket.on('vmail_received', function (data) {
    //         self._showLocalNotification(data.sender_name + ' sent you a V-Mail', data.message.substring(0, 50) + '...', { screen: 'Vmail', params: data.sender });
    //     });

    //     socket.on('audio_received', function (data) {
    //         const notificationMsg = data.sender.name + ' sent you an audio',
    //             notificationData = {
    //                 screen: 'PlayAudio',
    //                 params: data
    //             };
    //         self._showLocalNotification(notificationMsg, 'Tap to view', notificationData);
    //         Alert.alert(
    //             notificationMsg,
    //             'Do you want to play?',
    //             [
    //                 { text: 'OK', onPress: () => self.redirectToNotificationUrl('PlayAudio', notificationData) },
    //                 { text: 'Cancel', onPress: () => null, style: 'cancel' }
    //             ],
    //             { cancelable: false }
    //         )
    //     });
    // }

    bindSocketEvents() {
        const socket = this.state.socketIO,
            self = this;

        // bind events when socket is connected
        socket.on('connect', function (data) {
            socket.on('incoming_call', function (data) {
                const _p = self.props;
                _p.updateRemoteUser(data.from);
                if (_p.call.callState !== null) {
                    // if user is busy on other call then don't get incoming call and inform the caller
                    socket.emit('line_busy', { 'to': _p.call.remoteUser, 'from': _p.user });
                } else {
                    self._getLocalStream(function () {
                        self.showIncomingCall(data);
                    });
                }
            });

            socket.on('disconnect', reason => {
                const u = self.props.user;
                if (u.isLoggedIn == true) {
                    socket.connect();
                    self.props.services.mapUserWithSocketId(u);
                }
            });

            // when any participant joins a room
            socket.on("on_participant_joined", function (roomId, participant) {
                clearTimeout(self.outgoingCallTimout);
                self._addParticipant(participant);
            });
            socket.on('participant_dropped_call', function (droppedBy, autoDropped) {
                self.onParticipantDroppedCall(droppedBy, autoDropped);
            });
            socket.on('participant_left', function (data) {
                // todo: remove participant from participants array
                self.onParticipantLeft(data);
            });
            socket.on('participant_rejected_call', function (rejecter) {
                self.onParticipantRejectedCall(rejecter);
            });
            socket.on('participant_busy', function (data) {
                self.onParticipantBusy(data);
            });
            socket.on('not_reachable', function () {
                self.onParticipantNotReachable();
            });
        });
    }

    onMakeCall() {
        // when user makes call then unmute audio+video
        const self = this;
        self._getLocalStream(function () {
            self._muteMedia(false);
            self.startOutgoingRing();
            self.startRecording();
            self.setState({ isCallInitiator: true }, () => {
                self.outgoingCallTimout = setTimeout(() => {
                    self.dropCall(true);
                }, 60000);
            });
        });
    }

    dropCall(isAutoDropped) {
        const params = { 'dropped_by': this.props.user, 'room_id': this.props.call.roomId };
        // if the remote user didn't pick the call : 1. when the time exceeds or 2. when user himself drops the call after making the call
        if (isAutoDropped === true || this.state.streams.length < 2 && this.state.isCallInitiator) {
            params.is_autodropped = true;
        }
        if (this.outgoingCallTimout) {
            clearTimeout(this.outgoingCallTimout);
        }
        if (this.props.call.callType == 'call') {
            params.drop_inform_to = this.props.call.remoteUser;
        }
        const remoteSocketId = this._getSocketIdOfParticipant(this.props.call.remoteUser);
        this.props.services.leaveRoom(this.props.call.roomId, this.props.user.email);
        this.killStream(remoteSocketId);
        this.setState({ activeStreamUrl: this.state.selfStream.toURL() });
        this.props.services.dropCall(params);
        this._resetCall();
    }

    onParticipantDroppedCall(droppedBy, autoDropped) {
        // leave room if participant dropped the call in case of one-to-one calling
        if (!autoDropped) {
            this._showToast(droppedBy.name + ' dropped the call');
        }
        const _p = this.props;
        if (_p.call.callType == 'call') {
            _p.services.leaveRoom(_p.call.roomId, _p.user.email);
            this._resetCall();
        }
        this.killStream(droppedBy.socketId);
    }

    onParticipantLeft(data) {
        this._removeParticipant(data);
        this.killStream(data.socketId);
        this.props.services.leaveRoom();
    }

    onParticipantRejectedCall(rejecter) {
        this._resetCall();
        this._showToast(rejecter.name + ' rejected your call');
        // leave the room
        this.props.services.leaveRoom(this.props.call.roomId, this.props.user.email);
    }

    onParticipantBusy() {
        this._showToast('Line is busy of ' + this.props.call.remoteUser.name);
        this._resetCall();
    }

    onParticipantNotReachable() {
        this._resetCall();
        this._showToast('Not reachable');
        // leave the room
        this.props.services.leaveRoom(this.props.call.roomId, this.props.user.email);
    }

    participantStreamAdded(socketId, stream) {
        const self = this;
        let streams = this.state.streams,
            newState = {},
            _sUrl = stream.toURL();
        // if its a one-to-one call and the first participant joins then show him on full screen
        if (streams.length == 1 && this.props.call.callType == 'call') {
            newState.activeStreamUrl = _sUrl;
        }
        // filter existing stream by socket id
        streams = streams.filter(function (str) {
            return str.socketId != socketId;
        });
        streams.push({
            socketId,
            streamObj: stream,
            url: _sUrl
        });
        newState.streams = streams;
        this.setState(newState);
        setTimeout(function () {
            self._loudSpeaker(true);
            self.startRecording();
            self.stopOutgoingRing();
        }, 100);
    }

    playRingtone() {
        InCallManager.startRingtone('_BUNDLE_');
    }

    showIncomingCall(data) {
        const self = this,
            _p = self.props
        if (data) {
            self.playRingtone();
            self._addParticipant(data.from);
            _p.updateRoomId(data.room_id);
            _p.updateCallType(data.call_type);
            self._muteUnmuteVideo(false);
            self.setState({ 'loading': false, 'incomingCall': true, isCallInitiator: false });
        }
    }

    stopRingtone() {
        InCallManager.stopRingtone();
    }

    startOutgoingRing() {
        InCallManager.start({ media: 'audio', ringback: '_DTMF_' });
    }

    stopOutgoingRing() {
        InCallManager.stopRingback();
    }

    async acceptCall() {
        const self = this;
        self.stopRingtone();
        InCallManager.start();
        self._muteMedia(false);
        // join the room
        self.props.services.join(self.props.call.roomId, self.props.user.email, function (participants) {
            self.props.updateJoinState('joined');
            self.props.updateCallState('picked');
        });
        Vibration.cancel();
        this.setState({ 'incomingCall': false });
    }
    rejectCall() {
        this._resetCall();
        this.props.services.rejectCall(this.props.user, this.props.call.remoteUser);
    }
    toggleCamera() {
        const self = this,
            _st = self.state,
            facingMode = !_st.isFrontCamera;
        self.props.services.toggleCamera(facingMode, function (stream) {
            // remove existing stream
            const newStreams = _st.streams.filter(function (str) {
                if (str.socketId != _st.socketIO.id) {
                    return str;
                } _showToast
            })
            const _sU = stream.toURL();
            newStreams.push({
                socketId: _st.socketIO.id,
                streamObj: stream,
                url: _sU
            });
            self.setState({
                isFrontCamera: facingMode,
                selfStream: stream,
                activeStreamUrl: _sU,
                streams: newStreams
            });
        });
    }

    renderCallOptions() {
        const self = this;
        if (this.state.incomingCall) {
            return (
                <Modal
                    animationType="slide"
                    transparent={false}
                    visible={true}
                    onRequestClose={() => {
                        self._showToast('Line is busy of ' + this.props.call.remoteUser.name);
                    }}>
                    <View style={{
                        flex: 1,
                        backgroundColor: 'black',
                        flexDirection: 'column',
                        justifyContent: 'center',
                        alignItems: 'center'
                    }}><Icon name='phone' size={90} color="#fff" />
                        {/* <Text style={{ color: 'white', flexDirection: 'row', fontSize: 30 }}>{this.props.call.remoteUser.name}</Text> */}
                        <Text style={{ color: 'white', flexDirection: 'row', paddingBottom: 150 }}>{this.props.call.remoteUser.name} calling you...</Text>
                        <View style={{ flexDirection: 'row' }}>
                            <TouchableHighlight onPress={this.acceptCall} style={btnStyles.accept}>
                                <Text style={{ color: '#fff', fontSize: 20 }}>Accept</Text>
                            </TouchableHighlight>
                            <TouchableHighlight onPress={this.rejectCall} style={btnStyles.reject}>
                                <Text style={{ color: '#fff', fontSize: 20 }}>Reject</Text>
                            </TouchableHighlight>
                        </View>
                    </View>
                </Modal>
            );
        }
        return null;
    }

    renderToast() {
        return <Toast ref="toast" />;
    }

    // record screen once the call is connected
    startRecording() {
        if (Platform.OS == 'android') {
            if (!this.state.isRecording) {
                const recordingName = this._getRecordingName();
                this.state.scRecorder.startRecording(recordingName);
                this.setState({ isRecording: true });
            }
        }
    }

    // stop the recording when call ends
    stopRecording() {
        if (Platform.OS == 'android') {
            if (this.state.isRecording) {
                this.state.scRecorder.stopRecording();
                this.setState({ isRecording: false });
            }
        }
    }

    killStream(socketId = null) {
        const streams = this.state.streams;
        for (let str = 0; str < streams.length; str++) {
            if (streams[str].socketId == socketId) {
                this.props.services.destroyPeerConnection(socketId, streams[str].streamObj);
                streams.splice(str, 1);
                break;
            }
        }
        this.setState({ streams });
    }

    redirectToNotificationUrl(screen, params) {
        const _st = this.state,
            _p = this.props,
            pNavigate = this.props.common.routerNavigation.navigate;
        if (typeof screen == 'string' && screen.trim().length) {
            if (_p.user.isLoggedIn === true) {
                _p.addNavigationData(null);
                params ? pNavigate(screen, params) : pNavigate(screen);
            } else {
                params ? _p.addNavigationData({ screen, params }) : _p.addNavigationData({ screen });
            }
        }
    }

    /**
     * some private methods
     */
    _addParticipant(participant) {
        const participants = this.state.participants;
        participants.push(participant);
        this.setState({ participants });
    }

    _removeParticipant(participant) {
        const sP = this.state.participants;
        const participants = sP.filter(function (p) {
            return p.socketId != participant.socketId;
        });
        this.setState({ participants });
    }

    _checkPermissions() {
        const self = this;
        if (!self.state.isNetWorking) {
            return;
        }
        self.setState({ permissionChecked: false, permissionsGranted: false });
        if (Platform.OS === 'android') {
            const granted = PermissionsAndroid.requestMultiple([
                PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
                PermissionsAndroid.PERMISSIONS.WRITE_EXTERNAL_STORAGE,
                PermissionsAndroid.PERMISSIONS.CAMERA,
                PermissionsAndroid.PERMISSIONS.RECORD_AUDIO
            ])
                .then(function (res) {
                    self.setState({ permissionChecked: true });
                    const locPerm = 'android.permission.ACCESS_FINE_LOCATION',
                        extStor = 'android.permission.WRITE_EXTERNAL_STORAGE',
                        aud = 'android.permission.RECORD_AUDIO',
                        cam = 'android.permission.CAMERA';
                    if (res[locPerm] == 'denied' || res[extStor] == 'denied' || res[aud] == 'denied' || res[cam] == 'denied') {
                        self.setState({ permissionsGranted: false });
                    } else {
                        self.setState({ permissionsGranted: true }, function () {
                            // self._getLocalStream();
                            self._getGeoLocation();
                        });
                    }
                })
                .catch(function (err) {
                    self.setState({ permissionChecked: true });
                });
        } else {
            const permissionsGranted = true,
                requiredPermissions = [];
            Permissions.request('notification').then(response => {
                if (response != 'authorized') {
                    if (permissionsGranted) {
                        permissionsGranted = false;
                    }
                    requiredPermissions.push('Push Notificaion');
                }
                Permissions.request('location', { type: 'always' }).then(response => {
                    if (response != 'authorized') {
                        if (permissionsGranted) {
                            permissionsGranted = false;
                        }
                        requiredPermissions.push('GPS');
                    }
                    Permissions.request('microphone').then(response => {
                        if (response != 'authorized') {
                            if (permissionsGranted) {
                                permissionsGranted = false;
                            }
                            requiredPermissions.push('Microphone');
                        }
                        Permissions.request('camera').then(response => {
                            if (response != 'authorized') {
                                if (permissionsGranted) {
                                    permissionsGranted = false;
                                }
                                requiredPermissions.push('Camera');
                            }
                            self.setState({ permissionsGranted, requiredPermissions });
                            if (!permissionsGranted) {
                                self._askToOpenIOSSettings();
                            } else {
                                self._getGeoLocation();
                                // self._getLocalStream();
                            }
                        });
                    });
                });
            });
        }
    }

    _askToOpenIOSSettings() {
        const self = this;
        if (this.state.permissionDialogOpen) {
            return;
        }
        const reqPerm = self.state.requiredPermissions,
            permCount = reqPerm.length,
            lastPerm = permCount > 1 ? reqPerm.splice(-1, 1) : reqPerm;
        let permStr = reqPerm.join(', ');
        permStr = permCount > 1 ? permStr + ' and ' + lastPerm + '" permissions' : permStr + '" permission';
        permStr = 'Please make sure that you have allowed "' + permStr;
        self.setState({ permissionDialogOpen: true });
        Alert.alert(
            'Permissions Required',
            permStr,
            [
                { text: 'Settings', onPress: () => self._openSettings() }
            ],
            { cancelable: false }
        );
    }

    _openSettings() {
        this.setState({ permissionDialogOpen: false });
        OpenAppSettings.open();
    }

    _getSocketIdOfParticipant(participant) {
        let socketId = null,
            _p = this.state.participants;
        for (let p = 0; p < _p.length; p++) {
            if (_p[p].email == participant.email) {
                socketId = _p[p].socketId;
                break;
            }
        }
        return socketId;
    }

    _getGeoLocation(cb) {
        const self = this;
        if (!self.state.permissionsGranted) {
            return;
        }
        if (!self.props.user.location && !self.props.user.isLoggedIn) {
            self.setState({ loading: true, loaderMsg: 'Getting your location...' });
        }
        Geolocation.getCurrentPosition(
            function (position) {
                Geocoder.geocodePosition({
                    lat: position.coords.latitude,
                    lng: position.coords.longitude
                })
                    .then(res => {
                        self.setState({ loading: false });
                        self.props.updateLocation(res[0]);
                    })
                    .catch(err => {
                        self.setState({ loading: true, loaderMsg: 'Getting your location...' });
                        setTimeout(() => {
                            self.setState({ loading: false, loaderMsg: null });
                            self._getGeoLocation();
                        }, 1500)
                    })
            },
            (error) => {
                // const os = Platform.OS,
                //     alertMsg = os == 'android' ? 'Please allow TWA app to turn on GPS' : 'TWA application requires your location. Please make sure that GPS is turned on',
                //     secondarBtn = os == 'android' ? 'OK' : 'Settings';
                // Alert.alert(
                //     'Location Required',
                //     alertMsg,
                //     [
                //         { text: 'Cancel', onPress: () => self._turnOnGPS(), style: 'cancel' },
                //         { text: secondarBtn, onPress: () => self._turnOnGPS() },
                //     ],
                //     { cancelable: false }
                // )
            },
            { enableHighAccuracy: true, timeout: 15000, maximumAge: 10000 }
        );
    }

    // _turnOnGPS() {
    //     if (Platform.OS == 'android') {
    //         this._getGeoLocation();
    //     } else {
    //         // if ios then navigate user to settings screen
    //         OpenAppSettings.open()
    //     }
    // }

    _getLocalStream(cb) {
        const self = this,
            _st = self.state,
            reduxStream = self.props.call.localStream;
        if (!_st.permissionsGranted) {
            return;
        }
        if (reduxStream) {
            self._pushLocalStream(reduxStream);
        } else {
            // getting the client's steam and setting it into state
            self.props.services.getLocalStream(self.state.isFrontCamera, (stream) => {
                self.props.addLocalStream(stream);
                self._pushLocalStream(stream);
            });
        }
        if (typeof cb == 'function') {
            cb();
        }
    }

    _pushLocalStream(stream) {
        const _st = this.state,
            _sU = stream.toURL(),
            streams = [{
                socketId: _st.socketIO.id,
                streamObj: stream,
                url: _sU
            }];
        this.setState({
            selfStream: stream,
            activeStreamUrl: _sU,
            streams: streams
        });
    }

    _getRecordingName() {
        let name = (this.props.user.name + '-' + this.props.call.remoteUser.name).replace(/ +/g, "").toLowerCase();
        const d = new Date(),
            dtTm = d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate() + '_' + d.getHours() + '-' + d.getMinutes() + '-' + d.getSeconds();
        name += '_' + dtTm;
        return name;
    }

    _muteUnmuteAudio(mute = true) {
        const _ss = this.state.selfStream;
        if (_ss) {
            this.setState({ 'audioMuted': mute });
            _ss.getAudioTracks()[0].enabled = mute ? false : true;
        }
    }
    _muteUnmuteVideo(mute = true) {
        const _ss = this.state.selfStream;
        if (_ss) {
            let msg = mute ? 'Video is muted...' : null;
            this.setState({ 'videoMuted': mute, 'videoMsg': msg });
            _ss.getVideoTracks()[0].enabled = mute ? false : true;
        }
    }

    // mute both audio and video
    _muteMedia(mute = true) {
        this._muteUnmuteAudio(mute);
        this._muteUnmuteVideo(mute);
    }

    _renderInternetModal() {
        return (
            <Modal
                animationType="slide"
                transparent={false}
                visible={!this.state.isNetWorking}
                onRequestClose={() => {
                    //alert('Modal has been closed.');
                }}
            >
                <LinearGradient colors={['#244576', '#13253f']} style={{ flex: 1, padding: 30, justifyContent: 'center', alignItems: 'center' }}>
                    <Text style={{ color: 'white', fontSize: 25, marginBottom: 20 }}>Oooopss!</Text>
                    <Text style={{ color: 'white', fontSize: 16, textAlign: 'center' }}>{'No inernet connection found.'}</Text>
                    {/* <Text style={{ color: 'white', fontSize:16 }}>Please check your network connectivity.</Text> */}
                </LinearGradient>
            </Modal>
        );
    }

    _renderPermissionsModal() {
        const showModal = this.state.permissionChecked && !this.state.permissionsGranted;
        return (
            <Modal
                animationType="slide"
                transparent={false}
                visible={showModal}
                onRequestClose={() => {
                    //alert('Modal has been closed.');
                }}
            >
                <View style={{
                    flex: 1,
                    backgroundColor: 'black',
                    flexDirection: 'column',
                    justifyContent: 'center',
                    alignItems: 'center'
                }}>
                    <Text style={{ color: 'white', flexDirection: 'row', paddingBottom: 50 }}>Please grant all the required permissions to proceed.</Text>
                    <Text onPress={() => this._checkPermissions()} style={{ color: 'white' }}>click here</Text>
                </View>
            </Modal>
        );
    }

    _resetCall() {
        //this.killStream(this.state.socketIO.id);
        this.stopRingtone();
        InCallManager.stop();
        this.stopOutgoingRing();
        this.stopRecording();
        this.props.updateCallState(null);
        this.props.updateJoinState('ready');
        this.setState({
            'streams': [],
            'incomingCall': false,
            'activeStreamUrl': this.state.selfStream.toURL(),
            'isCallInitiator': false
        });
        Vibration.cancel();
        this._loudSpeaker(false);
    }

    _showToast(msg, duration = 750) {
        this.refs.toast.show(msg, duration);
    }

    _loudSpeaker(status = true) {
        InCallManager.setForceSpeakerphoneOn(status);
        // LoudSpeaker.open(status);
    }

    render() {
        const callState = this.props.call.callState,
            isCalling = callState == "calling",
            callPicked = callState == "picked";
        if (this.state.incomingCall) {
            Vibration.vibrate([0, 500, 500], true);
        }
        return (
            <View style={{ flex: 1 }} >
                <Loader loading={this.state.loading} message={this.state.loaderMsg} />
                {this._renderInternetModal()}
                {this._renderPermissionsModal()}
                {this.renderCallOptions()}
                {this.renderToast()}
                {isCalling || callPicked
                    ?
                    <View style={{ backgroundColor: '#000' }}>
                        <Text style={styles.videoMsg}>{this.state.videoMsg}</Text>
                        <FullScreenVideo streamURL={this.state.activeStreamUrl} />
                        <View style={styles.callOptions}>
                            {/* <Icon
                                style={styles.callOptIcon}
                                onPress={this.toggleCamera}
                                name='camera'
                                size={28}
                                color="#fff" /> */}
                            <Icon
                                style={styles.callOptIcon}
                                onPress={() => this._muteUnmuteAudio(!this.state.audioMuted)}
                                name={this.state.audioMuted ? 'microphone-slash' : 'microphone'}
                                size={28}
                                color="#fff" />
                            <TouchableHighlight
                                style={styles.dropButton}
                                onPress={this.dropCall} >
                                <Icon
                                    name="phone"
                                    size={25}
                                    color="#fff" />
                            </TouchableHighlight>
                            <Icon
                                style={styles.callOptIcon}
                                onPress={() => this._muteUnmuteVideo(!this.state.videoMuted)}
                                name={this.state.videoMuted ? 'video-camera' : 'video-camera'}
                                size={28}
                                color="#fff" />
                        </View>
                        <Thumbnails streams={this.state.streams}
                            setActive={(streamUrl) => this.setState({ 'activeStreamUrl': streamUrl })}
                            activeStreamUrl={this.state.activeStreamUrl} />
                    </View>
                    :
                    null
                }
                {this.props.children}
            </View>
        )
    }
}

const mapStateToProps = (state) => {
    return {
        call: state.call,
        common: state.common,
        services: state.services,
        user: state.users
    };
}

const mapDispatchToProps = (dispatch) => {
    return {
        addLocalStream: stream => dispatch(addLocalStream(stream)),
        addNavigationData: data => dispatch(addNavigationData(data)),
        login: (userData) => dispatch(login(userData)),
        showPopup: (isShowPopup) => dispatch(showPopup(isShowPopup)),
        updateRemoteUser: (remoteUser) => dispatch(updateRemoteUser(remoteUser)),
        updateCallState: (callState) => dispatch(updateCallState(callState)),
        updateJoinState: (joinState) => dispatch(updateJoinState(updateJoinState)),
        updateCallType: (type) => dispatch(updateCallType(type)),
        updateRoomId: (roomId) => dispatch(updateRoomId(roomId)),
        updateLocation: location => dispatch(updateLocation(location)),
        updateChatData: chatData => dispatch(updateChatData(chatData))
    }
}

const btnStyles = StyleSheet.create({
    accept: {
        padding: 20,
        marginRight: 5,
        backgroundColor: 'green'
    },
    reject: {
        padding: 20,
        marginRight: 5,
        backgroundColor: 'red'
    }
});

export default connect(mapStateToProps, mapDispatchToProps)(Layout);