import React from 'react';
import { connect } from 'react-redux';
import axios from 'axios';
// import Autocomplete from 'react-native-autocomplete-input';
import FilePickerModule from './FilePickerModule';
import Loader from './Loader';
import {
    Button,
    Image,
    Platform,
    Text,
    TouchableOpacity,
    View,
    ScrollView,
    StyleSheet
} from 'react-native';
import config from '../config/';
import IconMaterial from 'react-native-vector-icons/MaterialCommunityIcons';
import Toast from 'react-native-easy-toast';
import { updateHeaderTitle } from '../actions/UserAction';
class Vmail extends React.Component {
    pickerBtn = null;
    constructor(props) {
        super(props);
        this.state = {
            videos: [],
            loading: false
        };
        this.onStopRecording = this.onStopRecording.bind(this);
    }

    componentDidMount() {
        this.fetchVideos();
    }

    fetchVideos() {
        const self = this;
        self.setState({ loading: true });
        axios.get(config.mobApiUrl + 'video_recording/list', {
            user_id: self.props.user._id
        })
            .then(function (response) {
                self.setState({ loading: false, videos: response.data.data });
            })
            .catch(function (error) {
                self.setState({ loading: false });
            });
    }

    onStopRecording(promise) {
        const self = this;
        promise
            .then((video) => {
                if (video.data && video.data.length) {
                    const { uri, type: mimeType, fileName } = video.data[0],
                        formData = new FormData();
                    formData.append('file', { uri, type: mimeType, name: fileName });
                    axios.post(config.mobApiUrl + 'uploadVideos',
                        formData, {
                            headers: { 'content-type': 'multipart/form-data' }
                        }
                    )
                        .then(function (response) {
                            if (response.status == 200) {
                                axios.post(config.mobApiUrl + 'video_recording/add',
                                    {
                                        user_id: self.props.user._id,
                                        filename: response.data.fileName
                                    })
                                    .then(function (response) {
                                        if (response.status === 200) {
                                            const videos = self.state.videos;
                                            videos.push(response.data.data);
                                            self.setState({ videos });
                                        }
                                    })
                                    .catch(function (error) {
                                        self._showToast('An unexpected error occurred while saving vide recording. Please try again!');
                                    });
                            }
                        })
                        .catch(function (err) {
                            // self._showToast('An unexpected error occurred. Please try again!');
                        });
                }
            })
            .catch((err) => {
                //self._showToast('An unexpected error occurred. Please try again!');
            });
    }

    sendVideo(data) {
        // console.log(data);
    }

    _getTime(date) {
        return new Date(date).toLocaleTimeString('en-US', { hour12: true });
    }

    _showToast(msg, duration = 750) {
        this.refs.toast.show(msg, duration);
    }

    render() {
        const videos = this.state.videos;
        return (
            <View style={{ flex: 1 }}>
                <Loader loading={this.state.loading} />
                <Toast ref="toast" position="center" />
                {
                    videos.length ?

                        <ScrollView keyboardShouldPersistTaps="always" style={{ margin: 10, backgroundColor: "#ffffff", borderRadius: 10, flex: 0.85 }} >
                            {videos.map((item, i) =>
                                <View style={styles.singlelist} key={i}>
                                    <View style={{ flex: 0.70 }}>
                                        <View>
                                            <Text style={styles.filename} numberOfLines={1}>{item.filename}</Text>
                                            <Text style={styles.videoTime} numberOfLines={1} >{this._getTime(item.time)}</Text>
                                        </View>
                                    </View>
                                    <View style={styles.sendBtn}>
                                        <TouchableOpacity onPress={() => this.sendVideo(item)} style={styles.sendtxt} >
                                            <Text style={{ color: '#fff' }}>Send</Text>
                                        </TouchableOpacity>
                                    </View>
                                </View>
                            )}
                        </ScrollView>
                        :
                        <View style={{ padding: 10 }}><Text style={{ color: '#cf9740' }}>{this.state.loading ? 'Loading...' : 'No record found!'}</Text></View>
                }
                <View style={{ alignItems: 'center', justifyContent: 'center', flex: 0.15, backgroundColor: '#244576' }}><FilePickerModule callback={this.onStopRecording} containerStyle={styles.record} iconName="record-rec" iconSize={30} iconStyle={{ color: '#fff' }} isVideo={true} openOnStart="camera" /></View>
            </View>
        );
    }
}

const mapStateToProps = (state) => {
    return {
        user: state.users
    }
}
const mapDispatchToProps = (dispatch) => {
    return {
        updateHeaderTitle: (headerTitle) => dispatch(updateHeaderTitle(headerTitle))
    }
}
export default connect(mapStateToProps, mapDispatchToProps)(Vmail);

const styles = StyleSheet.create({
    record: {
        padding: 5,
        borderRadius: 20,
        backgroundColor: 'red',
    },
    imageContainer: {
        borderRadius: 100,
        height: 25,
        width: 25,
        backgroundColor: '#244576',
        flex: 0.08,
        marginRight: 10,
        alignItems: 'center',
        justifyContent: 'center'
    },
    fileName: {
        fontSize: 16,
        fontWeight: '300',
        color: '#000000'
    },
    singlelist: {
        flexDirection: 'row',
        borderRadius: 0,
        padding: 10,
        backgroundColor: '#fff',
        marginBottom: 0,
        marginLeft: 0,
        marginRight: 0,
        marginTop: 0,
        borderBottomWidth: 1,
        borderColor: '#eaeaea'
    },
    sendBtn: {
        alignItems: 'flex-end',
        flex: 0.3
    },
    sendtxt: {
        marginLeft: 15,
        backgroundColor: '#244576',
        borderRadius: 5,
        padding: 8
    },
    videoTime: {
        fontSize: 10,
        fontWeight: 'bold',
        color: '#cf9740'
    }
});
