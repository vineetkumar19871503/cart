import React, { Component } from 'react';
import {
  Alert,
  Button,
  StyleSheet,
  keyboardShouldPersistTaps,
  ScrollView,
  Text,
  TextInput,
  TouchableOpacity,
  View,
  WebView,
  Modal,
  Picker,
  Platform,
  ActionSheetIOS
} from 'react-native';
import config from '../config/';
import Icon from 'react-native-vector-icons/FontAwesome';
import { NavigationActions } from 'react-navigation';
import axios from 'axios';
import Header from './Header.js';
import Loader from './Loader';
import LinearGradient from 'react-native-linear-gradient';
import IconMaterial from 'react-native-vector-icons/MaterialCommunityIcons';
// import PayPal from 'react-native-paypal-wrapper';
import Toast from 'react-native-easy-toast';

var quesPlaceHolder = 'Select security questions';
class Registration extends React.Component {
  static navigationOptions = {
    title: 'Registration',
  };
  constructor(props) {
    super(props);
    const self = this;
    this.state = {
      userId: null,
      formErrors: {},
      loading: true,
      showWebviewLoader: true,
      formFields: self.getInitialFormValues(),
      questions: {},
      paymentData: {},
      setCondition: false,
      modalVisible: false,
      showPaypalModal: false,
      selectedQuesIndex: 1,
      quesText: quesPlaceHolder
    };
    this.state.headerTitle = 'New User';
    this.registerUser = this.registerUser.bind(this);
    this.showHideWebviewLoader = this.showHideWebviewLoader.bind(this);
    this.onWebviewMessage = this.onWebviewMessage.bind(this);

    //call api for security questions
    axios.get('https://twa-apis.herokuapp.com/api/v1.0/users/getSecurityQuestions')
      .then(function (response) {
        self.setState({
          loading: false
        });
        if (response.data.data) {
          let singleObj = {};
          response.data.data.filter((usr) => {
            singleObj[usr.question] = usr._id;
            return singleObj;
          });
          self.setState({ questions: singleObj });
        } else {
          Alert.alert(
            '',
            response.data.message,
          );
        }
      })
      .catch(function (error) {
        self.setState({
          loading: false
        });
      });
  }

  getInitialFormValues() {
    return {
      fname: null,
      lname: null,
      username: null,
      email: null,
      password: null,
      re_password: null,
      question: null,
      answer: null
    }
  }

  onChange(fieldName, value) {
    const self = this,
      formFields = this.state.formFields;
    formFields[fieldName] = value;
    this.setState({ formFields })
  }

  registerUser() {
    const self = this,
      paymentFailureMsg = 'Registration failed as payment could not be made successfully. Please try again!';
    this.setState({
      loading: true
    });
    axios.post(config.mobApiUrl + 'users/register', self.state.formFields)
      .then(async function (response) {
        if (response.status == 200) {
          self.setState({ loading: false, showPaypalModal: true, userId: response.data.data._id });
        } else {
          self._showToast('Registration failed!');
        }
      })
      .catch(function (error) {
        self.setState({ loading: false });
      });
  }

  removeUser() {
    const self = this;
    self.setState({showPaypalModal: false});
    axios.post(config.mobApiUrl + 'users/delete', { id: self.state.userId })
      .then(response => {
        console.log(response);
      })
      .catch(err => {
        console.log(response);
      });
  }

  updateUser(data) {
    const self = this;
    return new Promise((resolve, reject) => {
      axios.post(config.mobApiUrl + 'users/edit', data)
        .then(response => {
          resolve(response);
        })
        .catch(err => {
          reject(err);
        });
    });
  }

  submitRegistration = () => {
    const self = this;
    self._validateForm((isValid) => {
      if (isValid) {
        var value = self.state.formFields;
        if (value) {
          self.setState({
            setCondition: true
          });
        }
      }
    });
  }

  _validateForm(cb) {
    const errors = {}
    isValid = true,
      _v = this._validationMethods(),
      _fv = Object.assign({}, this.state.formFields),
      postMsg = 'can\'t be empty';

    if (_v.checkEmpty(_fv.fname)) {
      errors.fname = 'first name ' + postMsg;
    }
    if (_v.checkEmpty(_fv.lname)) {
      errors.lname = 'last name ' + postMsg;
    }
    if (_v.checkEmpty(_fv.username)) {
      errors.username = 'username ' + postMsg;
    }
    if (_v.checkEmpty(_fv.email)) {
      errors.email = 'email ' + postMsg;
    } else if (!_v.checkEmail(_fv.email)) {
      errors.email = 'invalid email';
    }
    if (_v.checkEmpty(_fv.password)) {
      errors.password = 'password ' + postMsg;
    }
    if (_v.checkEmpty(_fv.re_password)) {
      errors.re_password = 'confirm password ' + postMsg;
    }
    if (_v.checkEmpty(_fv.question)) {
      errors.question = 'please select atleast one question';
    }
    if (_v.checkEmpty(_fv.answer)) {
      errors.answer = 'answer ' + postMsg;
    }
    if (!errors.password && !errors.re_password && !_v.checkPasswords(_fv.password, _fv.re_password)) {
      errors.re_password = 'passwords do not match';
    }
    if (Object.keys(errors).length) {
      isValid = false;
    }
    this.setState({ formErrors: errors }, () => {
      cb(isValid);
    });
  }

  // validation methods
  _validationMethods() {
    return {
      checkEmpty: (val) => {
        val = !val ? '' : val;
        return !val.trim().length;
      },
      checkEmail: (email) => {
        email = !email ? '' : email;
        const atpos = email.indexOf("@"),
          dotpos = email.lastIndexOf(".");
        return !(atpos < 1 || dotpos < atpos + 2 || dotpos + 2 >= email.length);
      },
      checkPasswords: (pass1, pass2) => {
        return pass1 === pass2;
      }
    }
  }

  rejectRegistration = () => {
    const self = this;
    self.clearForm();
    this.setState({
      setCondition: false
    });
  }

  showHideWebviewLoader(state) {
    this.setState({ showWebviewLoader: state });
  }

  onWebviewMessage(e) {
    const self = this;
    let res = e.nativeEvent.data;
    try {
      res = JSON.parse(res);
      switch (res.status) {
        case "cancel": self.removeUser(); break;
        case "error": self.removeUser(); break;
        case "success":
          self.updateUser({
            'id': self.state.userId,
            'billing_info': e.nativeEvent.data,
            'billing_successful': true
          })
            .then((res) => {
              self.setState({ showPaypalModal: false, setCondition: false, modalVisible: true });
            })
            .catch((err) => {
              console.log(err);
              self._showToast('Error occurred!')
            });;
          break;
        default: return;
      }
      self._showToast(res.message, 2000);
    } catch (e) {
      console.log(e);
      self._showToast('Unexpected error occurred!');
    }
  }

  renderPaypalModal() {
    return (
      <Modal
        animationType="slide"
        transparent={false}
        visible={this.state.showPaypalModal}
        onRequestClose={() => { }}>
        <Loader loading={this.state.showWebviewLoader} />
        <WebView
          source={{ uri: config.mobApiUrl + 'paypal/checkout' }}
          ref="webview"
          onLoadEnd={() => this.showHideWebviewLoader(false)}
          onMessage={this.onWebviewMessage}
        />
      </Modal>
    );
  }

  _setModalVisible(visible) {
    this.setState({ modalVisible: visible });
  }

  _errMsg(field) {
    const fErr = this.state.formErrors;
    if (!fErr[field]) {
      return null;
    }
    return (
      <Text accessibilityLiveRegion="polite" style={{ flex: 1, color: '#a00' }}>
        {fErr[field]}
      </Text>
    )
  }

  _showQuestionsOption(self) {
    let allQuestionsArr = ['Cancel', quesPlaceHolder];
    let updatedOptions = allQuestionsArr.concat(Object.keys(self.state.questions));
    ActionSheetIOS.showActionSheetWithOptions({
      options: updatedOptions,
      destructiveButtonIndex: self.state.selectedQuesIndex,
      cancelButtonIndex: 0,
    },
      (buttonIndex) => {
        if (buttonIndex !== 0 && buttonIndex !== 1) {
          self.setState({ quesText: updatedOptions[buttonIndex], selectedQuesIndex: buttonIndex });
          self.onChange('question', updatedOptions[buttonIndex]);
        } else {
          self.setState({ quesText: quesPlaceHolder })
          self.onChange('question', null);
        }
      });
  }

  clearForm() {
    // clear content from all textbox
    this.setState({ formFields: null, quesText: quesPlaceHolder });
  }

  _showToast(msg, duration = 750) {
    this.refs.toast.show(msg, duration);
  }

  render() {
    const self = this,
      _q = this.state.questions;
    return (
      <View style={{ flex: 1 }}>
        {this.renderPaypalModal()}
        <Toast ref="toast" />
        <Loader loading={this.state.loading} />
        <LinearGradient colors={['#ffffff', '#cccccc']} style={styles.linearGradient}>
          <Modal
            animationType="slide"
            transparent={false}
            visible={this.state.modalVisible}
            onRequestClose={() => {
              this.props.navigation.navigate('Login')
            }}>
            <View style={{
              flex: 1,
              padding: 10,
              backgroundColor: '#fff',
              flexDirection: 'column',
              justifyContent: 'center',
              alignItems: 'center',
            }}>
              <View style={{ flex: 0.2, alignSelf: 'stretch', justifyContent: 'center', alignItems: 'center' }}>
                <Text style={{ color: '#244576', flexDirection: 'row', fontSize: 30 }}>Congratulations!</Text>
                <Text style={{ color: '#000', flexDirection: 'row' }}>Your registration has been completed!</Text>
              </View>
              <View style={{ flex: 0.1, alignSelf: 'stretch', borderRadius: 50, justifyContent: 'center', marginBottom: 10, alignItems: 'center', backgroundColor: '#eaeaea' }}>
                <Text style={{ color: '#000', flexDirection: 'row' }}>If you have any concerns then please contact us.</Text>
              </View>
              <View style={{ flex: 0.5, alignSelf: 'stretch', borderWidth: 0, borderRadius: 50, justifyContent: 'center', marginBottom: 10, alignItems: 'center', backgroundColor: '#ffffff' }}>
                <IconMaterial name="email" size={40} color="#cf9740" />
                <Text style={{ color: '#cf9740', flexDirection: 'row', marginBottom: 10 }}>info@thirdwitness.net</Text>
                <IconMaterial name="cellphone" size={40} color="#cf9740" />
                <Text style={{ color: '#cf9740', flexDirection: 'row' }}> (800)729-6913</Text>
              </View>
              <View style={{ flex: 0.2 }}></View>
              <TouchableOpacity style={{ flex: 0.1, backgroundColor: '#cf9740', alignSelf: 'stretch', justifyContent: 'center', padding: 5, }}
                onPress={async () => {
                  await self.props.navigation.navigate('Login')
                  self._setModalVisible(!this.state.modalVisible);
                }}
                underlayColor='#8b650b'>
                <Text style={styles.buttonText}>OK</Text>
              </TouchableOpacity>
            </View>
          </Modal>
          {this.state.setCondition ?
            <View style={{ flex: 1 }}>
              <LinearGradient colors={['#ffffff', '#cccccc']} style={styles.linearGradient}>
                <View style={{ flex: 0.9, alignSelf: 'stretch', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
                  <Text style={{ fontWeight: 'bold', marginBottom: 10 }}>Terms and Conditions</Text>
                  <ScrollView keyboardShouldPersistTaps='always' style={styles.scrollstyle} >
                    <Text>1. I understand that it is the job of Law Enforcement (Police) to enforce the
                      law, protect my family, friends, community and me from danger and harm
                      that I may or may not be aware of, understand, or see.{"\n"}{"\n"}</Text>
                    <Text>2. In registering, I agree to respect the authority of all Law Enforcement that
                      establish contact with me via TWA and to respectively comply with their
                      requests, even if I do not understand or agree with the reason they have
                      stopped, questioned, or detained me.{"\n"}{"\n"}</Text>
                    <Text>3. I further agree to cooperate with all requests from proper legal authority for
                      copies of my TWA identification documents as they may assist in protecting
                      and clarifying the truth for me, the Public and National Security.{"\n"}{"\n"}</Text>
                    <Text>4. To the best of my ability, all TWA files, recordings, and information will be
                      immediately and unconditionally be made available in matters involving
                      terrorist threats, activity, and threats to National Security.{"\n"}{"\n"}</Text>
                    <Text>5. All materials submitted to TWA is stored on TWA's servers exclusively.{"\n"}{"\n"}</Text>
                    <Text>6. All documents and communication is encrypted and can only be accessed by
                      (a) submitting an ID Case Number. TWA does not associated names with
                      recording ID numbers and therefore cannot retrieve any recordings without
                      an ID number.{"\n"}{"\n"}</Text>
                    <Text>7. All personal identifying information (i.e., name, address, phone number,
                      other ID ect.) associated wit information submitted by the Public and
                      retained on TWA's servers will be redacted and encrypted.{"\n"}{"\n"}</Text>
                    <Text>8. Police name, badge number, precinct, and supervisor's names will not be
                      available or released to the Public by TWA but may be requested or
                      submitted to the Public by the Officer or Precinct upon request during, or
                      after, a contact event.{"\n"}{"\n"}</Text>
                    </ScrollView>
                </View>
                <View style={{ marginTop: 10, flex: 0.3, flexDirection: 'column', paddingTop:20}} >
                  <View>
                    <Text>I accept the aforementioned</Text>
                    <TouchableOpacity style={{  backgroundColor: '#cf9740', alignSelf: 'stretch', justifyContent: 'center', padding: 15, margin: 10, borderRadius: 50 }}
                    onPress={this.registerUser} underlayColor='#8b650b'>
                    <Text style={styles.buttonText}>ACCEPT</Text>
                  </TouchableOpacity>
                  </View>  
                  <View>    
                    <Text>I do not accept the aforementioned</Text>
                    <TouchableOpacity style={{ backgroundColor: '#800c0d', borderRadius: 50, alignSelf: 'stretch', justifyContent: 'center', padding : 15, margin: 10 }}
                    onPress={this.rejectRegistration} underlayColor='#8b650b'>
                    <Text style={styles.buttonText}>REJECT</Text>
                  </TouchableOpacity>
                  </View>                
                </View>                
              </LinearGradient>
            </View>
            :
            <View>
              <ScrollView keyboardShouldPersistTaps='always' style={styles.scrollstyle} >
                <View style={styles.container} >
                  <View>
                    <View style={styles.inputSection}>
                      <Icon style={styles.inputIcon} name="user" size={20} color="#000" />
                      <TextInput
                        style={styles.inputForm}
                        placeholder="First Name"
                        onChangeText={value => this.onChange('fname', value)}
                        underlineColorAndroid="transparent"
                      />
                    </View>
                    {this._errMsg('fname')}
                  </View>
                  <View>
                    <View style={styles.inputSection}>
                      <Icon style={styles.inputIcon} name="user" size={20} color="#000" />
                      <TextInput
                        style={styles.inputForm}
                        placeholder="Last Name"
                        onChangeText={value => this.onChange('lname', value)}
                        underlineColorAndroid="transparent"
                      />
                    </View>
                    {this._errMsg('lname')}
                  </View>
                  <View>
                    <View style={styles.inputSection}>
                      <Icon style={styles.inputIcon} name="user" size={20} color="#000" />
                      <TextInput
                        autoCapitalize="none"
                        style={styles.inputForm}
                        placeholder="Username"
                        onChangeText={value => this.onChange('username', value)}
                        underlineColorAndroid="transparent"
                      />
                    </View>
                    {this._errMsg('username')}
                  </View>
                  <View>
                    <View style={styles.inputSection}>
                      <Icon style={styles.inputIcon} name="envelope" size={20} color="#000" />
                      <TextInput
                        autoCapitalize="none"
                        style={styles.inputForm}
                        placeholder="Email"
                        onChangeText={value => this.onChange('email', value)}
                        underlineColorAndroid="transparent"
                      />
                    </View>
                    {this._errMsg('email')}
                  </View>
                  <View>
                    <View style={styles.inputSection}>
                      <Icon style={styles.inputIcon} name="lock" size={20} color="#000" />
                      <TextInput
                        style={styles.inputForm}
                        placeholder="Password"
                        onChangeText={value => this.onChange('password', value)}
                        secureTextEntry={true}
                        underlineColorAndroid="transparent"
                      />
                    </View>
                    {this._errMsg('password')}
                  </View>
                  <View>
                    <View style={styles.inputSection}>
                      <Icon style={styles.inputIcon} name="lock" size={20} color="#000" />
                      <TextInput
                        style={styles.inputForm}
                        placeholder="Confirm Password"
                        onChangeText={value => this.onChange('re_password', value)}
                        secureTextEntry={true}
                        underlineColorAndroid="transparent"
                      />
                    </View>
                    {this._errMsg('re_password')}
                  </View>
                  <View>
                    <View style={{ marginTop: 10 }}>
                      {
                        Platform.OS === 'android'
                          ?
                          <Picker
                            style={{ height: 30 }}
                            selectedValue={this.state.quesText}
                            onValueChange={(value, index) => { this.onChange('question', value); this.setState({ quesText: value }); }}
                          >
                            <Picker.Item label={quesPlaceHolder} value={null} />
                            {
                              Object.keys(_q).map((key, i) =>
                                <Picker.Item key={i} label={key} value={_q[key]} />
                              )
                            }
                          </Picker>
                          :
                          <View style={styles.inputForm} >
                            <View style={{ flex: 1, flexDirection: 'row' }}>
                              <IconMaterial style={styles.inputIcon} name="security" size={20} color="#000" />
                              <Text style={{ flex: 1, }} onPress={() => this._showQuestionsOption(this)}>{this.state.quesText}</Text>
                              <IconMaterial size={25} style={{ alignSelf: 'flex-end' }} onPress={() => this._showQuestionsOption(this)} name="arrow-down-bold" />
                            </View>
                          </View>
                      }
                    </View>
                    {this._errMsg('question')}
                  </View>
                  <View>
                    <View style={styles.inputSection}>
                      <Icon style={styles.inputIcon} name="unlock" size={20} color="#000" />
                      <TextInput
                        style={styles.inputForm}
                        placeholder="Answer"
                        onChangeText={value => this.onChange('answer', value)}
                        underlineColorAndroid="transparent"
                      />
                    </View>
                    {this._errMsg('answer')}
                  </View>
                </View>
              </ScrollView>
              <TouchableOpacity style={styles.button} onPress={this.submitRegistration} underlayColor='#8b650b'>
                <Text style={styles.buttonText}>Register</Text>
              </TouchableOpacity>
            </View>
          }
        </LinearGradient>
      </View>
    );
  }
}

var styles = StyleSheet.create({
  linearGradient: {
    flex: 1,
    padding: 20

  },
  scrollstyle: {
    borderRadius: 15,
    backgroundColor: '#eaeaea',
    height: '80%',
    padding: 10
  },
  container: {
    justifyContent: 'center',
    marginTop: 5,
    padding: 20

  },
  title: {
    fontSize: 30,
    alignSelf: 'center',
    marginBottom: 30
  },
  buttonText: {
    fontSize: 18,
    color: 'white',
    alignSelf: 'center'
  },
  button: {
    paddingTop: 15,
    paddingBottom: 15,
    backgroundColor: '#cf9740',
    borderWidth: 0,
    borderRadius: 50,
    marginBottom: 10,
    marginTop: 10,
    borderRadius: 100,
    alignSelf: 'stretch',
    justifyContent: 'center',

  },
  inputForm: {
    flex: 1,
    paddingTop: 10,
    paddingRight: 10,
    paddingBottom: 10,
    paddingLeft: 0,
    borderWidth: 0,
  },
  inputSection: {
    borderBottomColor: '#bbb',
    borderBottomWidth: 1,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center'

  },
  inputIcon: {
    padding: 10,
  }
});

export default Registration