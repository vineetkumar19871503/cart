import React, { Component } from 'react';
import {
  Button,
  Platform,
  Text,
  View,
  TouchableOpacity,
  Dimensions
} from 'react-native';
import FilePickerModule from './FilePickerModule';
import Icon from 'react-native-vector-icons/FontAwesome';
import IconMaterial from 'react-native-vector-icons/MaterialCommunityIcons';
import { connect } from 'react-redux';
class Footer extends React.Component {
  constructor(props) {
    super(props);
  }

  _navigate(screen) {
    this.props.commonReducer.routerNavigation.navigate(screen);
  }

  render() {
    return (
      <View style={{ position: 'absolute', bottom: 0, flex: 1, flexDirection: 'row', elevation: 11, backgroundColor: '#cf9740' }}>
        <TouchableOpacity onPress={() => this._navigate('UsersListing')} style={{ flex: 0.5, alignItems: 'center', padding: 10, justifyContent: 'center' }}>
          <IconMaterial name="map-marker-outline" size={20} color="#fff" />
        </TouchableOpacity>
        <TouchableOpacity onPress={() => this._navigate('RecordedVideos')} style={{ flex: 0.5, alignItems: 'center', padding: 10, justifyContent: 'center', borderLeftWidth: 1, borderColor: '#ae7e0a' }}>
          <Text><Icon name="video-camera" size={20} color="#fff" /></Text>
        </TouchableOpacity>
      </View>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    commonReducer: state.common
  }
}

export default connect(mapStateToProps)(Footer);

