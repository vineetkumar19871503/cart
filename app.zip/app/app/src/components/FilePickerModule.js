import React, { Component } from 'react';
import {
  Alert,
  Button,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  Modal,
  Platform
} from 'react-native';
import ImagePicker from 'react-native-image-crop-picker';
import { DocumentPicker, DocumentPickerUtil } from 'react-native-document-picker';
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/FontAwesome';
import axios from 'axios';
import Loader from './Loader';
import IconMaterial from 'react-native-vector-icons/MaterialCommunityIcons';
export default class FilePickerModule extends React.Component {
  constructor(props) {
    super(props);
    const self = this;
    this.state = { showPickerOptions: false };
    if(props.openOnStart) {
      this.showPickerOptions();
    }
  }

  openCam(isVideo = false) {
    const self = this,
      _p = self.props;
    let imageQuality = 0.6,
      mediaType = 'photo',
      cropping = false;
    if (_p.isVideo) {
      mediaType = 'video';
    } else {
      if (_p.imageQuality) {
        imageQuality = _p.imageQuality;
      }
    }
    if (_p.cropping) {
      cropping = _p.cropping;
    }
    let opts = {
      loadingLabelText: 'loading...',
      mediaType,
      cropping
    };
    if (mediaType == 'photo') {
      opts.compressImageQuality = imageQuality;
    }
    ImagePicker.openCamera(opts)
      .then(data => {
        data = self._formatData([data]);
        self._handleResponse({
          data,
          pickerType: 'camera'
        });
      })
      .catch(err => {
        self._handleResponse(err, true);
      });
  }

  openPicker() {
    const self = this,
      isMultiple = self.props.isMultiple === true ? true : false;
    let mediaType = 'photo';
    if (this.props.isVideoGallery === true) {
      mediaType = 'video';
    }
    ImagePicker.openPicker({
      loadingLabelText: 'loading...',
      multiple: isMultiple,
      mediaType
    }).then(items => {
      if (!Array.isArray(items)) {
        items = [items];
      }
      const data = self._formatData(items);
      self._handleResponse({
        data,
        pickerType: 'gallery'
      });
    })
      .catch(err => {
        self._handleResponse(err, true);
      });
  }

  openMediaLibrary() {
    const self = this;
    DocumentPicker.show({
      filetype: [DocumentPickerUtil.allFiles()],
    }, (err, data) => {
      err ? self._handleResponse(err, true) : self._handleResponse({
        data: [data],
        pickerType: 'documents'
      });
    });
  }

  _formatData(data) {
    let res = [];
    if (Array.isArray(data)) {
      data.map((dt) => {
        const _tmpDt = Object.assign({}, dt),
          path = _tmpDt.path;
        let fileName = path.split('/');
        _tmpDt.fileName = fileName[fileName.length - 1];
        _tmpDt.fileSize = _tmpDt.size;
        _tmpDt.type = _tmpDt.mime;
        _tmpDt.uri = _tmpDt.path;
        delete _tmpDt.size;
        delete _tmpDt.mime;
        delete _tmpDt.path;
        res.push(_tmpDt);
      });
      return res;
    }
  }

  _handleResponse(res, isErr = false) {
    const self = this;
    if (typeof self.props.callback == 'function') {
      self.props.callback(new Promise((resolve, reject) => {
        if (isErr) {
          reject(res);
        } else {
          self.setState({ showPickerOptions: false }, () => {
            resolve(res);
          });
        }
        isErr ? reject(res) : resolve(res);
      }));
    }
  }

  renderPickerModal() {
    return (
      <View>
        <Modal
          animationType="slide"
          transparent={false}
          visible={this.state.showPickerOptions}
          onRequestClose={() => { }}>
          <LinearGradient colors={['#244576', '#13253f']} style={styles.linearGradient}>
            <View><Text style={{ color: '#fff' }}>Choose any option</Text></View>
            <View style={{ flexDirection: 'row' }}>
              <TouchableOpacity style={styles.optionBox} onPress={() => this.openPicker()}>
                <IconMaterial
                  style={styles.icon}
                  name="folder-multiple" size={30} />
              </TouchableOpacity>
              <TouchableOpacity style={styles.optionBox} onPress={() => this.openCam()}>
                <IconMaterial
                  style={styles.icon}
                  name="camera" size={30} />
              </TouchableOpacity>
              <TouchableOpacity style={styles.optionBox} onPress={() => this.openMediaLibrary()}>
                <IconMaterial
                  style={styles.icon}
                  name="file" size={30} />
              </TouchableOpacity>
              <TouchableOpacity style={styles.modalClose} onPress={() => this.showPickerOptions(false)}>
                <IconMaterial name="close" size={15} color="#333" />
              </TouchableOpacity>
            </View>
          </LinearGradient>
        </Modal>
      </View>
    );
  }

  showPickerOptions(show = false) {
    const self = this,
      openPickerType = this.props.openOnStart ? this.props.openOnStart : this.props.openPickerType;
    if (openPickerType) {
      switch (openPickerType) {
        case "camera": self.openCam(); break;
        case "gallery": self.openPicker(); break;
        case "documents": self.openMediaLibrary(); break;
        default: self.setState({ showPickerOptions: show });
      }
    } else {
      this.setState({ showPickerOptions: show });
    }
  }

  render() {
    const _p = this.props,
      containerStyle = _p.containerStyle ? _p.containerStyle : {},
      iconStyle = _p.iconStyle ? _p.iconStyle : { color: '#f00' },
      iconSize = _p.iconSize ? _p.iconSize : 30;
    return (
      <TouchableOpacity style={containerStyle}
        onPress={() => this.showPickerOptions(true)}
      >
        {this.renderPickerModal()}
        <IconMaterial
          style={iconStyle}
          name={this.props.iconName ? this.props.iconName : "paperclip"} size={iconSize} />
      </TouchableOpacity>
    )
  }
}

const styles = StyleSheet.create({
  linearGradient: {
    flex: 1,
    paddingTop: 20,
    paddingBottom: 10
  },
  modalClose: {
    position: 'absolute',
    top: 15,
    right: 15,
    padding: 8,
    borderRadius: 20,
    backgroundColor: '#CCC'
  },
  optionBox: {
    padding: 15,
    borderWidth: 1,
    borderColor: '#f1f1f1',
    borderRadius: 5,
    marginRight: 10
  },
  icon: {
    color: '#fff'
  }
});