import React, { Component } from 'react';
import {
  Alert,
  Platform,
  Button,
  StyleSheet,
  Text,
  View,
  Modal,
  Image,
  TextInput,
  TouchableOpacity,
  ScrollView,
  BackHandler,
  Picker,
  ActionSheetIOS
} from 'react-native';
import config from '../config/';
import Loader from './Loader';
import LinearGradient from 'react-native-linear-gradient';
import axios from 'axios';
import profileImage from '../../image/user-default-profile.png';
import { connect } from 'react-redux';
import { NavigationActions } from 'react-navigation';
import Footer from './Footer';
import Geocoder from 'react-native-geocoder';
import TabNavigator from 'react-native-tab-navigator';
import IconMaterial from 'react-native-vector-icons/MaterialCommunityIcons';
import { NotificationsAndroid } from 'react-native-notifications';
import Toast from 'react-native-easy-toast';
var radiusPlaceHolder = 'Select radius';

class UsersListingScreen extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      backPressCount: 0,
      contacts: [],
      vmailMsg: null,
      leosForVmail: [],
      nearbyUsers: [],
      initialPosition: 'unknown',
      loading: false,
      vmailLoading: false,
      vmailModalVisible: false,
      radius: 0,
      selectedTab: 'contacts',
      socket: this.props.services.getSocket(),
      usersLoaded: false,
      validationErrors: {},
      radiusSelected: radiusPlaceHolder,
      selectedRadiusIndex: 1,
    }
    this.showBlastVmailModal = this.showBlastVmailModal.bind(this);
    this.sendVmail = this.sendVmail.bind(this);
  }
  static navigationOptions = {
    title: 'Users Listing',
    cardStyle: { backgroundColor: 'black' }
  };

  getContactList() {
    const self = this;
    self.setState({ loading: true });
    axios.post(config.mobApiUrl + 'users/getContactList', { 'user_id': self.props.user._id, 'type': self.props.user.type })
      .then(function (response) {
        // extract myself from users list
        self.setState({ loading: false, usersLoaded: true, contacts: response.data.data });
        self.filterUsersList(response.data.data, 'contacts');
      })
      .catch(function (error) {
        self.setState({ loading: false });
      });
  }


  componentDidMount() {
    const self = this;
    self.setState({
      initialPosition: this.props.user.location.formattedAddress
    });
    // getting contacts
    self.getContactList();

    // getting nearby users
    self.getUsersInRange();
  }

  componentWillMount() {
    BackHandler.addEventListener('hardwareBackPress', this.backPressed);
  }

  componentWillUnmount() {
    BackHandler.removeEventListener('hardwareBackPress', this.backPressed);
  }

  backPressed = () => {
    this.setState({ backPressCount: this.state.backPressCount + 1 });
    const _b = this.state.backPressCount;
    if (_b == 1) {
      this._showToast('Press again to exit');
    }
    if (_b >= 2) {
      return;
    }
    return true;
  }

  filterUsersList(users, listType) {
    const self = this;
    let msg = null;
    users = users.filter((usr) => usr.email != self.props.user.email);
    const state = listType == 'users' ? { 'nearbyUsers': users } : { 'contacts': users };
    self.setState(state);
  }

  goToProfilePage(user) {
    const self = this;
    user.refresh = () => {
      self.setState({ backPressCount: 0 });
      self.getContactList();
    }
    self.props.navigation.navigate('UserDetail', user);
  }

  getUsersInRange(radius) {
    const self = this;
    self.setState({ radius });
    const _u = self.props.user;
    if (radius && radius >= 0) {
      this.props.services.getUsersByArea(_u.type, radius, _u.email, _u.location.position, function (users) {
        self.filterUsersList(users, 'users');
      });
    } else {
      self.filterUsersList([], 'users');
    }
  }

  showBlastVmailModal(state = true) {
    const self = this,
      _u = self.props.user;
    if (state) {
      self.setState({ vmailLoading: state, vmailMsg: '', validationErrors: {} });
      axios.post(config.mobApiUrl + 'users/leoListOfPar', {
        user_id: _u._id,
        par_id: _u.par_id,
      })
        .then(function (response) {
          self.setState({ vmailLoading: false });
          if (response.data.status == 200) {
            self.setState({ leosForVmail: response.data.data, vmailModalVisible: state });
          }
        })
        .catch(function (error) {
          self.setState({ vmailLoading: false });
          self._showToast("Error occurred. " + error.message);
        });
    } else {
      self.setState({ vmailLoading: state, vmailMsg: '', vmailModalVisible: state, validationErrors: {} });
    }
  }

  contactUsTab() {
    this.getContactList();
    this.setState({ selectedTab: 'contacts' })
  }

  sendVmail() {
    const self = this,
      me = self.props.user,
      loc = me.location,
      _st = self.state,
      errors = {},
      msg = _st.vmailMsg;
    let isValid = true;
    self.setState({ isFormSubmitted: true });
    if (typeof msg == 'string' && msg.trim().length) {
      errors.vmailMsg = null;
    } else {
      isValid = false;
      errors.vmailMsg = 'Message can\'t be empty';
    }
    self.setState({ validationErrors: errors });
    if (isValid) {
      self.setState({ vmailLoading: true });
      const receiverIds = self.state.leosForVmail.map(leo => leo._id),
        vmailObj = {
          "sender_id": me._id,
          "receiver_id": receiverIds,
          "subject": 'vmail blast',
          "location": {
            address: loc.formattedAddress,
            coords: loc.position
          },
          "message": _st.vmailMsg
        };
      axios.post(config.mobApiUrl + 'vmails/sendMsg', vmailObj)
        .then(function (response) {
          self.setState({ vmailLoading: false });
          if (response.data.status == 200) {
            // send notification to users about vmail
            self.state.leosForVmail.map((leo) => {
              const _u = Object.assign({}, vmailObj, { sender: { _id: me._id, email: me.email, name: me.name, fname: me.fname, lname: me.lname } });
              _u.receiver_id = leo._id;
              _u.sender_email = me.email;
              _u.sender_name = me.name;
              _u.receiver_email = leo.email;
              _u.receiver_name = leo.name;
              _u.deviceInfo = leo.deviceInfo;
              self.state.socket.emit('send_vmail', _u);
            });
            self.setState({ vmailModalVisible: false });
            self._showToast('Message sent successfully', 1200);
          }
        })
        .catch(function (error) {
          console.log(error);
          self.setState({ vmailLoading: false });
        });
    }
  }

  renderComposeVmailModal() {
    const err = this.state.validationErrors;
    return (
      <Modal
        animationType="slide"
        transparent={false}
        visible={this.state.vmailModalVisible}
        onRequestClose={() => {
        }}>
        <LinearGradient colors={['#244576', '#13253f']} style={styles.linearGradient}>
          <View >
            <Text style={styles.vmailTitle}>V-Mail Blast</Text>
          </View>
          <ScrollView keyboardShouldPersistTaps="always">
            <TextInput
              placeholder="Message"
              underlineColorAndroid={'transparent'}
              placeholderTextColor="#888"
              multiline={true}
              onChangeText={(text) => this.setState({ vmailMsg: text })}
              value={this.state.message}
              style={styles.textArea}
            />
            <Text style={styles.vmailError}>{err.vmailMsg ? err.vmailMsg : null}</Text>
            <View style={{ flexDirection: 'row' }}>
              <TouchableOpacity onPress={this.sendVmail} style={styles.vmailSubmitBtn}>
                <Text style={{ color: 'white' }}>Submit</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={() => this.showBlastVmailModal(false)} style={styles.vmailSubmitBtn}>
                <Text style={{ color: 'white' }}>Cancel</Text>
              </TouchableOpacity>
            </View>
          </ScrollView>
        </LinearGradient>
      </Modal>
    );
  }

  _showRadiusOptions(self) {
    const radiusOptions = ['Cancel', radiusPlaceHolder, '5 Miles', '10 Miles'];
    ActionSheetIOS.showActionSheetWithOptions({
      options: radiusOptions,
      destructiveButtonIndex: self.state.selectedRadiusIndex,
      cancelButtonIndex: 0,
    },
      (buttonIndex) => {
        if (buttonIndex !== 0 && buttonIndex !== 1) {
          let radiusslected = parseInt(radiusOptions[buttonIndex]);
          self.setState({ radiusSelected: radiusOptions[buttonIndex], selectedRadiusIndex: buttonIndex });
          self.getUsersInRange(radiusslected);
        } else {
          self.setState({ radiusSelected: radiusPlaceHolder })
          self.getUsersInRange(0);
        }
      });
  }

  _showToast(msg, duration = 750) {
    this.refs.toast.show(msg, duration);
  }

  _renderTabs() {
    return (
      <View style={{ padding: 20, flex: 1 }}>
        <TabNavigator
          tabBarStyle={{ top: 0, padding: 0, borderColor: '#ccc', borderRadius: 5, backgroundColor: '#244576' }}
          sceneStyle={{ paddingTop: 50 }}
        >
          <TabNavigator.Item
            titleStyle={{ color: "#ffffff", padding: 5, fontSize: 15, borderBottomWidth: 3, borderColor: '#244576' }}
            selectedTitleStyle={{ color: "#cf9740", borderBottomWidth: 3, borderColor: '#cf9740', padding: 5, fontSize: 15 }}
            selected={this.state.selectedTab === 'contacts'}
            title="Contacts"
            onPress={() => this.contactUsTab()}>
            <View style={styles.container}>
              {this.state.contacts.length ?
                <ScrollView keyboardShouldPersistTaps="always">
                  {this.state.contacts.map((item, i) =>
                    <TouchableOpacity key={i} onPress={() => this.goToProfilePage(item)} username style={styles.singlelist}>
                      <View style={{ flexDirection: 'row' }}>
                        <View style={styles.imageContainer}>
                          <Image source={profileImage} style={styles.profileImage} />
                        </View>
                        <View style={{
                          marginLeft: 10,
                          flex: 1,
                          flexDirection: 'column',
                          alignItems: 'flex-start',
                          justifyContent: 'center'
                        }}>
                          {
                            (this.props.user.type == 'leo') ?
                              (item.type === 'citizen') ?
                                <View>
                                  <Text style={{ fontSize: 18, color: '#434b52', fontWeight: '300' }}>{item.name} {(typeof this.props.user.userChat != 'undefined' && typeof this.props.user.userChat[item.email] != 'undefined') ? "(" + this.props.user.userChat[item.email].length + ")" : ''} </Text>
                                  <Text style={{ fontSize: 14, color: '#cf9740' }}>{item.email}</Text>
                                </View>
                                :
                                <View>
                                  <Text style={{ fontSize: 18, color: '#434b52', fontWeight: '300' }}>{item.name + ' <' + item.email + '>'}</Text>
                                  <Text style={{ fontSize: 14, color: '#cf9740' }}>
                                    <IconMaterial name="trophy-award" />&nbsp;
                              {item.badgeno}</Text>
                                </View>
                              :
                              <View>
                                <Text style={{ fontSize: 18, color: '#434b52', fontWeight: '300' }}>LEO</Text>
                                <Text style={{ fontSize: 14, color: '#cf9740' }}>
                                  <IconMaterial name="trophy-award" />&nbsp;
                              {item.badgeno}</Text>
                              </View>
                          }
                        </View>
                      </View>
                    </TouchableOpacity>
                  )}
                </ScrollView>
                : null}
              {!this.state.contacts.length && !this.state.loading ?
                <View style={{ padding: 10 }}><Text style={{ color: 'red' }}>No contacts available</Text></View>
                : null
              }
            </View>
          </TabNavigator.Item>
          <TabNavigator.Item
            selected={this.state.selectedTab === 'users'}
            titleStyle={{ color: "#ffffff", padding: 5, fontSize: 15, borderBottomWidth: 3, borderColor: '#244576' }}
            selectedTitleStyle={{ color: "#cf9740", borderBottomWidth: 3, borderColor: '#cf9740', padding: 5, fontSize: 15 }}

            title="Nearby Users"
            onPress={() => this.setState({ selectedTab: 'users' })}>
            <View style={{ marginTop: 10 }}>
              <View style={styles.radiusSelect}>
                {(
                  Platform.OS === 'android'
                    ?
                    <Picker
                      style={{ height: 30 }}
                      selectedValue={this.state.radius}
                      onValueChange={(value, index) => this.getUsersInRange(value)}
                    >
                      <Picker.Item label="Select Radius" value={-1} />
                      <Picker.Item label="5 Miles" value="5" />
                      <Picker.Item label="10 Miles" value="10" />
                    </Picker> :
                    <View style={{ flexDirection: 'row', padding: 5 }}>
                      <Text style={{ flex: 0.9 }} onPress={() => this._showRadiusOptions(this)}>{this.state.radiusSelected}</Text>
                      <IconMaterial size={25} style={{ alignSelf: 'flex-end' }} onPress={() => this._showRadiusOptions(this)} name="arrow-down-bold" />
                    </View>
                )}

              </View>
              {this.state.nearbyUsers.length ?
                <View style={styles.container} >
                  <ScrollView keyboardShouldPersistTaps="always">
                    {this.state.nearbyUsers.map((item, i) =>
                      <TouchableOpacity key={i} onPress={() => this.goToProfilePage(item)} username style={styles.singlelist}>
                        <View style={{ flexDirection: 'row' }}>
                          <View style={styles.imageContainer}>
                            <Image source={profileImage} style={styles.profileImage} />
                          </View>
                          <View style={{
                            marginLeft: 10,
                            flex: 1,
                            flexDirection: 'column',
                            alignItems: 'flex-start',
                            justifyContent: 'center'
                          }}>
                            {
                              (this.props.user.type == 'leo') ?
                                (item.type === 'citizen') ?
                                  <View>
                                    <Text style={{ fontSize: 18, color: '#434b52', fontWeight: '300' }}>{item.name}</Text>
                                    <Text style={{ fontSize: 14, color: '#cf9740' }}>{item.email}</Text>
                                  </View>
                                  :
                                  <View>
                                    <Text style={{ fontSize: 18, color: '#434b52', fontWeight: '300' }}>{item.name + ' <' + item.email + '>'}</Text>
                                    <Text style={{ fontSize: 14, color: '#cf9740' }}>
                                      <IconMaterial name="trophy-award" />&nbsp;
                              {item.badgeno}</Text>
                                  </View>
                                :
                                <View>
                                  <Text style={{ fontSize: 18, color: '#434b52', fontWeight: '300' }}>LEO</Text>
                                  <Text style={{ fontSize: 14, color: '#cf9740' }}>
                                    <IconMaterial name="trophy-award" />&nbsp;
                              {item.badgeno}</Text>
                                </View>
                            }
                          </View>
                        </View>
                      </TouchableOpacity>
                    )}
                  </ScrollView>
                </View>
                : null}
              {!this.state.nearbyUsers.length ?

                <View style={{ padding: 10 }}><Text style={{ color: '#cf9740' }}>No nearby users available in this area. Please select different range.</Text></View>
                : null
              }
            </View>
          </TabNavigator.Item>
        </TabNavigator>
      </View>
    );
  }
  _keyExtractor = (item, index) => index.toString();

  render() {
    return (
      <View style={{ flex: 1 }}>
        <Toast ref="toast" position="center" />
        <Loader loading={this.state.loading} />
        <Loader loading={this.state.vmailLoading} />
        {this.renderComposeVmailModal()}
        <View style={styles.addressBar}>
          <View style={{ padding: 10, flex: 0.2 }}>
            <IconMaterial name="map-marker-outline" size={40} color="#cf9740" />
          </View>
          <View style={{ padding: 10, flex: 0.8 }} >
            <Text style={{ justifyContent: 'center', alignSelf: 'center' }}>
              {this.state.initialPosition}
            </Text>
          </View>
        </View>
        {this._renderTabs()}
        <TouchableOpacity style={styles.composeButton} onPress={() => this.showBlastVmailModal(true)}>
          <IconMaterial name="radio-tower" size={20} color="#fff" />
        </TouchableOpacity>
        <Footer />
      </View>
    );
  }
}

var styles = StyleSheet.create({
  container: {
    justifyContent: 'center',
    backgroundColor: '#ffffff',
    borderWidth: 1,
    borderColor: '#ddd',
    borderBottomWidth: 0,
    shadowColor: '#000',
    shadowOffset: { width: 2, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 10,
    marginLeft: 5,
    marginRight: 5,
    marginTop: 10,
    borderRadius: 5,
    padding: 0
  },
  textArea: { color: '#cf9740', borderRadius: 5, backgroundColor: '#fff', marginBottom: 10, flexDirection: 'row', borderColor: 'gray', borderWidth: 1, padding: 15, height: 150, alignItems: 'flex-start', textAlignVertical: 'top' },
  addressBar: {
    flexDirection: 'row',
    justifyContent: 'center',
    height: 80,
    backgroundColor: '#ffffff',
    borderWidth: 1,
    borderColor: '#ddd',
    borderBottomWidth: 1,
    shadowColor: '#000',
    shadowOffset: { width: 1, height: 1 },
    shadowOpacity: 0.3,
    shadowRadius: 1,
    elevation: 1,
    marginLeft: 0,
    marginRight: 0,
    marginTop: 0
  },
  radiusSelect: {
    justifyContent: 'center',
    padding: 3,
    backgroundColor: '#ffffff',
    borderWidth: 1,
    borderColor: '#ddd',
    borderBottomWidth: 0,
    shadowColor: '#000',
    shadowOffset: { width: 2, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 20,
    //elevation: 5,
    marginLeft: 5,
    marginRight: 5,
    marginTop: 0,
    borderRadius: 5,
    //height: 40
  },
  title: {
    fontSize: 30,
    alignSelf: 'center',
    marginBottom: 30
  },
  buttonText: {
    fontSize: 18,
    color: 'white',
    alignSelf: 'center'
  },
  button: {
    height: 36,
    backgroundColor: '#48BBEC',
    borderColor: '#48BBEC',
    borderWidth: 1,
    borderRadius: 8,
    marginBottom: 10,
    alignSelf: 'stretch',
    justifyContent: 'center'
  },
  imageContainer: {
    width: 46,
    height: 46,
    borderRadius: 90,
    borderWidth: 3,
    borderColor: '#eaeaea',
    alignItems: 'flex-start',
    alignSelf: 'center'
  },
  profileImage: {
    width: 38,
    height: 38,
    borderRadius: 90,
  },
  singlelist: {
    borderRadius: 0,
    padding: 10,
    backgroundColor: '#fff',
    marginBottom: 0,
    marginLeft: 0,
    marginRight: 0,
    marginTop: 0,
    borderBottomWidth: 1,
    borderColor: '#eaeaea'
  },
  vmailSubmitBtn: {
    paddingTop: 15,
    paddingBottom: 15,
    backgroundColor: '#cf9740',
    borderWidth: 0,
    borderRadius: 10,
    margin: 10,
    borderRadius: 100,
    flexDirection: 'row',
    flex: 1,
    alignSelf: 'stretch',
    justifyContent: 'center'
  },
  vmailTitle: {
    fontSize: 28,
    color: 'white',
    justifyContent: 'center',
    alignItems: 'center',
    alignSelf: 'center',
    alignContent: 'center',
    marginBottom: 50
  },
  linearGradient: {
    flex: 1,
    padding: 20
  },
  composeButton: {
    position: 'absolute',
    bottom: 55,
    right: 10,
    padding: 10,
    borderRadius: 20,
    backgroundColor: '#244576'
  },
  vmailError: {
    color: '#f00',
    fontSize: 15,
  }
});

const mapStateToProps = (state) => {
  return {
    services: state.services,
    user: state.users
  }
}

export default connect(mapStateToProps)(UsersListingScreen);