import React, { Component } from 'react';
import { StyleSheet, Text, TouchableHighlight, View, ListView, Image } from 'react-native';
import { RTCView } from 'react-native-webrtc';
import styles from "../../style/thumbnails.js";
import config from "../config/";
export default class Thumbnails extends Component {
  constructor(props) {
    super(props);
    const dataSource = new ListView.DataSource({ rowHasChanged: (r1, r2) => r1 !== r2 });
    this.state = {
      dataSource: props.streams.filter(stream => stream.url != props.activeStreamUrl)
    }
  }

  componentWillReceiveProps(nextProps) {
    this.setState({
      dataSource: nextProps.streams.filter(stream => stream.url != nextProps.activeStreamUrl)
    })
  }

  render() {
    let thumbnailStyles = [styles.thumbnail];
    if (this.props.streams.length <= 1) {
      return null;
    }
    //ELSE:
    return (
      <View style={styles.thumbnailContainer}>
        {this.state.dataSource.map((stream, i) =>
          <TouchableHighlight
            key={i}
            onPress={() => this.handleThumbnailPress(stream.url)}>
            {
              config.useRCTView ?
                <RTCView streamURL={stream.url} zOrder={2} objectFit='cover' style={thumbnailStyles} />
                :
                <Image source={stream.url} resizeMode={"contain"} style={thumbnailStyles} />
            }
          </TouchableHighlight>
        )
        }
      </View>
    )
  }

  handleThumbnailPress(streamUrl) {
    this.props.setActive(streamUrl);
  }
}
