import React from 'react';
import { connect } from 'react-redux';
import axios from 'axios';
import Loader from '../Loader';
import {
    Button,
    Image,
    Platform,
    Text,
    TouchableOpacity,
    View,
    ScrollView,
    StyleSheet
} from 'react-native';
import config from '../../config/';
import IconMaterial from 'react-native-vector-icons/MaterialCommunityIcons';
import profileImage from '../../../image/user-default-profile.png';
import Toast from 'react-native-easy-toast';
class ConferenceList extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            conferences: [],
            loading: false
        };
    }

    componentDidMount() {
        this.fetchConferences();
    }

    fetchConferences() {
        const self = this;
        self.setState({ loading: true });
        axios.get(config.mobApiUrl + 'conference/list', {
            user_id: self.props.user._id
        })
            .then(function (response) {
                self.setState({ loading: false, conferences: response.data.data });
            })
            .catch(function (error) {
                self.setState({ loading: false });
            });
    }

    _getDateRange(startDate, endDate) {
        const startDt = new Date(startDate),
            monthNames = [
                "January", "February", "March",
                "April", "May", "June", "July",
                "August", "September", "October",
                "November", "December"
            ],
            day = startDt.getDate(),
            monthIndex = startDt.getMonth(),
            year = startDt.getFullYear(),
            dateStr = monthNames[monthIndex] + ' ' + day + ', ' + year,
            startTime = this.formatTime(startDate),
            endTime = this.formatTime(endDate);
        return dateStr + " (" + startTime + " - " + endTime + ")";
    }

    formatTime(date) {
        // formats a javascript Date object into a 12h AM/PM time string
        date = new Date(date);
        var hour = date.getHours();
        var minute = date.getMinutes();
        var amPM = (hour > 11) ? "PM" : "AM";
        if (hour > 12) {
            hour -= 12;
        } else if (hour == 0) {
            hour = "12";
        }
        if (minute < 10) {
            minute = "0" + minute;
        }
        return hour + ":" + minute + " " + amPM;
    }

    _showToast(msg, duration = 750) {
        this.refs.toast.show(msg, duration);
    }

    render() {
        const conferences = this.state.conferences,
            uid = this.props.user._id;
        return (
            <View style={{ flex: 1 }}>
                <Loader loading={this.state.loading} />
                <Toast ref="toast" position="center" />
                {
                    conferences.length ?
                        <ScrollView keyboardShouldPersistTaps="always">
                            {conferences.map((item, i) =>
                                <View key={i} style={styles.singlelist}>
                                    <View style={{ flexDirection: 'row', flex: 1 }}>
                                        <View style={styles.imageContainer}>
                                            <Image source={profileImage} style={styles.profileImage} />
                                        </View>
                                        <View style={{
                                            marginLeft: 10,
                                            flex: 1,
                                            flexDirection: 'column',
                                            alignItems: 'flex-start',
                                            justifyContent: 'center'
                                        }}>
                                            <Text style={{ fontSize: 16, color: '#434b52', fontWeight: '300' }}>Username</Text>
                                            <Text style={{ fontSize: 16, color: '#434b52', fontWeight: '300' }}>{item.subject}</Text>
                                            <Text style={{ fontSize: 10, color: '#888', fontWeight: '300' }}>{this._getDateRange(item.start_time, item.end_time)}</Text>
                                        </View>
                                    </View>
                                    <View style={styles.confOptions}>
                                        <TouchableOpacity style={styles.joinBtn}>
                                            <Text style={styles.btnTxt}>Join</Text>
                                        </TouchableOpacity>
                                        {
                                            uid == item.user_id
                                                ?
                                                <TouchableOpacity style={styles.editBtn}>
                                                    <Text style={styles.btnTxt}>Edit</Text>
                                                </TouchableOpacity>
                                                : null
                                        }
                                        {
                                            uid == item.user_id
                                                ?
                                                <TouchableOpacity style={styles.deleteBtn}>
                                                    <Text style={styles.btnTxt}>Delete</Text>
                                                </TouchableOpacity>
                                                :
                                                null
                                        }
                                    </View>
                                </View>
                            )}
                        </ScrollView>
                        :
                        <View style={{ padding: 10 }}><Text style={{ color: '#cf9740' }}>{this.state.loading ? 'Loading...' : 'No record found!'}</Text></View>
                }
                <TouchableOpacity style={styles.createConference} onPress={() => this.props.navigation.navigate('CreateConference')}>
                    <IconMaterial name="pencil" size={20} color="#cf9740" />
                </TouchableOpacity>
            </View>
        );
    }
}

const mapStateToProps = (state) => {
    return {
        user: state.users
    }
}
export default connect(mapStateToProps)(ConferenceList);
const styles = StyleSheet.create({
    createConference: {
        position: 'absolute',
        bottom: 30,
        right: 10,
        padding: 10,
        borderRadius: 20,
        backgroundColor: '#244576'
    },
    confOptions: {
        flexDirection: 'row',
        flex: 1,
        padding: 2,
        marginTop: 10
    },
    btnTxt: {
        textAlign: 'center',
        color: '#fff'
    },
    joinBtn: {
        flex: 1,
        padding: 5,
        backgroundColor: '#5bc0de',
        marginRight: 1
    },
    editBtn: {
        flex: 1,
        padding: 5,
        backgroundColor: '#f0ad4e',
        marginRight: 1
    },
    deleteBtn: {
        flex: 1,
        padding: 5,
        backgroundColor: '#d43f3a',
        marginRight: 1
    },
    imageContainer: {
        width: 46,
        height: 46,
        borderRadius: 90,
        borderWidth: 3,
        borderColor: '#eaeaea',
        alignItems: 'flex-start',
        alignSelf: 'center'
    },
    profileImage: {
        width: 38,
        height: 38,
        borderRadius: 90,
    },
    title: {
        fontSize: 16,
        fontWeight: '300',
        color: '#000000'
    },
    username: {
        fontSize: 16,
        fontWeight: '300',
        color: '#000000'
    },
    singlelist: {
        flexDirection: 'column',
        borderRadius: 0,
        padding: 10,
        backgroundColor: '#fff',
        marginBottom: 0,
        marginLeft: 0,
        marginRight: 0,
        marginTop: 0,
        borderBottomWidth: 1,
        borderColor: '#eaeaea'
    },
    time: {
        fontSize: 10,
        fontWeight: 'bold',
        color: '#cf9740'
    }
});
