import React, { Component } from 'react';
import {
    Button, Text, View, StyleSheet, TouchableHighlight
} from 'react-native';
import { connect } from 'react-redux';
import Loader from '../Loader';
import Toast from 'react-native-easy-toast';

class CreateConference extends React.Component {
    static navigationOptions = {
        title: 'Conference'
    };

    constructor(props) {
        super(props);
        this.state = {
        }
    }

    renderToast() {
        return <Toast ref="toast" />;
    }

    _showToast(msg, duration = 750) {
        this.refs.toast.show(msg, duration);
    }

    render() {
        return (
            <View>
                {this.renderToast()}
                <Text>Create Conference Page</Text>
            </View>
        );
    }
}

const mapStateToProps = (state) => {
    return {
        user: state.users
    }
}

export default connect(mapStateToProps)(CreateConference);