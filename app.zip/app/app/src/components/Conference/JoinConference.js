import React, { Component } from 'react';
import {
    Button, Text, View, StyleSheet, TouchableHighlight
} from 'react-native';
import { connect } from 'react-redux';
import { FormLabel, FormInput } from 'react-native-elements';
import FullScreenVideo from "../FullScreenVideo.js";
import Icon from 'react-native-vector-icons/FontAwesome';
import Loader from '../Loader';
import LoudSpeaker from 'react-native-loud-speaker';
import styles from '../../../style/app';
import Thumbnails from "../Thumbnails";
import Toast from 'react-native-easy-toast';

class JoinConference extends React.Component {
    static navigationOptions = {
        title: 'Conference'
    };
    constructor(props) {
        super(props);
        this.dropConf = this.dropConf.bind(this);
        this.state = {
            activeStreamUrl: null,
            audioMuted: false,
            callbacks: {
                participantStreamAdded: this.participantStreamAdded.bind(this)
            },
            isFrontCamera: true,
            joined: false,
            loading: false,
            participants: [],
            roomId: 'xyzabc',
            selfStream: null,
            socketIO: null,
            streams: [],
            videoMsg: null
        }
        this.startConference = this.startConference.bind(this);
    }

    componentWillMount() {
        this.setState({ socketIO: this.props.services.getSocket() });
    }

    async componentDidMount() {
        const self = this;
        this.bindSocketEvents();
        this.props.services.bindComponentCallbacksToServices(this.state.callbacks);
    }

    async dropConf() {
        const params = { 'dropped_by': this.props.user, 'room_id': this.state.roomId };
        this.setState({ activeStreamUrl: null, streams: [] });
        this.killStream(this.state.socketIO.id, true);
        this.props.services.dropConference(params);
        this._resetCall();
    }

    addParticipant(participant) {
        const participants = this.state.participants;
        participants.push(participant);
        this.setState({ participants });
    }

    removeParticipant(participant) {
        const sP = this.state.participants;
        const participants = sP.filter(function (p) {
            return p.socketId != participant.socketId;
        });
        this.setState({ participants });
    }

    bindSocketEvents() {
        const socket = this.state.socketIO,
            self = this;
        // when any participant joins a room
        socket.on("on_participant_joined_conference", function (roomId, participant) {
            self._showToast(participant.name + ' joined the conference', 1200);
            self.addParticipant(participant);
        });
        socket.on('participant_left_conference', function (data) {
            self.removeParticipant(data);
            self._showToast(data.name + ' left conference', 1200);
            self.killStream(data.socketId)
        });
    }

    async startConference() {
        const self = this;
        await this._getLocalStream();
        self.setState({ loading: true });
        // join the room
        self.props.services.joinConference(self.state.roomId, self.props.user.email, function (participants) {
            self.setState({ joined: true, loading: false });
        });
    }

    killStream(socketId = null, killall) {
        const self = this,
            socket = this.state.socketIO;
        if (killall === true) {
            this.setState({ streams: [] });
        } else {
            let streams = this.state.streams;
            for (let str = 0; str < streams.length; str++) {
                if (streams[str].socketId == socketId) {
                    this.props.services.destroyPeerConnection(socketId, streams[str].streamObj);
                    streams.splice(str, 1);
                    break;
                }
            }
            if (streams.length == 1 && streams[0].socketId == socket.id) {
                this.setState({ activeStreamUrl: this.state.selfStream.toURL() });
            }
            this.setState({ streams });
        }
    }

    participantStreamAdded(socketId, stream) {
        const self = this;
        let streams = this.state.streams,
            _sUrl = stream.toURL(),
            newState = {
                activeStreamUrl: _sUrl
            };
        // filter existing stream by socket id
        streams = streams.filter(function (str) {
            return str.socketId != socketId;
        });
        streams.push({
            socketId,
            streamObj: stream,
            url: _sUrl
        });
        newState.streams = streams;
        this.setState(newState);
        setTimeout(function () {
            self._loudSpeaker(true);
        }, 100);
    }

    renderToast() {
        return <Toast ref="toast" />;
    }

    _showToast(msg, duration = 750) {
        if (this.refs.toast) {
            this.refs.toast.show(msg, duration);
        }
    }

    _getLocalStream() {
        const self = this,
            reduxStream = self.props.call.localStream;
        if (reduxStream) {
            self._pushLocalStream(reduxStream);
        } else {
            // getting the client's steam and setting it into state
            self.props.services.getLocalStream(self.state.isFrontCamera, (stream) => {
                self._pushLocalStream(stream);
            });
        }
    }

    _pushLocalStream(stream) {
        const _st = this.state,
            _sU = stream.toURL(),
            streams = _st.streams;
        streams.push({
            socketId: _st.socketIO.id,
            streamObj: stream,
            url: _sU
        });
        this.setState({
            selfStream: stream,
            activeStreamUrl: _sU,
            streams: streams
        });
    }

    _getSocketIdOfParticipant(participant) {
        let socketId = null,
            _p = this.state.participants;
        for (let p = 0; p < _p.length; p++) {
            if (_p[p].email == participant.email) {
                socketId = _p[p].socketId;
                break;
            }
        }
        return socketId;
    }

    _loudSpeaker(status = true) {
        LoudSpeaker.open(status);
    }

    _muteUnmuteAudio(mute = true) {
        const _ss = this.state.selfStream;
        if (_ss) {
            this.setState({ 'audioMuted': mute });
            _ss.getAudioTracks()[0].enabled = mute ? false : true;
        }
    }
    _muteUnmuteVideo(mute = true) {
        const _ss = this.state.selfStream;
        if (_ss) {
            let msg = mute ? 'Video is muted...' : null;
            this.setState({ 'videoMuted': mute, 'videoMsg': msg });
            _ss.getVideoTracks()[0].enabled = mute ? false : true;
        }
    }

    // mute both audio and video
    _muteMedia(mute = true) {
        this._muteUnmuteAudio(mute);
        this._muteUnmuteVideo(mute);
    }

    _resetCall() {
        this.setState({ 'joined': false });
        this._loudSpeaker(false);
    }

    render() {
        return (
            <View>
                {this.renderToast()}
                <Loader loading={this.state.loading} />
                {this.state.joined
                    ?
                    <View style={{ backgroundColor: '#000' }}>
                        <Text style={styles.videoMsg}>{this.state.videoMsg}</Text>
                        <FullScreenVideo streamURL={this.state.activeStreamUrl} />
                        <View style={styles.callOptions}>
                            <Icon
                                style={styles.callOptIcon}
                                onPress={() => this._muteUnmuteAudio(!this.state.audioMuted)}
                                name={this.state.audioMuted ? 'microphone-slash' : 'microphone'}
                                size={28}
                                color="#fff" />
                            <TouchableHighlight
                                style={styles.dropButton}
                                onPress={this.dropConf} >
                                <Icon
                                    name="phone"
                                    size={25}
                                    color="#fff" />
                            </TouchableHighlight>
                            <Icon
                                style={styles.callOptIcon}
                                onPress={() => this._muteUnmuteVideo(!this.state.videoMuted)}
                                name={this.state.videoMuted ? 'video-camera' : 'video-camera'}
                                size={28}
                                color="#fff" />
                        </View>
                        <Thumbnails streams={this.state.streams}
                            setActive={(streamUrl) => this.setState({ 'activeStreamUrl': streamUrl })}
                            activeStreamUrl={this.state.activeStreamUrl} />
                    </View>
                    :
                    <TouchableHighlight onPress={() => this.startConference()}>
                        <View style={styles.blockIcon}>
                            <Icon name="video-camera" size={100} color="#cf9740" />
                            <Text style={{ color: 'white' }}>Attend Conference</Text>
                        </View>
                    </TouchableHighlight>
                }
            </View>
        );
    }
}

const mapStateToProps = (state) => {
    return {
        call: state.call,
        services: state.services,
        user: state.users
    }
}

export default connect(mapStateToProps)(JoinConference);