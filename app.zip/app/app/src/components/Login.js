import React, { Component } from 'react';
import {
  Button,
  StyleSheet,
  Text,
  View,
  Image,
  TouchableHighlight,
  ScrollView,
  Platform,
  TextInput,
  KeyboardAvoidingView,
  TouchableOpacity,
  Alert,
  AsyncStorage
} from 'react-native';
import config from '../config/';
import axios from 'axios';
import { connect } from 'react-redux';
import { FormLabel, FormInput } from 'react-native-elements';
import { addNavigationData } from '../actions/NotificationAction';
import { addRouterNavigation } from '../actions/CommonAction';
import Icon from 'react-native-vector-icons/FontAwesome';
import Loader from './Loader';
import { login } from '../actions/UserAction';
import logo from '../../image/logo.png';
import { StackActions, NavigationActions } from 'react-navigation';
import t from 'tcomb-form-native';
import Toast from 'react-native-easy-toast';
import LinearGradient from 'react-native-linear-gradient';
import PushNotification from 'react-native-push-notification';

const Form = t.form.Form;
class Login extends React.Component {
  static navigationOptions = {
    title: '',
    headerMode: null
  };

  constructor(props) {
    super(props)

    // adding navigation to store
    if (this.props.navigation) {
      this.props.addRouterNavigation(this.props.navigation);
    }
    // this.state = { loading: false, localUserInfo: null, memberIdErrorMsg: null, isMemberId: false, memberId: null, value: { 'email': 'john@twa.com', 'password': '12345678' } };
    this.state = { loading: false, localUserInfo: null, memberIdErrorMsg: null, isMemberId: false, memberId: null, value: {}, deviceInfo: null };
    // this.state = { loading: false, localUserInfo: null, memberIdErrorMsg: null, isMemberId: false, memberId: 318155, value: {} };
    this._onPress = this._onPress.bind(this);
    this.refresh = this.refresh.bind(this);
    this.logout = this.logout.bind(this);
    //email validation
    var Email = t.refinement(t.String, val => this.requiredField(val) && this.validEmail(val));
    Email.getValidationErrorMessage = val => {
      if (!this.requiredField(val)) {
        return 'email required!';
      }
      else if (!this.validEmail(val)) {
        return 'Invalid email address';
      }
    };

    //password validation
    var Password = t.refinement(t.String, val => this.requiredField(val));
    Password.getValidationErrorMessage = val => {
      if (!this.requiredField(val)) {
        return 'password required!';
      }
    };

    //set form
    this.UserLogin = t.struct({
      email: Email,
      password: Password,
    });
  }

  //required field check
  requiredField = (val) => {
    if (val) {
      return true;
    } else {
      return false;
    }
  }

  //valid email check 
  validEmail = (val) => {
    const reg = /[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/; //or any other regexp
    return reg.test(val);
  }

  async componentWillMount() {
    const self = this;
    let localUserInfo = await AsyncStorage.getItem('localUserInfo');
    if (localUserInfo) {
      localUserInfo = JSON.parse(localUserInfo);
      this.setState({ localUserInfo, isMemberId: true });
    }
    PushNotification.configure({
      onRegister: function (token) {
        self.setState({ deviceInfo: token });
      },
      senderID: "35766600149", //sender id from fire base console
      permissions: {
        alert: true,
        badge: true,
        sound: true
      },
    });
  }

  _loginSubmit = () => {
    const self = this;
    const formValueObj = {};
    var value = self.refs.form.getValue();
    if (value) {
      self.setState({
        loading: true
      });
      formValueObj.email = value.email;
      formValueObj.password = value.password;
      formValueObj.type = 'firstLogin';
      axios.post(config.mobApiUrl + 'users/login',
        formValueObj
      )
        .then(function (response) {
          if (response.data.checkstatus) {
            self.setState({ isMemberId: true, loading: false });
          } else {
            Alert.alert(
              '',
              response.data.message,
              [
                { text: 'OK', onPress: () => { self.setState({ loading: false }) } }
              ],
              { cancelable: false }
            );
          }
          // self.setState({
          //   loading: false
          // });
        })
        .catch(function (error) {
          self.setState({
            loading: false
          });
        });

    }
  }

  async _onPress() {
    let _p = this.props;
    const self = this;
    self.setState({ memberIdErrorMsg: '' });
    const formValueObj = {};
    if (self.state.memberId) {
      const usr = self.state.localUserInfo;
      if (usr) {
        if (self.state.memberId == usr.memberId) {
          self.setState({ loading: true });
          await _p.login(usr);
          //update device Info
          let updateDeviceInfo = {};
          updateDeviceInfo.deviceInfo = self.state.deviceInfo;
          updateDeviceInfo.id = usr._id;
          axios.post(config.mobApiUrl + 'users/updateDeviceInfo', updateDeviceInfo)
            .then(async function (response) {
              self.setState({ loading: false }, () => {
                _p.services.mapUserWithSocketId(usr);
                self.navigateAfterLogin();
              });
            })
            .catch(function (error) {
              self._showToast('Error occurred while fetching login details!');
              // console.log(error);
            });
        } else {
          self.setState({ memberIdErrorMsg: 'Invalid member ID' });
        }
      } else {
        // call api if local member id doesn't exist
        var value = self.state.value;
        formValueObj.email = value.email;
        formValueObj.password = value.password;
        formValueObj.memberId = self.state.memberId;
        formValueObj.deviceInfo = self.state.deviceInfo;
        formValueObj.type = 'secondLogin';
        if (value) { // if validation fails, value will be null
          self.setState({
            loading: true
          });
          axios.post(config.mobApiUrl + 'users/login',
            formValueObj
          )
            .then(async function (response) {
              if (response.data.checkstatus) {
                self.setState({ loading: false });
                const userInfo = Object.assign({}, response.data.data, { memberId: self.state.memberId });
                await _p.login(userInfo);
                _p = self.props;
                _p.services.mapUserWithSocketId(_p.user);
                AsyncStorage.setItem('localUserInfo', JSON.stringify(_p.user));
                self.navigateAfterLogin();
              } else {
                self.setState({ isMemberId: true })
                Alert.alert(
                  '',
                  response.data.message,
                  [
                    { text: 'OK', onPress: () => { self.setState({ loading: false }) } }
                  ],
                  { cancelable: false }
                );
              }
            })
            .catch(function (error) {
              self.setState({
                loading: false
              });
            });
        }
      }
    } else {
      self.setState({ memberIdErrorMsg: 'This field is required' });
    }


    // if (!self.state.memberId) {
    //   self.setState({ memberIdErrorMsg: 'This field is required' })
    // } else if (self.state.localMemberId) {
    //   if(self.state.memberId == self.state.localMemberId) {
    //     formValueObj.memberId = self.state.memberId;  
    //   } else {
    //     self.setState({ memberIdErrorMsg: 'Invalid member ID' })  
    //   }
    // } else {
    //   formValueObj.email = value.email;
    //   formValueObj.password = value.password;
    //   formValueObj.memberId = self.state.memberId;
    //   var value = self.state.value;
    //   if (value) { // if validation fails, value will be null
    //     self.setState({
    //       loading: true
    //     });
    //     axios.post('https://twa-apis.herokuapp.com/api/v1.0/users/login',
    //       formValueObj
    //     )
    //       .then(function (response) {
    //         self.setState({
    //           loading: false
    //         });
    //         if (response.data.data.status) {
    //           const userInfo = Object.assign({}, response.data.data, self.state.memberId);
    //           AsyncStorage.setItem('localMemberId', self.state.memberId);
    //           AsyncStorage.setItem('localUserInfo', self.state.memberId);
    //           self.props.login(response.data.data);
    //           self.props.services.mapUserWithSocketId(self.props.user);
    //           self.props.navigation.navigate('UsersListing');
    //         } else {
    //           Alert.alert(
    //             '',
    //             response.data.message,
    //           );
    //         }
    //       })
    //       .catch(function (error) {
    //         self.setState({
    //           loading: false
    //         });
    //       });
    //   }
    // }

  }


  _showToast(msg, duration = 750) {
    this.refs.toast.show(msg, duration);
  }

  navigateAfterLogin() {
    const self = this,
      navObj = this.props.navigation, // router navigation
      notificationNavObj = this.props.notificationNav;  // local notification navigation obj
    if (notificationNavObj) {
      const _n = Object.assign({}, notificationNavObj);
      this.props.addNavigationData(null);
      setTimeout(function () {
        _n.params ? self._resetActionAndRedirect(self, _n.screen, _n.params) : self._resetActionAndRedirect(self, _n.screen);
      }, 500);
    } else {
      setTimeout(function () {
        self._resetActionAndRedirect(self, 'UsersListing');
      }, 500);
    }
  }

  _resetActionAndRedirect(self, screen, params) {
    const resetAction = StackActions.reset({
      index: 0,
      actions: params ? [NavigationActions.navigate({ routeName: screen, params })] : [NavigationActions.navigate({ routeName: screen })],
    });
    this.props.navigation.dispatch(resetAction);
  }

  customFieldsTemplate = (locals) => {
    var error =
      locals.hasError && locals.error ? (
        <Text accessibilityLiveRegion="polite" style={{ flex: 1, color: '#a00' }}>
          {locals.error}
        </Text>
      ) : null;
    if (locals.label.match(/Password/)) {
      var submitArrow = null;
      var secureTextEntry = true;
      var dystyle = 'forPass';
    } else {
      var submitArrow = null;
      var secureTextEntry = null;
      var dystyle = 'forEmail';
    }

    return (
      <View style={{ flex: 1, flexDirection: 'column' }}>
        <View style={{ flex: 0.8, flexDirection: 'row' }}>
          <Icon style={styles.inputIcon} name={locals.help} size={20} color="#cf9740" />
          <View style={styles.inputSection}>
            <TextInput
              style={styles.inputForm}
              autoCorrect={false}
              autoCapitalize='none'
              placeholder={locals.label}
              placeholderTextColor="#888"
              secureTextEntry={secureTextEntry}
              onChangeText={value => locals.onChange(value)}
              underlineColorAndroid="transparent"
            />
            {submitArrow}
          </View>
        </View>
        <View style={styles.errorText}>
          <Text>{error}</Text>
        </View>
      </View>
    );
  }

  onChangeForm = (value) => {
    this.setState({ value });
  }

  onChangeMemberId = (text) => {
    this.setState({ 'memberId': text });
  }

  clearForm() {
    // clear content from all textbox
    this.setState({ value: null });
  }

  logout() {
    const _p = this.props;
    AsyncStorage.removeItem('localUserInfo');
    _p.services.logout();
    this.setState({ isMemberId: false });
  }

  refresh() {
    // when we logout then it still asks to enter TWA Member ID
    const self = this,
      _navSt = this.props.navigation.state;
    if (_navSt.params && this.state.isMemberId) {
      if (_navSt.params.refresh) {
        setTimeout(() => {
          self.setState({ memberId: null, isMemberId: false });
        }, 100);
      }
    }
  }

  render() {
    //set form options
    this.options = {
      fields: {
        email: {
          label: 'Enter Email',
          help: 'envelope',
          template: this.customFieldsTemplate
        },
        password: {
          label: 'Enter Password',
          password: true,
          secureTextEntry: true,
          help: 'lock',
          template: this.customFieldsTemplate
        },
      },
    }
    this.refresh();
    return (
      <View style={{ flex: 1 }}>
        <Toast ref="toast" />
        <LinearGradient colors={['#244576', '#13253f']} style={styles.linearGradient}>
          <Loader loading={this.state.loading} />
          {
            this.state.isMemberId
              ?
              <View style={{ flex: 1, flexDirection: 'column' }}>
                <View style={{ flex: 0.7, alignSelf: 'stretch', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
                  <Text style={{ fontWeight: 'bold', color: 'white' }}>Please enter TWA Member ID</Text>
                  <TextInput
                    secureTextEntry={true}
                    autoFocus={true}
                    autoCorrect={false}
                    underlineColorAndroid={'transparent'}
                    style={{ height: 40, color: '#cf9740', width: 180, borderBottomColor: '#ffffff', borderBottomWidth: 1 }}
                    placeholderTextColor="#888"
                    placeholder="TWA Member ID"
                    returnKeyType='done'
                    keyboardType="numeric"
                    maxLength={6}
                    // onChangeText={(memberId) => this.setState({ memberId })}
                    onChangeText={(text) => this.onChangeMemberId(text)}
                  />
                  <Text style={{ color: '#ed1c25' }}>{this.state.memberIdErrorMsg}</Text>
                </View>
                <View style={{ flex: 0.3, flexDirection: 'column', alignSelf: 'stretch', alignItems: 'center', justifyContent: 'center', margin: 50 }}>
                  <TouchableHighlight style={styles.button}
                    onPress={this._onPress} underlayColor='#8b650b'>
                    <Text style={styles.buttonText}>Confirm</Text>
                  </TouchableHighlight>
                  <View style={styles.textBlcok} >
                    <Text onPress={this.logout} style={styles.newText}>
                      Login with different user
                    </Text>
                  </View>
                </View>
              </View>
              :
              <ScrollView keyboardShouldPersistTaps='always'>

                {/* <KeyboardAvoidingView style={styles.container} behavior="padding"> */}
                {/* <View style={{ height: 30 }} /> */}
                <View style={styles.container}  >
                  <View borderRadius={100} style={{ width: 175, height: 175, padding: 4, alignSelf: 'center', backgroundColor: '#cf9740' }}  >
                    <Image source={logo} borderRadius={Platform.OS == 'ios' ? 80 : 100} style={{ width: 166, height: 166, alignSelf: 'center' }} />
                  </View>
                  <Text style={styles.title}>THIRD WITNESS</Text>
                  <Form ref="form"
                    onChange={this.onChangeForm}
                    value={this.state.value}
                    options={this.options}
                    type={this.UserLogin} />
                  <TouchableHighlight style={styles.button} onPress={this._loginSubmit} underlayColor='#8b650b'>
                    <Text style={styles.buttonText}>LOGIN</Text>
                  </TouchableHighlight>
                  <View style={styles.textBlcok} >
                    <Text onPress={() => {
                      this.props.navigation.navigate('Registration');
                    }} style={styles.newText}>
                      New User
                    </Text>

                  </View>
                  {/* <View style={{ height: 100 }} /> */}
                  {/* </KeyboardAvoidingView> */}
                </View>

              </ScrollView>
          }
        </LinearGradient>
      </View>
    );
  }
}


const mapStateToProps = (state) => {
  return {
    notificationNav: state.notificationNav,
    services: state.services,
    user: state.users
  }
}

const mapDispatchToProps = (dispatch) => {
  return {
    addNavigationData: (data) => dispatch(addNavigationData(data)),
    addRouterNavigation: (nav) => dispatch(addRouterNavigation(nav)),
    login: (userData) => dispatch(login(userData))
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(Login);

const styles = StyleSheet.create({
  linearGradient: {
    flex: 1,
    paddingTop: 20,
    paddingBottom: 10
  },
  container: {
    justifyContent: 'center',
    marginTop: 0,
    paddingTop: 0,
    paddingLeft: 60,
    paddingRight: 60,
    paddingBottom: 20,
    flex: 1
  },
  title: {
    fontSize: 20,
    alignSelf: 'center',
    marginBottom: 30,
    color: 'white',
    paddingTop: 20
  },
  buttonText: {
    fontSize: 18,
    color: 'white',
    alignSelf: 'center',
    height: (Platform.OS == 'ios') ? 40 : 30,
    paddingTop: (Platform.OS == 'ios') ? 7 : 0,
  },
  button: {
    paddingTop: (Platform.OS == 'ios') ? 15 : 5,
    paddingBottom: (Platform.OS == 'ios') ? 15 : 5,
    backgroundColor: '#cf9740',
    borderWidth: 0,
    borderRadius: 50,
    marginBottom: 10,
    marginTop: 20,
    borderRadius: 100,
    alignSelf: 'stretch',
    justifyContent: 'center',
  },
  textBlcok: {
    flex: 1,
    flexDirection: 'row',
    alignSelf: 'center',
  },
  newText: {
    fontSize: 14,
    alignSelf: 'center',
    fontWeight: 'normal',
    marginTop: 10,
    color: '#cf9740',
    textDecorationLine: 'underline',
    paddingLeft: 5,
    paddingRight: 5,

  },
  inputForm: {
    flex: 1,
    paddingRight: 10,
    paddingLeft: 0,
    color: '#cf9740',
    borderWidth: 0
  },

  inputSection: {
    borderBottomColor: '#bbb',
    borderBottomWidth: 1,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    flex: 0.9,
    marginBottom: 12
  },
  inputIcon: {
    flex: 0.1,

    alignItems: 'center',
    paddingRight: Platform.OS == 'ios' ? 10 : 0,
    marginTop: Platform.OS == 'ios' ? 0 : 15,
  },
  errorText: {

    justifyContent: 'center',
    alignSelf: 'flex-end',
  }
});
