import React from 'react';
import { connect } from 'react-redux';
import config from '../config/';
import axios from 'axios';
import Loader from './Loader';
import { Image, Platform, Text, TouchableOpacity, View, ScrollView, StyleSheet } from 'react-native';
import IconMaterial from 'react-native-vector-icons/MaterialCommunityIcons';
import Toast from 'react-native-easy-toast';
class SendAudio extends React.Component {
    constructor(props) {
        super(props);
        const userDetails = this.props.navigation.state.params || null;
        this.state = {
            loading: false,
            userDetails,
            audios: []
        };
        if (!userDetails) {
            this.props.navigation.navigate('UsersListing');
        }

        this.sendAudio = this.sendAudio.bind(this);
    }

    componentWillMount() {
        const self = this;
        self.setState({ loading: true });
        axios.get(config.mobApiUrl + 'audios/list')
            .then(function (response) {
                self.setState({ loading: false });
                if (response.data.status == 200) {
                    self.setState({ audios: response.data.data });
                }
            })
            .catch(function (error) {
                self.setState({ loading: false });
            });
    }

    sendAudio(audioDetail) {
        const self = this,
            sender = self.props.user,
            receiver = self.state.userDetails,
            postData = {
                audio_id: audioDetail._id,
                sender_id: sender._id,
                receiver_id: receiver._id
            };
        self.setState({ loading: true });
        axios.post(config.mobApiUrl + 'audios/sendAudio', postData)
            .then(function (response) {
                self.setState({ loading: false }, () => {
                    self._showToast(response.data.message);
                    const socketData = {
                        receiver: {
                            deviceInfo: receiver.deviceInfo,
                            email: receiver.email,
                            name: receiver.name,
                            type: receiver.type
                        },
                        sender: {
                            email: sender.email,
                            name: sender.name,
                            type: sender.type
                        },
                        audioDetail
                    };
                    self.props.services.sendAudio(socketData);
                });
            })
            .catch(function (error) {
                self._showToast('An unexpected error occurred. Please try again!');
                self.setState({ loading: false });
            });
    }

    _showToast(msg, duration = 750) {
        this.refs.toast.show(msg, duration);
    }

    render() {
        const audios = this.state.audios;
        return (
            <View>
                <Toast ref="toast" position="center" />
                <Loader loading={this.state.loading} />
                {
                    audios.length ?
                        <ScrollView keyboardShouldPersistTaps="always">
                            {audios.map((item, i) =>
                                <View key={i}>
                                    <View key={i} onPress={() => this.showHideDetailModal(item)} style={styles.singlelist}>
                                        <View style={{ flexDirection: 'row' }}>
                                            {/* <View style={styles.imageContainer}>
                                                <IconMaterial name="play" size={16} color="#fff" />
                                            </View> */}
                                            <View style={{ marginLeft: 12, paddingTop: 5 }}>
                                                <Text style={styles.subject}>{item.displayname}</Text>
                                            </View>
                                            <TouchableOpacity style={styles.sendBtn} onPress={() => this.sendAudio(item)}><Text style={{ color: '#fff' }}>Send</Text></TouchableOpacity>
                                        </View>
                                    </View>
                                </View>
                            )}
                        </ScrollView>
                        :
                        <View style={{ padding: 10 }}><Text style={{ color: '#cf9740' }}>{this.state.loading ? 'Loading...' : 'No audio available!'}</Text></View>
                }
            </View>
        )
    }
}

const mapStateToProps = (state) => {
    return {
        user: state.users,
        services: state.services
    }
}

export default connect(mapStateToProps)(SendAudio);

var styles = StyleSheet.create({
    singlelist: {
        borderRadius: 0,
        padding: 10,
        backgroundColor: '#fff',
        marginBottom: 0,
        marginLeft: 0,
        marginRight: 0,
        marginTop: 0,
        borderBottomWidth: 1,
        borderColor: '#eaeaea'
    },
    imageContainer: {
        padding: 8,
        borderRadius: 20,
        backgroundColor: '#244576'
    },
    sendBtn: {
        backgroundColor: '#244576',
        paddingTop: 5,
        paddingLeft: 10,
        paddingRight: 10,
        paddingBottom: 5,
        borderRadius: 2
    }
});
