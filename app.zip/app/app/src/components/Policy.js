import React, { Component } from 'react';
import {
  Button, Text, View, StyleSheet, ImageBackground, AsyncStorage, ScrollView,
} from 'react-native';
import { connect } from 'react-redux';
import { FormLabel, FormInput } from 'react-native-elements';
import Icon from 'react-native-vector-icons/FontAwesome';
import Loader from './Loader';
import LinearGradient from 'react-native-linear-gradient';


class Policy extends React.Component {
  static navigationOptions = {
    title: 'Policy/Privacy',
  };

  constructor(props) {
    super(props);
    this.state = { loading: true };
  }

  componentWillMount() {
    // AsyncStorage.removeItem('email');
    AsyncStorage.getItem('email').then((value) => {
      if (value) {
        this.setState({ loader: false, logged: true, email: value })
      } else {
        this.setState({ loader: false })
      }
    })
  }
  testSocket() {
    this.props.services.testSocketMapping();
  }
  render() {
    return (
      <View style={{ flex: 1 }}>
        <LinearGradient colors={['#ffffff', '#cccccc']} style={styles.linearGradient}>
          <View style={{ flex: 1, alignSelf: 'stretch', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
            <Text style={{ fontWeight: 'bold', marginBottom: 10 }}>THIRD WITNESS (TWA) POLICY, PROCEDURE &amp; PRIVACY FOR THE PUBLIC</Text>
            <View style={styles.outerScroll}>
              <ScrollView keyboardShouldPersistTaps='always' style={styles.scrollstyle} >
                <Text style={{ fontWeight: 'bold' }}>Your Photo ID, license, insurance and any other personal
                     identifying information is not copied or retained in any form by
                     TWA. It is housed on your device for absolute control by you and
                confidentiality.{"\n"}{"\n"}</Text>
                <Text style={{ fontWeight: 'bold' }}>Please read carefully before proceeding with TWA Registration:{"\n"}{"\n"}</Text>
                <Text>1. TWA is not a social interaction application.{"\n"}{"\n"}</Text>
                <Text>2. TWA's primary purpose is to reduce the risk of LEO's and Citizen's
                  expressing violence and harm towards each other.{"\n"}{"\n"}</Text>
                <Text>3. TWA does not promote, judge, or in any way publicize any communication
                  or information submitted without prior written consent.{"\n"}{"\n"}</Text>
                <Text>4. TWA only accepts and retains relevant information (for a limited time) that
                   (a) reference events and communication between Law Enforcement and the
                   Public (b) reference events and communication that represent Law
                   Enforcement and/or the Public's safety and well-being as a result of contact
              with each other and (c) threaten National Security.{"\n"}{"\n"}</Text>
                <Text>5. TWA does not acknowledge events prior to, or after those depicted in
                recordings or submitted in photo or text.{"\n"}{"\n"}</Text>
                <Text>6. TWA does not interpret, infer, edit or otherwise embellish upon any data
                submitted. It only retains the absolute integrity of the material as submitted.{"\n"}{"\n"}</Text>
              </ScrollView>
            </View>
          </View>
        </LinearGradient>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    // flexDirection: 'column',
    // alignItems: 'stretch',
    // justifyContent: 'center',
  },
  linearGradient: {
    flex: 1,
    padding: 20

  },
  outerScroll: {
    borderRadius: 15,
    backgroundColor: '#eaeaea',
    flex: 1,
    padding: 20
  },
  scrollstyle: {

  },
  buttonText: {
    fontSize: 18,
    color: 'white',
    alignSelf: 'center'
  },
});

const mapStateToProps = (state) => {
  return {
    services: state.services
  }
}
export default connect(mapStateToProps)(Policy);