import React, { Component } from 'react';
import {
  Button, Text, View, StyleSheet, ImageBackground, AsyncStorage, Image, PermissionsAndroid
} from 'react-native';
import { connect } from 'react-redux';
import Loader from './Loader';
import profileImage from '../../image/user-default-profile.png';
import Geocoder from 'react-native-geocoder';
import IconMaterial from 'react-native-vector-icons/MaterialCommunityIcons';
import LinearGradient from 'react-native-linear-gradient';


class Home extends React.Component {
  static navigationOptions = {
    title: 'Home',
  };

  constructor(props) {
    super(props);
    this.state = {
      loading: true,
      initialPosition: 'unknown',
      lastPosition: 'unknown',
    };
    this.testSocket = this.testSocket.bind(this);
  }

  componentWillUnmount = () => {
    // navigator.geolocation.clearWatch(this.watchID);
  }

  //get current location
  _getDeviceLocation() {
    navigator.geolocation.getCurrentPosition(
      (position) => {
        // const initialPosition = JSON.stringify(position);
        // Position Geocoding
        var cord = {
          lat: position.coords.latitude,
          lng: position.coords.longitude
        };

        Geocoder.geocodePosition(cord).then(res => {
          const initialPosition = res[0].formattedAddress;
          this.setState({ initialPosition });
        })
          .catch(err => console.log(err))
      },
      (error) => {
        alert(error.message)
      },
      // { enableHighAccuracy: true, timeout: 20000, maximumAge: 10000 }
    );
    // this.watchID = navigator.geolocation.watchPosition((position) => {
    //   const lastPosition = JSON.stringify(position);
    //   this.setState({ lastPosition });
    // });
  }


  Capitalize(str, complete = false) {
    if (complete) {
      return str.toUpperCase();
    } else {
      return str.charAt(0).toUpperCase() + str.slice(1);
    }

  }


  componentWillMount() {
    this._getDeviceLocation();
    // AsyncStorage.removeItem('email');
    AsyncStorage.getItem('email').then((value) => {
      if (value) {
        this.setState({ loader: false, logged: true, email: value })
      } else {
        this.setState({ loader: false })
      }
    })
  }
  testSocket() {
    this.props.services.testSocketMapping();
  }
  render() {
    return (
      <View style={styles.container}>
        <View style={styles.profileSection}>
          <LinearGradient colors={['#244576', '#13253f']} style={styles.linearGradient2}>
            <View style={styles.headerContainer}>
              <View style={styles.imageContainer}>
                <Image source={profileImage} style={styles.profileImage} />
              </View>
              <Text style={styles.profileType}>
                {this.Capitalize(this.props.user.type, true)}
              </Text>
              <Text style={styles.profileName}>
                {this.Capitalize(this.props.user.fname + ' ' + this.props.user.lname)}
              </Text>
              <Text style={styles.profileEmail}>
                {this.props.user.email}
              </Text>
            </View>
          </LinearGradient>
        </View>
        <View style={styles.detailSection}>
          <View style={{ padding: 10, flex: 0.2 }}>
            <IconMaterial name="map-marker-outline" size={40} color="#cf9740" />
          </View>
          <View style={{ padding: 10, flex: 0.8 }} >
            <Text style={{ justifyContent: 'center', alignSelf: 'center' }}>
              {this.state.initialPosition}
            </Text>
          </View>
        </View>
      </View >
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'stretch',
  },
  profileSection: {
    flex: .5,
    backgroundColor: 'grey',
    justifyContent: 'flex-start',
    flexDirection: 'column',
  },
  detailSection: {
    flexDirection: 'row',
    justifyContent: 'center',
    height: 80,
    backgroundColor: '#ffffff',
    borderWidth: 1,
    borderColor: '#ddd',
    borderBottomWidth: 1,
    shadowColor: '#000',
    shadowOffset: { width: 1, height: 1 },
    shadowOpacity: 0.3,
    shadowRadius: 1,
    elevation: 1,
    marginLeft: 0,
    marginRight: 0,
    marginTop: 0
  },
  imageContainer: {
    width: 110,
    height: 110,
    borderRadius: 90,
    backgroundColor: '#fff',
    borderColor: '#cf9740',
    borderWidth: 3,
    alignSelf: 'center',
    justifyContent: 'center'
  },
  profileImage: {
    width: 106,
    height: 106,
    borderRadius: 90,
    alignSelf: 'center',
  },
  profileName: {
    alignSelf: 'center',
    color: '#fff',
    fontWeight: 'bold',
    paddingTop: 10,
  },
  profileEmail: {
    alignSelf: 'center',
    color: '#cf9740',
    fontWeight: 'bold',
  },
  profileType: {
    alignSelf: 'center',
    backgroundColor: '#cf9740',
    color: 'white',
    borderRadius: 5,
    paddingTop: 2,
    paddingBottom: 2,
    paddingRight: 10,
    paddingLeft: 10,
    marginTop: 10,
    fontWeight: 'bold',
  },

  linearGradient2: {
    flex: 1,
    paddingTop: 20,
    paddingBottom: 10,
    height: '100%',
    shadowColor: '#000',
    borderColor: '#ddd',
    borderBottomWidth: 1,
    shadowOffset: { width: 4, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 5,
  },


  image: {
    flexGrow: 1,
    height: null,
    width: null,
    alignItems: 'center',
    justifyContent: 'center',
  },
  paragraph: {
    color: '#fff',
    textAlign: 'center',
  },
});

const mapStateToProps = (state) => {
  return {
    user: state.users,
    services: state.services
  }
}
export default connect(mapStateToProps)(Home);