import React from 'react';
import { connect } from 'react-redux';
import axios from 'axios';
// import Autocomplete from 'react-native-autocomplete-input';
import Loader from '../Loader';
import {
    Button,
    Image,
    Modal,
    Platform,
    Text,
    TextInput,
    TouchableOpacity,
    View,
    ScrollView,
    StyleSheet
} from 'react-native';
import config from '../../config/';
import FilePickerModule from './../FilePickerModule';
import IconMaterial from 'react-native-vector-icons/MaterialCommunityIcons';
import LinearGradient from 'react-native-linear-gradient';
import MultiSelect from 'react-native-multiple-select';
import profileImage from '../../../image/user-default-profile.png';
import styles from './style';
import TabNavigator from 'react-native-tab-navigator';
import Toast from 'react-native-easy-toast';
import { updateHeaderTitle } from '../../actions/UserAction';
class VmailAll extends React.Component {
    constructor(props) {
        super(props);
        const params = this.props.navigation.state.params;
        this.state = {
            attachment: null,
            isFormSubmitted: false,
            loading: false,
            isFetchingVmail: false,
            query: '',
            receiver_email: params ? params.email : '',
            receivedVmails: [],
            selectedTab: 'inbox',
            selectedUsers: [],
            sentVmails: [],
            socket: this.props.services.getSocket(),
            showComposeModal: false,
            showDetailModal: false,
            users: [],
            tmpUsers: [],
            vmailReceiver: null,
            validationErrors: {},
            vmailDetail: [],
            // compose vmail fields
            receiver_id: '',
            sender_id: '',
            subject: '',
            message: ''
        };
        this.fetchVmails = this.fetchVmails.bind(this);
        this.removeAttachment = this.removeAttachment.bind(this);
        this.showHideDetailModal = this.showHideDetailModal.bind(this);
        this.sendVmail = this.sendVmail.bind(this);
        this.showHideComposeModal = this.showHideComposeModal.bind(this);
        this.onFileSelect = this.onFileSelect.bind(this);
        this.onUserSelect = this.onUserSelect.bind(this);
        this.props.updateHeaderTitle('V-Mail')
    }

    componentDidMount() {
        // call api
        this.fetchVmails(1);
    }

    _getTime(date) {
        return new Date(date).toLocaleTimeString('en-US', { hour12: true });
    }

    fetchVmails(type = 1) {
        const self = this,
            me = self.props.user;
        let params = { "receiver_id": me._id };
        if (type == 2) {
            params = { "sender_id": me._id };
        }
        self.setState({ isFetchingVmail: true, loading: true, selectedTab: type == 1 ? 'inbox' : 'sent' });
        axios.post(config.mobApiUrl + 'vmails/list', params)
            .then(function (response) {
                self.setState({ loading: false, isFetchingVmail: false });
                if (response.data.status == 200) {
                    type == 1 ? self.setState({ receivedVmails: response.data.data }) : self.setState({ sentVmails: response.data.data });
                }
            })
            .catch(function (error) {
                self.setState({ loading: false, isFetchingVmail: false });
            });
    }

    showHideDetailModal(data) {
        const self = this;
        if (data) {
            self.setState({ loading: true });
            axios.post(config.mobApiUrl + 'vmails/getDetailMsg', { 'id': data._id })
                .then(async function (response) {
                    self.setState({ loading: false });
                    if (response.data.status == 200) {
                        self.setState({ vmailDetail: response.data.data, showDetailModal: true });
                    }
                })
                .catch(function (error) {
                    self.setState({ loading: false });
                });
        } else {
            self.setState({ vmailDetail: [], showDetailModal: false });
        }
    }

    async showHideComposeModal(state) {
        const self = this;
        self.setState({ loading: true, selectedUsers: [], receiver_id: '', sender_id: '', subject: '', message: '', validationErrors: {}, attachment: null });
        await new Promise((resolve, reject) => {
            axios.post(config.mobApiUrl + 'users/getContactList', {
                user_id: self.props.user._id,
            })
                .then(function (response) {
                    self.setState({ loading: false });
                    if (response.data.status == 200) {
                        const dt = response.data.data.filter(u => u._id != self.props.user._id)
                        self.setState({ users: dt, tmpUsers: dt, showComposeModal: state});
                        resolve();
                    }
                })
                .catch(function (error) {
                    self.setState({ loading: false });
                    reject();
                });
        });
    }

    onFileSelect(promise) {
        const self = this;
        promise
            .then((res) => {
                self.setState({ attachment: res.data[0] });
            })
            .catch((err) => {
                //self._showToast('An unexpected error occurred. Please try again!');
            });
    }

    sendVmail() {
        const self = this,
            me = self.props.user,
            _st = self.state,
            errors = {};
        let isValid = true;
        self.setState({ isFormSubmitted: true });
        if (!_st.selectedUsers.length) {
            isValid = false;
            errors.receiver_email = 'Please select atleast one user';
        }
        if (!_st.subject.trim().length) {
            isValid = false;
            errors.subject = 'Subject can\'t be empty';
        } else {
            errors.subject = null;
        }
        if (!_st.message.trim().length) {
            isValid = false;
            errors.message = 'Message can\'t be empty';
        } else {
            errors.message = null;
        }
        self.setState({ validationErrors: errors });
        if (isValid) {
            self.setState({ loading: true });
            const receiverIds = self.state.selectedUsers.map(uid => uid),
                vmailObj = {
                    "sender_id": me._id,
                    "receiver_id": receiverIds,
                    "subject": _st.subject,
                    "message": _st.message
                };
            // check if there are attachments then save them first
            const attachment = self.state.attachment;
            if (attachment) {
                const { uri, type: mimeType, fileName } = this.state.attachment;
                const formData = new FormData();
                formData.append('file', { uri, type: mimeType, name: fileName });
                axios.post(config.apiUrl + 'uploadAttachments',
                    formData, {
                        headers: { 'content-type': 'multipart/form-data' }
                    }
                )
                    .then(function (response) {
                        if (response.status == 200) {
                            vmailObj.attachment = response.data.fileName;
                            self._saveVmail(vmailObj);
                        }
                    })
                    .catch(function (err) {
                        self._showToast('An unexpected error occurred. Please try again!');
                        self.setState({ loading: false });
                    });
            } else {
                self._saveVmail(vmailObj);
            }
        }
    }

    _showToast(msg, duration = 750) {
        this.refs.toast.show(msg, duration);
    }

    _saveVmail(formData) {
        const self = this,
            me = self.props.user;
        if (!formData.attachment) {
            self.setState({ loading: true });
        }
        axios.post(config.mobApiUrl + 'vmails/sendMsg', formData)
            .then(function (response) {
                self.setState({ loading: false });
                if (response.data.status == 200) {
                    self.setState({ selectedTab: 'sent', showComposeModal: false });
                    self.fetchVmails(2);
                    self._showToast('Message sent successfully', 1200);
                    let usersToNotify;
                    usersToNotify = [];
                    const selU = self.state.selectedUsers,
                        usrs = self.state.users;
                    for (let sucounter = 0; sucounter < selU.length; sucounter++) {
                        for (let ucounter = 0; ucounter < usrs.length; ucounter++) {
                            if (selU[sucounter] == usrs[ucounter]._id) {
                                usersToNotify.push(usrs[ucounter]);
                            }
                        }
                    }
                    usersToNotify.map((u) => {
                        const _u = Object.assign({}, formData, { sender: { _id: me._id, type: me.type, email: me.email, name: me.name, fname: me.fname, lname: me.lname } });
                        _u.receiver = {
                            _id: u._id,
                            type: u.type,
                            email: u.email,
                            name: u.name,
                            deviceInfo: u.deviceInfo
                        };
                        self.state.socket.emit('send_vmail', _u);
                    });
                }
            })
            .catch(function (error) {
                self.setState({ loading: false });
            });
    }

    onUserSelect(selectedUsers) {
        this.setState({ selectedUsers });
    }

    downloadDoc(source) {
        Linking.openURL(source);
    }

    removeAttachment() {
        this.setState({ attachment: null });
    }

    renderFileIcon(source) {
        if (source) {
            if (typeof source === 'string') {
                const fileExt = source.split('.').pop();
                let fileUri = 'https://twaapi.herokuapp.com/attachments/' + source;
                if (['docx', 'doc', 'xls', 'xlsx'].indexOf(fileExt) > -1) {
                    return (<IconMaterial onPress={() => this._downloadDoc(fileUri)} name="file-document" size={40} color="#000" />)
                } else if (fileExt == 'pdf') {
                    return (<IconMaterial onPress={() => this._downloadDoc(fileUri)} name="file-pdf" size={40} color="#000" />)
                } else {
                    return (<TouchableOpacity onPress={() => this._downloadDoc(fileUri)}><Image source={{ uri: fileUri }} resizeMethod="scale" style={{ height: 100, width: 100 }} /></TouchableOpacity>)
                }
            } else {
                const fileExt = source.fileName.split('.').pop();
                if (['docx', 'doc', 'xls', 'xlsx'].indexOf(fileExt) > -1) {
                    return (<IconMaterial name="file-document" size={40} color="#000" />)
                } else if (fileExt == 'pdf') {
                    return (<IconMaterial name="file-pdf" size={40} color="#000" />)
                } else {
                    return (<TouchableOpacity ><Image source={source} resizeMethod="scale" style={{ height: 100, width: 100 }} /></TouchableOpacity>)
                }
            }
        }
    }

    renderComposeModal() {
        const err = this.state.validationErrors,
            attachment = this.state.attachment ? this.state.attachment : null;
        return (
            <Modal
                animationType="slide"
                transparent={false}
                visible={this.state.showComposeModal}
                onRequestClose={() => {
                }}>
                <LinearGradient colors={['#244576', '#13253f']} style={styles.linearGradient}>
                    <View style={{ flexDirection: 'row', backgroundColor: '#cf9740', height: 50, padding: 10 }} >
                        <Text style={styles.title}>Compose V-Mail</Text>
                        <TouchableOpacity style={styles.submitBtn}>
                            {
                                !attachment
                                    ?
                                    <FilePickerModule callback={this.onFileSelect} iconStyle={{ color: '#fff' }} isMultiple={false} isVideo={false} />
                                    :
                                    null
                            }
                        </TouchableOpacity>
                        <TouchableOpacity onPress={this.sendVmail} style={styles.submitBtn}>
                            <IconMaterial name="send" size={30} color="#fff" />
                        </TouchableOpacity>
                        <TouchableOpacity onPress={() => this.showHideComposeModal(false)} style={styles.submitBtn}>
                            <IconMaterial name="close" size={30} color="#fff" />
                        </TouchableOpacity>
                    </View>
                    <View style={styles.multiselectcontainer}>
                        <ScrollView keyboardShouldPersistTaps="always">
                            {
                                this.state.userInfo ?
                                    <View>
                                        <TextInput
                                            style={styles.textbox}
                                            placeholder="Receiver's Email"
                                            underlineColorAndroid={'transparent'}
                                            placeholderTextColor="#888"
                                            onChangeText={(text) => this.setState({ receiver_email: text })}
                                            editable={false}
                                            value={this.state.receiver_email}
                                        />
                                        <Text style={styles.error}>{err.receiver_email ? err.receiver_email : null}</Text>
                                    </View>
                                    :
                                    <View>
                                        <MultiSelect
                                            hideTags
                                            items={this.state.users}
                                            uniqueKey="_id"
                                            autoFocusInput={false}
                                            ref={(component) => { this.multiSelect = component }}
                                            onSelectedItemsChange={this.onUserSelect}
                                            selectedItems={this.state.selectedUsers}
                                            selectText="Select Users"
                                            searchInputPlaceholderText="Search Users..."
                                            onChangeInput={(text) => this.setState({ query: text })}
                                            //altFontFamily="ProximaNova-Light"
                                            tagRemoveIconColor="#CCC"
                                            tagBorderColor="#CCC"
                                            tagTextColor="#CCC"
                                            selectedItemTextColor="#CCC"
                                            selectedItemIconColor="#CCC"
                                            itemTextColor="#000"
                                            displayKey="name"
                                            searchInputStyle={{ backgroundColor: 'transparent', padding: 10 }}
                                            submitButtonColor="#cf9740"
                                            submitButtonText="Done"
                                        />
                                        <Text style={styles.error}>{err.receiver_email ? err.receiver_email : null}</Text>
                                    </View>
                            }
                            <TextInput
                                ref={ref => subjectInput = ref}
                                underlineColorAndroid={'transparent'}
                                style={styles.textbox}
                                placeholder="Subject"
                                placeholderTextColor="#888"
                                onChangeText={(text) => this.setState({ subject: text })}
                                value={this.state.subject}
                            />
                            <Text style={styles.error}>{err.subject ? err.subject : null}</Text>
                            <TextInput
                                placeholder="Message"
                                underlineColorAndroid={'transparent'}
                                placeholderTextColor="#888"
                                multiline={true}
                                onChangeText={(text) => this.setState({ message: text })}
                                value={this.state.message}
                                style={styles.textArea}
                            />
                            <Text style={styles.error}>{err.message ? err.message : null}</Text>
                            {
                                attachment
                                    ?
                                    <View style={styles.attachmentContainer}>
                                        <View style={styles.attachmentBox}>
                                            <TouchableOpacity style={styles.removeAttachment} onPress={this.removeAttachment}>
                                                <IconMaterial name="delete" size={15} color="#fff" />
                                            </TouchableOpacity>
                                            {this.renderFileIcon(attachment)}
                                        </View>
                                    </View>
                                    :
                                    null
                            }

                        </ScrollView>
                    </View>
                </LinearGradient>
            </Modal>
        );
    }

    renderDetailModal() {
        const _st = this.state,
            dt = _st.vmailDetail;
        return (
            <Modal
                animationType="slide"
                transparent={false}
                visible={_st.showDetailModal}
                onRequestClose={() => {
                }}>
                <View style={{ flex: 1, paddingTop: 20 }}>
                    {
                        dt.length ?
                            <ScrollView style={{ padding: 15 }}>
                                <View>
                                    <Text style={styles.modalsub}>{dt[0].subject}</Text>
                                </View>
                                <View style={{ flexDirection: 'row' }}>
                                    <View style={styles.imageContainer}>
                                        <Text style={styles.senderSlot}>{dt[0].sender.name.slice(0, 1).toUpperCase()}</Text>
                                    </View>
                                    <View style={{ marginLeft: 12, flex: 0.8 }}>
                                        <Text>From: {dt[0].sender.name + ' <' + dt[0].sender.email + '>'}</Text>
                                        <Text>To: {dt[0].receiver.name + ' <' + dt[0].receiver.email + '>'}</Text>
                                        <Text style={styles.messageTime}>{this._getTime(dt[0].doc)} </Text>
                                    </View>
                                </View>
                                <View style={styles.modalsubsm}>
                                    <Text style={{ color: 'blue', paddingBottom: 10 }}>{dt[0].subject}</Text>
                                    <Text>{dt[0].message}</Text>
                                </View>
                            </ScrollView>
                            :
                            <Text>No detail found</Text>
                    }
                    <TouchableOpacity style={styles.modalClose} onPress={() => this.showHideDetailModal()}>
                        <IconMaterial name="close" size={15} color="#333" />
                    </TouchableOpacity>
                </View>
            </Modal>
        );
    }

    renderVmails() {
        const _st = this.state,
            vmails = _st.selectedTab == 'inbox' ? _st.receivedVmails : _st.sentVmails;
        return (
            <View >
                {
                    vmails.length ?
                        <ScrollView keyboardShouldPersistTaps="always">
                            {vmails.map((item, i) =>
                                <TouchableOpacity key={i} onPress={() => this.showHideDetailModal(item)} style={styles.singlelist}>
                                    <View style={{ flexDirection: 'row' }}>
                                        <View style={styles.imageContainer}>
                                            <Text style={styles.senderSlot}>{item.subject.slice(0, 1).toUpperCase()}</Text>
                                        </View>
                                        <View style={{ marginLeft: 12, flex: 0.8 }}>
                                            <View style={{ flexDirection: 'row' }}>
                                                <View style={{ flex: 0.7 }}>
                                                    <Text style={styles.sender}>{this.state.selectedTab == 'inbox' ? item.sender.name : 'You'}</Text>
                                                </View>
                                                <View style={{ flex: 0.3 }}>
                                                    <Text style={styles.messageTime}>{this._getTime(item.doc)} </Text>
                                                </View>
                                            </View>
                                            <View>
                                                <Text style={styles.subject} numberOfLines={1}>{item.subject}</Text>
                                                <Text style={styles.message} numberOfLines={1} >{item.message}</Text>
                                            </View>
                                        </View>
                                    </View>
                                </TouchableOpacity>
                            )}
                        </ScrollView>
                        :
                        <View style={{ padding: 10 }}><Text style={{ color: '#cf9740' }}>{this.state.isFetchingVmail ? 'Loading...' : 'No record found!'}</Text></View>
                }
            </View>
        );
    }

    _showToast(msg, duration = 750) {
        this.refs.toast.show(msg, duration);
    }

    renderToast() {
        return <Toast ref="toast" />;
    }

    render() {
        return (
            <View style={{ paddingTop: 20, paddingLeft: 20, paddingRight: 20, flex: 1 }}>
                <Toast ref="toast" />
                <Loader loading={this.state.loading} />
                {this.renderComposeModal()}
                {this.renderDetailModal()}
                {this.renderToast()}
                <TabNavigator
                    tabBarStyle={{ top: 0, padding: 0, borderColor: '#ccc', borderRadius: 5, backgroundColor: '#244576' }}
                    sceneStyle={{ paddingTop: 50 }}
                >
                    <TabNavigator.Item
                        titleStyle={{ color: "#ffffff", padding: 5, fontSize: 15, borderBottomWidth: 3, borderColor: '#244576' }}
                        selectedTitleStyle={{ color: "#cf9740", borderBottomWidth: 3, borderColor: '#cf9740', padding: 5, fontSize: 15 }}
                        selected={this.state.selectedTab === 'inbox'}
                        title="Inbox"
                        onPress={() => this.fetchVmails(1)}>
                        {this.renderVmails()}
                    </TabNavigator.Item>
                    <TabNavigator.Item
                        selected={this.state.selectedTab === 'sent'}
                        titleStyle={{ color: "#ffffff", padding: 5, fontSize: 15, borderBottomWidth: 3, borderColor: '#244576' }}
                        selectedTitleStyle={{ color: "#cf9740", borderBottomWidth: 3, borderColor: '#cf9740', padding: 5, fontSize: 15 }}
                        title="Sent"
                        onPress={() => this.fetchVmails(2)}>
                        {this.renderVmails()}
                    </TabNavigator.Item>
                </TabNavigator>
                <TouchableOpacity style={styles.compose} onPress={() => this.showHideComposeModal(true)}>
                    <IconMaterial name="plus" size={20} color="#fff" />
                </TouchableOpacity>
            </View>
        );
    }
}

const mapStateToProps = (state) => {
    return {
        user: state.users,
        services: state.services
    }
}
const mapDispatchToProps = (dispatch) => {
    return {
        updateHeaderTitle: (headerTitle) => dispatch(updateHeaderTitle(headerTitle))
    }
}
export default connect(mapStateToProps, mapDispatchToProps)(VmailAll);
