import { StyleSheet } from 'react-native';
import config from "../../config/";
export default StyleSheet.create({
    attachmentContainer: {
        flex: 1,
        flexDirection: 'row',
        paddingTop: 20,
        paddingBottom: 20
    },
    attachmentBox: {
        flexDirection: 'row',
        padding: 10,
        height: 80,
        width: 80,
        marginRight: 5,
    },
    title: {
        fontSize: 22,
        color: 'white',
        justifyContent: 'center',
        alignItems: 'center',
        alignSelf: 'center',
        alignContent: 'center',
      
        flex:0.7
    },
    singlelist: {
        borderRadius: 0,
        padding: 10,
        backgroundColor: '#fff',
        marginBottom: 0,
        marginLeft: 0,
        marginRight: 0,
        marginTop: 0,
        borderBottomWidth: 1,
        borderColor: '#eaeaea'
    },
    compose: {
        position: 'absolute',
        bottom: 30,
        right: 10,
        padding: 10,
        borderRadius: 20,
        backgroundColor: '#244576'
    },
    removeAttachment: {
        padding: 5,
        position: 'absolute',
        backgroundColor: '#cf9740',
        top: -5,
        right: -40,
        borderRadius: 15,
        zIndex: 1
    },
    error: {
        color: '#f00',
        fontSize: 15,
        alignSelf: 'flex-end',
        marginBottom:5,
        paddingBottom:10
    },
    linearGradient: {
        flex: 1,
        padding: 0
    },
    submitBtn: {
               
        flex: .1,      
        
    },
    iconattach:{
 flex: .1,   
    },
    textbox: { color: '#cf9740', borderRadius: 5, backgroundColor: '#fff', marginBottom: 10, height: 50, flexDirection: 'row', borderColor: 'gray', borderWidth: 1, padding: 15 },
    textArea: { color: '#cf9740', borderRadius: 5, backgroundColor: '#fff', marginBottom: 10, flexDirection: 'row', borderColor: 'gray', borderWidth: 1, padding: 15, height: 150, alignItems: 'flex-start', textAlignVertical: 'top' },
    imageContainer: {
        width: 45,
        height: 50,
        borderRadius: 100,
        backgroundColor: '#244576',
        flex: 0.18,
        alignItems: 'center',
        justifyContent: 'center'
    },
    profileImage: {
        width: 25,
        height: 25,
        alignSelf: 'center',
        paddingTop: 10
    },
    profileName: {
        alignSelf: 'center',
        color: '#fff',
        fontWeight: 'bold',
        paddingTop: 10

    },
    senderSlot: {
        fontSize: 20,
        color: '#fff',
        fontWeight: 'bold',

    },
    sender: {
        fontSize: 16,
        fontWeight: 'bold',
        color: '#000000'
    },
    subject: {
        fontSize: 16,
        fontWeight: '300',
        color: '#000000'
    },
    message: {
        fontSize: 10,
        color: 'grey'
    },
    messageTime: {
        fontSize: 10,
        fontWeight: 'bold',
        color: '#cf9740'
    },
    modalClose: {
        position: 'absolute',
        top: 15,
        right: 15,
        padding: 8,
        borderRadius: 20,
        backgroundColor: '#CCC'
    },
    multiselectcontainer: {
        flex: 1,
        padding: 15
    },
    modalsub: {
        fontSize: 28,
        fontWeight: 'bold',
        color: '#000000',
        borderBottomColor: '#ccc',
        borderBottomWidth: 1,
        marginBottom: 10,
        paddingBottom: 10

    },
    modalsubsm: {
        margin: 10,
        padding: 10

    }
});
