import React, { Component } from 'react';
import {
  Button, Text, View, StyleSheet, ImageBackground, AsyncStorage, ScrollView,
} from 'react-native';
import { connect } from 'react-redux';
import { FormLabel, FormInput } from 'react-native-elements';
import Icon from 'react-native-vector-icons/FontAwesome';
import Loader from './Loader';
import LinearGradient from 'react-native-linear-gradient';


class About extends React.Component {
  static navigationOptions = {
    title: 'About',
  };

  constructor(props) {
    super(props);
    this.state = { loading: true };
  }

  componentWillMount() {
    // AsyncStorage.removeItem('email');
    AsyncStorage.getItem('email').then((value) => {
      if (value) {
        this.setState({ loader: false, logged: true, email: value })
      } else {
        this.setState({ loader: false })
      }
    })
  }
  testSocket() {
    this.props.services.testSocketMapping();
  }
  render() {
    return (
      <View style={{ flex: 1 }}>
        <LinearGradient colors={['#ffffff', '#cccccc']} style={styles.linearGradient}>
          <View style={{ flex: 1, alignSelf: 'stretch', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
            <Text style={{ fontWeight: 'bold', marginBottom: 10 }}>Our Mission</Text>
            <View style={styles.outerScroll}>
              <ScrollView keyboardShouldPersistTaps='always' style={styles.scrollstyle} >
                <Text>Third Witness Application's (TWA) primary mission is to save the lives of Law Enforcement Officers
                    and Citizens. TWA proposes to use technology to reduce Law Enforcement's exposure to violence
                    and harm, and modify Citizen's behavior that threaten, disrespect, and provoke an undesirable
                    response from Law Enforcement that results in the use of excessive force and death for many
                Citizens.{"\n"}{"\n"}</Text>
                <Text>Recent events have greatly escalated the threat to Law Enforcement to the extent that they are
                      targets of violence by terrorists, criminals, the mentally ill, and political extremists. A significant
                      segment of the public does not like or trust, and has a significant fear of, the police. This fear and
                      mistrust results in behavior that is disrespectful, offensive, and provocative to Law Enforcement, often
                      resulting in physical and fatal conflicts between the Police and common Citizens.{"\n"}{"\n"}</Text>
                <Text>The paradox is that although the Police are often feared, they are recognized as essential to protect
                      our safety and well-being from criminal elements in our society. It is the extreme elements in the
                      general population and in Law Enforcement that have created the sentiment of fear and anger
                      between Law Enforcement and Citizens.{"\n"}{"\n"}</Text>
                <Text>There is no way to effectively reduce the tension between Law Enforcement and Citizens by
                      continuing to exercise traditional procedures. New procedures and protocols have to be implemented
                      to neutralize the fear, anger and prejudice that exist between Law Enforcement and the General
                      Population and to reduce the mutual threat of violence between Law Enforcement and the Public.
                      TWA proposes to use technology as an alternative to supplement the status quo, that will reduce the
                      risk of harm for both Law Enforcement Officers and Citizens.{"\n"}{"\n"}</Text>

              </ScrollView>
            </View>
          </View>
        </LinearGradient>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    // flexDirection: 'column',
    // alignItems: 'stretch',
    // justifyContent: 'center',
  },
  linearGradient: {
    flex: 1,
    padding: 20

  },
  outerScroll: {
    borderRadius: 15,
    backgroundColor: '#eaeaea',
    flex: 1,
    padding: 20
  },
  scrollstyle: {

  },
  buttonText: {
    fontSize: 18,
    color: 'white',
    alignSelf: 'center'
  },
});

const mapStateToProps = (state) => {
  return {
    services: state.services
  }
}
export default connect(mapStateToProps)(About);