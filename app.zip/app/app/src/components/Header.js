import React, { Component } from 'react';
import {
  AsyncStorage,
  Button,
  ImageBackground,
  Platform,
  StyleSheet,
  Text,
  TouchableOpacity,
  View
} from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome';
import { showPopup } from '../actions/LayoutAction';
import { StackActions, NavigationActions, DrawerActions } from 'react-navigation';
import { connect } from 'react-redux';
import { logout } from '../actions/UserAction';
import IconMaterial from 'react-native-vector-icons/MaterialCommunityIcons';

class Header extends React.Component {
  constructor(props) {
    super(props);
    this.state = { menuPopUp: false };
    this.logout = this.logout.bind(this);
    this.goBack = this.goBack.bind(this);
    this.openDrawer = this.openDrawer.bind(this);
  }

  openDrawer() {
    this.props.nav.dispatch(DrawerActions.openDrawer());
  }

  goBack() {
    const backStatus = this.props.nav.goBack(null);
    if (backStatus) {
      // refresh the screen when go back
      if (this.props.nav.state.params && this.props.nav.state.params.refresh) {
        this.props.nav.state.params.refresh();
      }
    } else {
      // if we launch on any random screen after login because of push notifications then go to UsersListing page when back is pressed
      const resetAction = StackActions.reset({
        index: 0,
        actions: [NavigationActions.navigate({ routeName: 'UsersListing' })]
      });
      this.props.nav.dispatch(resetAction);
    }
  }

  logout() {
    const _p = this.props;
    AsyncStorage.removeItem('localUserInfo');
    _p.services.logout();
    _p.logout();
    const resetAction = StackActions.reset({
      index: 0,
      actions: [NavigationActions.navigate({ routeName: 'Login' })],
    });
    _p.nav.dispatch(resetAction);
  }

  getHeaderTitle(title) {
    if (typeof title == 'string') {
      return title;
    } else if (this.props.user.headerTitle) {
      return this.props.user.headerTitle;
    } else {
      return 'TWA';
    }
  }

  render() {
    const showPopup = this.props.layout.showPopup;
    return (
      <View>
        <View style={styles.header}>
          <View style={{ flex: 1 }}>
            {this.props.hamburger ?
              <TouchableOpacity style={styles.headerLeft} onPress={() => this.openDrawer()}>
              <IconMaterial
                name="menu"
                color="#fff"
                size={22}
              />
              </TouchableOpacity>
              :
              <TouchableOpacity style={styles.headerLeft} onPress={this.goBack}>
              <IconMaterial
                name="arrow-left"
                color="#fff"
                size={22}
              />
              </TouchableOpacity>
            }
          </View>
          <View style={{ flex: 1, alignItems: 'center', minWidth: 200,justifyContent:'center' }}>
            <Text style={{ color: '#fff' }}>{this.getHeaderTitle(this.props.headerTitle)}</Text>
          </View>
          <View style={{ flex: 1,  paddingRight: 5, paddingBottom:5, paddingTop:15, alignItems: 'flex-end' ,justifyContent:'center'}}>
            <IconMaterial name="logout" size={20} color="#fff" onPress={this.logout} />
          </View>
        </View>
        {
          showPopup ?
            <TouchableOpacity onPress={this.logout} ref="header-menu" style={{ flex: 1, position: 'absolute', elevation: 11, backgroundColor: '#fff', right: 20, top: 40 }}>
              <Text style={styles.navItemStyle} >Logout</Text>
            </TouchableOpacity>
            : null
        }
      </View>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    services: state.services,
    user: state.users,
    layout: state.layout
  }
}

const mapDispatchToProps = (dispatch) => {
  return {
    logout: () => dispatch(logout()),
    showPopup: (isShowPopup) => dispatch(showPopup(isShowPopup))
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(Header);

const styles = StyleSheet.create({
  headerLeft: { paddingTop:15,paddingBottom:10, paddingLeft:5,justifyContent:'center'  },
  header: {
    height: 50,
    backgroundColor: '#244576',
    padding: 0,
    alignSelf: 'stretch',
    // flex:1,
    marginTop: (Platform.OS === 'ios') ? 20 : 0,
    flexDirection: 'row'
  },
  navItemStyle: {
    color: '#000',
    padding: 10,
    fontSize: 20,
    borderBottomWidth: 1,
    borderColor: '#171819'
  },
});
