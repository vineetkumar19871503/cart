import React, { Component } from 'react';
import {
  BackHandler,
  StyleSheet,
  Text,
  View,
  Image,
  TouchableOpacity,
  Platform,
  Alert
} from 'react-native';
import config from '../config/';
import axios from 'axios';
import Icon from 'react-native-vector-icons/FontAwesome';
import IconMaterial from 'react-native-vector-icons/MaterialCommunityIcons';
import { connect } from 'react-redux';
import profileImage from '../../image/user-default-profile.png';
import { updateRemoteUser, updateCallState, updateCallType, updateJoinState, updateRoomId } from '../actions/CallAction';
import LinearGradient from 'react-native-linear-gradient';
import { NavigationActions } from 'react-navigation';
import Toast from 'react-native-easy-toast';
import Loader from './Loader';
import Footer from './Footer';
import { updateHeaderTitle } from '../actions/UserAction';

class UsersDetailScreen extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      loading: false,
      myContacts: [],
      contactExists: false,
      isOnline: false,
      paramUser: {},
      socketIO: null,
      tempRefreshState: false // to update the dummy state for refreshing when navigation.goBack is called
    };
    this.goToRecordedAudios = this.goToRecordedAudios.bind(this);
    this.bindSocketEvents = this.bindSocketEvents.bind(this);
    this.navigateToVmail = this.navigateToVmail.bind(this);

  }
  static navigationOptions = { title: 'User Detail' };
  async componentWillMount() {
    const self = this,
      paramUser = this.props.navigation.state.params,
      socketIO = self.props.services.getSocket();
    self.setState({ paramUser, socketIO });
    self.props.services.checkOnlineStatus(paramUser.email, function (isOnline) {
      self.setState({ isOnline });
    });
    BackHandler.addEventListener('hardwareBackPress', self.backPressed);
    await self.getUserContacts();
  }

  componentDidMount() {
    this.bindSocketEvents();
    this._setHeaderTitle();
  }

  componentWillUnmount() {
    BackHandler.removeEventListener('hardwareBackPress', this.backPressed);
  }

  bindSocketEvents() {
    const self = this,
      socket = this.state.socketIO;
    socket.on('user_connected', function (user) {
      if (user) {
        if (user.email == self.state.paramUser.email) {
          self.setState({ isOnline: true });
        }
      }
    });

    socket.on('user_disconnected', function (user) {
      if (user) {
        if (user.email == self.state.paramUser.email) {
          self.setState({ isOnline: false });
        }
      }
    });
  }

  backPressed = () => {
    if (this.props.navigation.state.params && this.props.navigation.state.params.refresh) {
      this.props.navigation.state.params.refresh();
    }
    this.props.navigation.goBack();
    return true;
  }

  makeCall(user) {

    const self = this;
    const _p = self.props;
    if (_p.call.callState != null) {
      self._showToast('You are already on a call');
    } else {
      const from = _p.user,
        roomId = self._generateRoomId();
      // dispatching action to update room id
      _p.updateRemoteUser(user);
      _p.updateCallState('calling');
      _p.updateCallType('call');
      _p.updateRoomId(roomId);
      _p.services.makeCall(from, user, roomId, 'call');
    }
    // self.props.services.checkOnlineStatus(user.email, function (isOnline) {
    //   if (isOnline) {
    //     const _p = self.props;
    //     if (_p.call.callState != null) {
    //       self._showToast('You are already on a call');
    //     } else {
    //       const from = _p.user,
    //         roomId = self._generateRoomId();
    //       // dispatching action to update room id
    //       _p.updateRemoteUser(user);
    //       _p.updateCallState('calling');
    //       _p.updateCallType('call');
    //       _p.updateRoomId(roomId);
    //       _p.services.makeCall(from, user, roomId, 'call');
    //     }
    //   } else {
    //     self._showToast('User is not online. Please try after some time')
    //   }
    // });
  }

  goToChatScreen(user) {
    const self = this;
    self.props.navigation.navigate('UserChat', user);
  }

  // getValueByRoomId(user) {
  //   const self = this;
  //   self.setState({
  //     loading: true
  //   });
  //   const _p = this.props;
  //   const from = {};
  //   from._id = _p.user._id;
  //   from.email = _p.user.email;
  //   const to = {};
  //   to._id = user._id;
  //   to.email = user.email;
  //   to.fname = user.fname;
  //   const userInfo = {};
  //   userInfo.from = from;
  //   userInfo.to = to;
  //   _p.services.getValueByRoomId(userInfo, function (roomData) {
  //     userInfo.roomData = roomData;
  //     self.setState({
  //       loading: false
  //     });
  //     self.props.navigation.navigate('UserChat', userInfo);
  //   });
  // }

  goToRecordedAudios(user) {
    this.props.navigation.navigate('SendAudio', user)
    // const self = this;
    // self.props.services.checkOnlineStatus(user.email, function (isOnline) {
    //   isOnline ? self.props.navigation.navigate('SendAudio', user) : self._showToast('User is not online. Please try after some time');
    // });
  }

  addToContact(userData) {
    const self = this;
    self.setState({
      loading: true
    });
    axios.post(config.mobApiUrl + 'users/saveUserContacts', {
      user_id: self.props.user._id,
      contact_id: userData._id
    })
      .then(function (response) {
        self.setState({
          loading: false
        });
        if (response.data.status == 200) {
          self.setState({ contactExists: true });
        }
        self._showToast(response.data.message);
      })
      .catch(function (error) {
        self.setState({ loading: false });
        self._showToast('An error occurred');
      });
  }

  getUserContacts() {
    const self = this;
    self.setState({ loading: true });
    axios.post(config.mobApiUrl + 'users/getContactList', {
      user_id: self.props.user._id,
    })
      .then(function (response) {
        self.setState({ loading: false });
        if (response.data.data && response.data.data.length) {
          const myContacts = response.data.data;
          self.setState({ myContacts });
          myContacts.map((c) => {
            if (c.user_id == self.props.user._id && self.state.paramUser._id == c.contact_id) {
              self.setState({ contactExists: true });
            }
          });
        }
      })
      .catch(function (error) {
        self.setState({ loading: false });
      });
  }

  navigateToVmail(user) {
    const self = this;
    user.refresh = () => {
      self._setHeaderTitle();
    }
    self.props.navigation.navigate('Vmail', user);
  }

  removeContact(user) {
    const self = this;
    Alert.alert(
      'Remove Contact',
      'Do you really want to remove this contact?',
      [
        { text: 'Cancel', onPress: () => console.log('Cancel Pressed'), style: 'cancel' },
        {
          text: 'Yes', onPress: () => {
            self.setState({ loading: true });
            axios.post(config.mobApiUrl + 'users/removeContact', {
              user_id: self.props.user._id,
              contact_id: user._id
            })
              .then(function (response) {
                self.setState({
                  loading: false
                });
                if (response.data.status == 200) {
                  self.setState({ contactExists: false });
                }
                self._showToast(response.data.message);
              })
              .catch(function (error) {
                self.setState({ loading: false });
                self._showToast('An error occurred');
              });
          }
        },
      ],
      { cancelable: false }
    )
  }

  _setHeaderTitle() {
    if (this.props.user.type == 'leo') {
      this.props.updateHeaderTitle(this.props.navigation.state.params.name);
    } else {
      this.props.updateHeaderTitle('LEO');
    }
  }

  _generateRoomId() {
    const possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    let text = "";
    for (var i = 0; i < 25; i++) {
      text += possible.charAt(Math.floor(Math.random() * possible.length));
    }
    return text;
  }

  renderToast() {
    return <Toast ref="toast" />;
  }

  _showToast(msg, duration = 750) {
    this.refs.toast.show(msg, duration);
  }

  Capitalize(str, complete = false) {
    if (complete) {
      return str.toUpperCase();
    } else {
      return str.charAt(0).toUpperCase() + str.slice(1);
    }
  }

  render() {
    const contactExists = this.state.contactExists,
      user = this.props.navigation.state.params,
      isLEO = this.props.user.type !== 'citizen' ? true : false;
    return (
      <View style={styles.container}>
        <Loader loading={this.state.loading} />
        {this.renderToast()}
        <LinearGradient colors={['#244576', '#13253f']} style={styles.linearGradient}>
          <View style={styles.headerContainer}>
            <View style={styles.imageContainer}>
              <Image source={profileImage} style={styles.profileImage} />
              <View style={this.state.isOnline ? styles.online : styles.offline}></View>
            </View>
            <View >
              <Text style={styles.profileType}>
                {this.Capitalize(user.type, true)}
              </Text>
              {(user.type === 'citizen') ?
                <View>
                  <Text style={styles.profileName}>
                    {this.Capitalize(user.fname + ' ' + user.lname)}
                  </Text>
                  <Text style={styles.profileEmail}>
                    {user.email}
                  </Text>
                </View>
                :
                <View>
                  <Text style={styles.profileBadge}>
                    <IconMaterial style={styles.blockIcon} name="trophy-award" size={30} color="#ffffff" />&nbsp;&nbsp;
                          {user.badgeno}</Text>
                </View>
              }
            </View>
          </View>
        </LinearGradient>
        <View style={{ flex: 0.6, flexDirection: 'column', backgroundColor: '#cf9740' }}>
          <View style={{ flex: 1, flexDirection: 'row' }}>
            {isLEO === true ?
              <TouchableOpacity onPress={() => this.makeCall(user)} style={styles.buttonCall}>
                <View style={styles.blockInner}>
                  <Icon style={styles.blockIcon} name="video-camera" size={50} color="#fff" />
                  <Text style={styles.blockText}>Video Call</Text>
                </View>
              </TouchableOpacity>
              :
              null
            }
            <TouchableOpacity onPress={() => this.goToRecordedAudios(user)} style={styles.recordedAudios}>
              <View style={styles.blockInner}>
                <IconMaterial style={styles.blockIcon} name="speaker" size={50} color="#fff" />
                <Text style={styles.blockText}>Recorded Audios</Text>
              </View>
            </TouchableOpacity>
          </View>
          <View style={{ flex: 1, flexDirection: 'row' }}>
            <TouchableOpacity onPress={() => this.goToChatScreen(user)} style={styles.buttonChat}>
              <View style={styles.blockInner}>
                <Icon style={styles.blockIcon} name="comments" size={50} color="#fff" />
                <Text style={styles.blockText}>Chat</Text>
              </View>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => this.navigateToVmail(user)} style={styles.buttonVmail}>
              <View style={styles.blockInner}>
                <Icon style={styles.blockIcon} name="envelope" size={50} color="#fff" />
                <Text style={styles.blockText}>V-Mail</Text>
              </View>
            </TouchableOpacity>
          </View>
          <View style={{ flex: 1, flexDirection: 'row' }}>
            <TouchableOpacity onPress={() => contactExists ? this.removeContact(user) : this.addToContact(user)} style={contactExists ? styles.removeContact : styles.addContact}>
              <View style={styles.blockInner}>
                <IconMaterial style={styles.blockIcon} name="contacts" size={50} color="#fff" />
                <Text style={styles.blockText}>{contactExists ? 'Remove Contact' : 'Add To Contact'}</Text>
              </View>
            </TouchableOpacity>
          </View>
        </View >
      </View >
    );
  }
}
const styles = StyleSheet.create({
  online: {
    height: 20,
    width: 20,
    borderRadius: 10,
    backgroundColor: '#0f0',
    position: 'absolute',
    top: 0,
    right: 0
  },
  offline: {
    height: 20,
    width: 20,
    borderRadius: 10,
    position: 'absolute',
    top: 0,
    right: 0,
    backgroundColor: '#f00'
  },
  linearGradient: {
    flex: 0.4,
    paddingTop: 20,
    paddingBottom: 10,
    borderBottomColor: '#cf9740',
    borderBottomWidth: 4
  },
  container: {
    paddingTop: 0,
    flex: 1,
    alignItems: 'stretch',
  },
  blockInner: {
    flex: 1,
    justifyContent: 'center',
  },
  blockIcon: {
    justifyContent: 'center',
    alignSelf: 'center',
  },
  buttonCall: {
    justifyContent: 'center',
    flex: 1,
    backgroundColor: '#f39c12',
    padding: 30,
    margin: 0,
    // borderRadius: 5,
  },
  recordedAudios: {
    justifyContent: 'center',
    flex: 1,
    backgroundColor: '#f1c40f',
    padding: 30,
    margin: 0,
    // borderRadius: 5,
  },
  addContact: {
    justifyContent: 'center',
    flex: 1,
    backgroundColor: '#27ae60',
    padding: 30,
    margin: 0,
    // borderRadius: 5,
  },
  removeContact: {
    justifyContent: 'center',
    flex: 1,
    backgroundColor: '#c0392b',
    padding: 30,
    margin: 0,
    // borderRadius: 5,
  },
  buttonChat: {
    justifyContent: 'center',
    flex: 1,
    backgroundColor: '#d35400',
    padding: 30,
    margin: 0,
    // borderRadius: 5,
  },
  buttonVmail: {
    justifyContent: 'center',
    flex: 1,
    backgroundColor: '#e67e22',
    padding: 30,
    margin: 0,
    // borderRadius: 5,
  },
  blockText: {
    justifyContent: 'center',
    fontSize: 11,
    color: '#fff',
    alignSelf: 'center',
  },
  headerContainer: {
    flexDirection: 'column',
    flex: 1,
  },
  imageContainer: {
    width: 110,
    height: 110,
    borderRadius: 90,
    backgroundColor: '#fff',
    borderColor: '#cf9740',
    borderWidth: 3,
    alignSelf: 'center',
    justifyContent: 'center'
  },
  profileImage: {
    width: 106,
    height: 106,
    borderRadius: Platform.OS == 'ios' ? 55 : 90,
    alignSelf: 'center',
  },
  profileName: {
    alignSelf: 'center',
    paddingTop: 10,
    color: 'white'
  },
  profileEmail: {
    alignSelf: 'center',
    color: '#cf9740',
    fontWeight: 'bold',
  },
  profileBadge: {
    alignSelf: 'center',
    color: '#cf9740',
    fontWeight: 'bold',
    marginTop: 7,
    fontSize: 22
  },
  profileType: {
    alignSelf: 'center',
    backgroundColor: '#cf9740',
    color: 'white',
    borderRadius: 5,
    paddingTop: 2,
    paddingBottom: 2,
    paddingRight: 10,
    paddingLeft: 10,
    marginTop: 10,
    fontWeight: 'bold',
  },
});

const mapStateToProps = (state) => {
  return {
    call: state.call,
    services: state.services,
    user: state.users
  }
}

const mapDispatchToProps = (dispatch) => {
  return {
    updateRemoteUser: (remoteUser) => dispatch(updateRemoteUser(remoteUser)),
    updateCallState: (callState) => dispatch(updateCallState(callState)),
    updateCallType: (type) => dispatch(updateCallType(type)),
    updateJoinState: (joinState) => dispatch(updateJoinState(joinState)),
    updateRoomId: (id) => dispatch(updateRoomId(id)),
    updateHeaderTitle: (headerTitle) => dispatch(updateHeaderTitle(headerTitle))
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(UsersDetailScreen);
