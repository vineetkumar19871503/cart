export function addRouterNavigation(nav) {
    return {
        type: 'ADD_ROUTER_NAVIGATION',
        payload: nav
    }
}

export function setCurrentScreen(screen) {
    return {
        type: 'SET_CURRENT_SCREEN',
        payload: screen
    }
}