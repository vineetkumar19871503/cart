export function login(userData = {}) {
    return {
        type: 'LOGIN',
        payload: userData
    }
}

export function logout() {
    return {
        type: 'LOGOUT'
    }
}

export function updateLocation(location) {
    return {
        type: 'UPDATE_LOCATION',
        payload: location
    }
}

export function updateChatData(chatData) {
    return {
        type: 'CHAT_DATA',
        payload: chatData
    }
}

export function deleteChatData(deleteChat) {
    return {
        type: 'DELETE_CHAT_DATA',
        payload: deleteChat
    }
}

export function updateHeaderTitle(headerTitle) {
    return {
        type: 'HEADER_TITLE',
        payload: headerTitle
    }
}