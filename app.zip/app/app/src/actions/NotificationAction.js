export function addNavigationData(data) {
    return {
        type: 'ADD_NAV_DATA',
        payload: data
    }
}
