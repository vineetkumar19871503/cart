import config from '../config/';
import { Platform } from 'react-native';
// const config = require('../config/app');
IS_BROWSER = (module == null || module.exports == null);
let WebRTC = null,
  onDataChannelMessageCallback = null,
  onMakeCall = null,
  onParticipantLeftCallback = null,
  onParticipantStreamAdded = null,
  onShowCallOptions = null,
  socket = null;

// if it is browser then get the rtc references from browser else require react-native-webrts for app
if (IS_BROWSER) {
  WebRTC = {
    getUserMedia: navigator.getUserMedia = navigator.getUserMedia || navigator.webkitGetUserMedia || navigator.mozGetUserMedia || navigator.msGetUserMedia,
    MediaStreamTrack: window.MediaStreamTrack,
    RTCPeerConnection: window.RTCPeerConnection,
    RTCSessionDescription: window.RTCSessionDescription,
    RTCIceCandidate: window.RTCIceCandidate
  }
  socket = io();
} else {
  WebRTC = require('react-native-webrtc');
  socket = require('socket.io-client')(config.socketServerUrl, { transports: ['websocket'], jsonp: false, 'forceNew': true });
}

const configuration = { "iceServers": [{ "url": "stun:stun.l.google.com:19302" }] },
  peerConnections = {}; //map of {socketId: socket.io id, RTCPeerConnection}
let localStream = null,
  participants = null, //list of {socketId, name}
  me = null; //{socketId, name}

// creating peerconnection and defining event callbacks
function createPeerConnection(participant, isOffer, onDataChannelMessage) {
  let socketId = participant.socketId;
  var retVal = new WebRTC.RTCPeerConnection(configuration);

  peerConnections[socketId] = retVal;
  retVal.onicecandidate = function (event) {
    if (event.candidate) {
      socket.emit('exchange', { 'to': socketId, 'candidate': event.candidate });
    }
  };

  function createOffer() {
    retVal.createOffer(function (desc) {
      retVal.setLocalDescription(desc, function () {
        socket.emit('exchange', { 'to': socketId, 'sdp': retVal.localDescription });
      }, logError);
    }, logError);
  }

  retVal.onnegotiationneeded = function () {
    if (isOffer) {
      createOffer({ offerToReceiveVideo: true, offerToReceiveAudio: true });
    }
  }

  retVal.oniceconnectionstatechange = function (event) {
    if (event.target.iceConnectionState === 'connected') {
      createDataChannel();
    }
  };

  retVal.onsignalingstatechange = function (event) {
    // console.log('onsignalingstatechange');
  };
  retVal.addStream(localStream);
  retVal.onaddstream = function (event) {
    onParticipantStreamAdded(socketId, event.stream);
  };


  function createDataChannel() {
    if (retVal.textDataChannel) {
      return;
    }
    var dataChannel = retVal.createDataChannel("text");
    dataChannel.onerror = function (error) {
    };
    dataChannel.onmessage = function (event) {
      if (onDataChannelMessageCallback != null) {
        onDataChannelMessageCallback(JSON.parse(event.data));
      }
    };
    dataChannel.onopen = function () {
    };
    dataChannel.onclose = function () {
    };
    retVal.textDataChannel = dataChannel;
  }
  return retVal;
}

function exchange(data) {
  var fromId = data.from;
  var pc;
  if (fromId in peerConnections) {
    pc = peerConnections[fromId];
  } else {
    let participant = participants.filter((participant) => participant.socketId == fromId)[0];
    if (participant == null) {
      participant = {
        socketId: fromId,
        name: ""
      }
    }
    pc = createPeerConnection(participant, false);
  }
  if (data.sdp) {
    pc.setRemoteDescription(new WebRTC.RTCSessionDescription(data.sdp), function () {
      if (pc.remoteDescription.type == "offer")
        pc.createAnswer(function (desc) {
          pc.setLocalDescription(desc, function () {
            socket.emit('exchange', { 'to': fromId, 'sdp': pc.localDescription });
          }, logError);
        }, logError);
    }, logError);
  } else {
    pc.addIceCandidate(new WebRTC.RTCIceCandidate(data.candidate));
  }
}

function leave(socketId) {
  var pc = peerConnections[socketId];
  pc.close();
  delete peerConnections[socketId];
  if (onParticipantLeftCallback != null) {
    onParticipantLeftCallback(socketId);
  }
}

socket.on('exchange', function (data) {
  exchange(data);
});

function bindComponentCallbacksToServices(callbacks) {
  if (callbacks.participantStreamAdded) {
    onParticipantStreamAdded = callbacks.participantStreamAdded;
  }
  if (callbacks.onMakeCall) {
    onMakeCall = callbacks.onMakeCall;
  }
}


function logError(error) {
  console.log("logError", error);
}

function countparticipants(conferenceName, callback) {
  socket.emit("count", conferenceName, (count) => {
    callback(count);
  });
}

function getLocalStream(isFront, callback) {
  let videoSourceId;
  // on android, you don't have to specify sourceId manually, just use facingMode
  // uncomment it if you want to specify
  if (Platform.OS === 'ios') {
    WebRTC.MediaStreamTrack.getSources(sourceInfos => {
      for (const i = 0; i < sourceInfos.length; i++) {
        const sourceInfo = sourceInfos[i];
        if (sourceInfo.kind == "video" && sourceInfo.facing == (isFront ? "front" : "back")) {
          videoSourceId = sourceInfo.id;
        }
      }
    });
  }
  WebRTC.getUserMedia({
    audio: true,
    video: {
      mandatory: {
        minWidth: 640, // Provide your own width, height and frame rate here
        minHeight: 360,
        minFrameRate: 30
      },
      facingMode: (isFront ? "user" : "environment"),
      optional: (videoSourceId ? [{ sourceId: videoSourceId }] : []),
    }
  }, function (stream) {
    callback(stream);
    localStream = stream;
  }, logError);
}

function getPeerConnectionBySocketId(socketId) {
  return peerConnections[socketId];
}

function destroyPeerConnection(socketId, stream) {
  if (peerConnections[socketId]) {
    const pc = peerConnections[socketId];
    pc.removeStream(stream);
    pc.close();
    delete peerConnections[socketId];
  }
}

function join(roomId, email, cb, callType = 'call') {
  socket.emit('join', { roomId, email, callType }, function (cbParticipants) {
    participants = cbParticipants;
    cbParticipants.forEach((participant) => {
      createPeerConnection(participant, true);
    });
    cb(cbParticipants);
  });
}

function joinConference(roomId, email, cb) {
  join(roomId, email, cb, 'conference');
}

// return the current socket
function getSocket() {
  return socket;
}

function toggleCamera(isFront, cb) {
  getLocalStream(isFront, function (stream) {
    const pcLen = Object.keys(peerConnections).length;
    if (localStream && pcLen) {
      for (const id in peerConnections) {
        const pc = peerConnections[id];
        pc && pc.removeStream(localStream);
      }
      localStream.release();
    }
    if (pcLen) {
      for (const id in peerConnections) {
        const pc = peerConnections[id];
        pc && pc.addStream(stream);
      }
    }
    cb(stream);
  });
}

function makeCall(from, to, room_id, call_type) {
  // join the conference
  join(room_id, from.email, function () {
    onMakeCall();
    socket.emit('outgoing_call', { from, to, room_id, call_type });
  });
}

function dropCall(data) {
  if (!data.callType) {
    data.callType = 'call';
  }
  leaveRoom(data.room_id, data.dropped_by.email, data.callType);
  socket.emit('drop_call', data);
}

function dropConference(data) {
  data.callType = 'conference';
  dropCall(data);
}

function logout() {
  socket.emit('user_logout');
}

function checkOnlineStatus(email, cb) {
  socket.emit('checkOnlineStatus', email, function (isOnline) {
    cb(isOnline);
  });
}

function mapUserWithSocketId(user) {
  socket.emit('mapUserWithSocketId', { user });
}

function getValueByRoomId(userInfo, cb) {
  socket.emit('getValueByRoomId', { userInfo }, function (roomData) {
    cb(roomData);
  });
}

function saveChatMessage(datavalue, usersInfoToServer, cb) {
  socket.emit('saveChatMessage', { datavalue, usersInfoToServer }, function (chatData) {
    // cb(chatData);
  });
}

function rejectCall(rejecter, rejectedOf) {
  socket.emit('reject_call', { rejecter, rejectedOf });
}

function leaveRoom(room_id, email, callType) {
  socket.emit('leave_room', { room_id, email, callType });
}

function testSocketMapping() {
  socket.emit('test_socket_mapping', function (data) {
  });
}

function getUsersByArea(myType, radius, email, coords, cb) {
  socket.emit('get_users_by_coords', { myType, radius, email, coords }, function (users) {
    cb(users);
  });
}

function sendAudio(data) {
  socket.emit('send_audio', data);
}

//------------------------------------------------------------------------------
// Exports
if (!IS_BROWSER) {
  module.exports = {
    bindComponentCallbacksToServices,
    checkOnlineStatus,
    countparticipants,
    createPeerConnection,
    destroyPeerConnection,
    dropCall,
    dropConference,
    getLocalStream,
    getPeerConnectionBySocketId,
    getSocket,
    getUsersByArea,
    join,
    joinConference,
    leaveRoom,
    logout,
    makeCall,
    mapUserWithSocketId,
    getValueByRoomId,
    saveChatMessage,
    rejectCall,
    sendAudio,
    testSocketMapping,
    toggleCamera
  }
}
