var port = process.env.PORT || 3005;
var config = {
  isDev: false,
  jwtTokenExpires: 2,
  expressSessionSecure: true,
  expressSessionHttpOnly: false,
  db: {
    url: 'mongodb://twa:twa#@ds125479.mlab.com:25479/twa'
    // url: 'mongodb://vineetkumar1987:Vineetkumar1987#@ds127300.mlab.com:27300/etruckinglocal'
    // mongodb://<dbuser>:<dbpassword>@ds125479.mlab.com:25479/twa
  },
  nexmo: {
    apiKey: '8a7e8063',
    apiSecret: 'bda5f5e1f458cd7d'
  },
  marital_status: ['single', 'married', 'divorcee', 'widowed'],
  apiPrefix: '/api/v1',
  mobApiPrefix: '/api/v1.0',
  users: {
    admin: { password: 'password' }
  },
  bcryptSalt: 10,
  jwtSecret: '09sdufa0sfusafkljsa098',
  host: 'localhost',
  port: port,
  enableAuth: true,
  enableCheckPermissions: true,
  paypal: {
    "port": port,
    "api": {
      "host": "api.paypal.com",
      "port": "",
      "client_id": "ATqNPvJlJzb3ip7IcJ_FRTN9E3KP0mV9qsveqfuys8UN6MBJb1bXjZ2L0iVv0sGS-DYnMXWbeQepCxGd",
      "client_secret": "ENDZV7ZAljN_nLNugHMkHOS4MZoQ-4BZuPhedd5xXRj0cdgo7Z3JXEzX4hhmZHFwHKeJHDqyreJObf-6"
    }
  }
}
if (process.env.NODE_ENV != undefined && process.env.NODE_ENV == 'dev') {
  config.isDev = true;
  config.expressSessionSecure = false;
  config.expressSessionHttpOnly = true;
  config.paypal = {
    "port": port,
    "api": {
      "host": "api.sandbox.paypal.com",
      "port": "",
      // "client_id": "Ae9Ka8l9nk8iVdRXp-rZldAVcEmPM4d8u2GKm3orW2cFtaq7SKmFFv5-6C4TaOwdP94R1kQj6FKjANJg",
      // "client_secret": "EKXcpKSvl9F92hmMSLrg5VAZn_IqZ9I03S4O4TWmi04qbMt3e7zWfUW2dnHb8WMbV_rVnirypnT-r6d7"
      "client_id": "ATqNPvJlJzb3ip7IcJ_FRTN9E3KP0mV9qsveqfuys8UN6MBJb1bXjZ2L0iVv0sGS-DYnMXWbeQepCxGd",
      "client_secret": "ENDZV7ZAljN_nLNugHMkHOS4MZoQ-4BZuPhedd5xXRj0cdgo7Z3JXEzX4hhmZHFwHKeJHDqyreJObf-6"
    }
  }
}
module.exports = config;
