const geodist = require('geodist'),
    ChatMessageModel = require('./src/db/models/ChatMessageModel'),
    notificationsService = require('./src/notifications/');
var emailsWithSocketIds = {},
    loginStatusMapping = {},
    userLocations = {},
    roomParticipants = [];

var apn = require('apn');

function socketIdsInRoom(io, roomId, cb) {
    io.in(roomId).clients((err, clients) => {
        cb(clients);
    });
}

function parseCoords(coords) {
    let res = {};
    for (var key in coords) {
        if (coords.hasOwnProperty(key)) {
            res[key] = parseFloat(parseFloat(coords[key]).toFixed(4));
        }
    }
    return res;
}

function getUserBySocketId(sId) {
    for (var email in emailsWithSocketIds) {
        if (emailsWithSocketIds.hasOwnProperty(email)) {
            if (emailsWithSocketIds[email].socketId === sId)
                return emailsWithSocketIds[email];
        }
    }
}

module.exports = function (server) {
    const io = require('socket.io')(server, {
        pingTimeout: 30000,
        pingInterval: 30000
    });
    io.on('connection', function (socket) {
        // console.log('\n\n\n\n==================' + socket.id + ' CONNECTED=================\n\n\n\n');
        socket.on('disconnect', function () {
            // console.log('\n\n\n\n==================' + socket.id + ' DISCONNECTED=================\n\n\n\n');
            const user = getUserBySocketId(socket.id);
            if (user) {
                delete emailsWithSocketIds[user.email];
                delete loginStatusMapping[user.email];
                delete userLocations[user.email];
            }
            if (socket.room) {
                var room = socket.room;
                socket.to(room).emit('leave', socket.id);
                socket.leave(room);
            }
            socket.broadcast.emit('user_disconnected', user);
        });

        socket.on('checkOnlineStatus', function (email, cb) {
            const isOnline = emailsWithSocketIds[email] !== undefined;
            cb(isOnline);
        });

        socket.on('join', function (joinData, callback) { //Join room
            const roomId = joinData.roomId,
                email = joinData.email,
                joineeData = emailsWithSocketIds[email];
            socket.join(roomId);
            socket.room = roomId;
            const socketIds = socketIdsInRoom(io, roomId, function (socketIds) {
                roomParticipants = socketIds.map((socketId) => {
                    let participant;
                    for (var e_mail in emailsWithSocketIds) {
                        if (emailsWithSocketIds.hasOwnProperty(e_mail)) {
                            if (socketId == emailsWithSocketIds[e_mail].socketId) {
                                participant = emailsWithSocketIds[e_mail];
                                break;
                            }
                        }
                    }
                    return { socketId, participant };
                }).filter((participant) => participant.socketId != socket.id);
                callback(roomParticipants);
                roomParticipants.forEach((participant) => {
                    const emitEvent = joinData.callType != undefined && joinData.callType == 'conference' ? 'on_participant_joined_conference' : 'on_participant_joined';
                    io.sockets.clients().connected[participant.socketId].emit(emitEvent, roomId, joineeData);
                });
            });
        });


        socket.on("count", function (roomId, callback) {
            if (roomId) {
                var socketIds = socketIdsInRoom(io, roomId, function (socketIds) {
                    callback(socketIds.length);
                });
            } else {
                callback(io.engine.clientsCount);
            }
        });

        socket.on('leave_room', function (data) {
            const roomId = data.room_id,
                emitEvent = data.callType != undefined && data.callType == 'conference' ? 'participant_left_conference' : 'participant_left';
            socket.leave(roomId);
            socket.to(roomId).emit(emitEvent, emailsWithSocketIds[data.email]);
        });
        socket.on('drop_call', function (data) {
            // if we found data.to then this is one-to-one call and we need to tell the other user that we are leaving
            if (data.callType && data.callType == 'conference') {
                //socket.to(data.room_id).emit('participant_left_conference', data.dropped_by);
            } else {
                const toUser = emailsWithSocketIds[data.drop_inform_to.email];
                if (toUser) {
                    const to = io.sockets.clients().connected[toUser.socketId];
                    data.dropped_by.socketId = socket.id;
                    data.is_autodropped === true ? to.emit('participant_dropped_call', data.dropped_by, true) : to.emit('participant_dropped_call', data.dropped_by, false);
                }
                const deviceInfo = data.drop_inform_to.deviceInfo;
                let fromName = data.dropped_by.name;
                if (data.drop_inform_to == 'citizen') {
                    fromName = 'LEO';
                }
                if (data.is_autodropped === true) {
                    if (deviceInfo.os == 'ios') {
                        notificationsService.sendPushNotificationIOS(deviceInfo.token, '', 'Missed call from ' + fromName, { 'screen': 'none' }, data.room_id);
                    } else if (deviceInfo.os == 'android') {
                        notificationsService.sendPushNotificationAndroid(deviceInfo.token, 'Missed call from ' + fromName, null, { 'screen': 'none' }, data.room_id);
                    }
                }
            }
        });

        socket.on('exchange', function (data) {
            // console.log('exchange', data);
            data.from = socket.id;
            var to = io.sockets.clients().connected[data.to];
            if (to) {
                to.emit('exchange', data);
            }
        });

        socket.on('line_busy', function (data) {
            const toSocketId = emailsWithSocketIds[data.to.email].socketId;
            if (toSocketId) {
                const to = io.sockets.clients().connected[toSocketId];
                to.emit('participant_busy', data);
            }
        });
        socket.on('mapUserWithSocketId', function (data, cb) {
            data.user.socketId = socket.id;
            emailsWithSocketIds[data.user.email] = data.user;
            loginStatusMapping[data.user.email] = true;
            let locationFound = false;
            if (data.user.location) {
                let p = Object.assign({}, data.user.location.position);
                p.lon = p.lng;
                delete p.lng;
                userLocations[data.user.email] = p;
                locationFound = true;
            }
            if (typeof cb == 'function') {
                cb(locationFound);
            }
            // emit connection information to all socket users
            socket.broadcast.emit('user_connected', data.user)
        });

        socket.on('outgoing_call', function (data) {
            const deviceInfo = data.to.deviceInfo,
                _p = emailsWithSocketIds;
            let title = data.from.name + " is calling you...",
                isLoggedIn = true;
            if (data.to.type == 'citizen') {
                title = 'LEO is calling you...';
            }
            if (loginStatusMapping[data.to.email] === false) {
                isLoggedIn = false;
            }
            if (isLoggedIn) {
                if (deviceInfo.os == 'ios') {
                    notificationsService.sendPushNotificationIOS(deviceInfo.token, null, title, { 'screen': 'call', 'params': { from: data.from._id, room_id: data.room_id, call_type: 'call' } }, data.room_id);
                } else if (deviceInfo.os == 'android') {
                    notificationsService.sendPushNotificationAndroid(deviceInfo.token, title, 'Tap to receive', { 'screen': 'call', 'params': { from: data.from._id, room_id: data.room_id, call_type: 'call' } }, data.room_id);
                }
                const toUser = _p[data.to.email],
                    fromUser = _p[data.from.email];
                if (toUser && fromUser) {
                    data.to.socketId = toUser.socketId;
                    data.from.socketId = fromUser.socketId;
                    const to = io.sockets.clients().connected[toUser.socketId];
                    to.emit('incoming_call', data);
                }
            } else {
                if (!_p[data.to.email]) {
                    io.sockets.clients().connected[_p[data.from.email].socketId].emit('not_reachable');
                }
            }
        });

        socket.on('reject_call', function (rejectData) {
            if (rejectData.rejectedOf) {
                const toSocketId = emailsWithSocketIds[rejectData.rejectedOf.email].socketId;
                if (toSocketId) {
                    const to = io.sockets.clients().connected[toSocketId];
                    to.emit('participant_rejected_call', rejectData.rejecter);
                }
            }
        });

        socket.on('test_socket_mapping', function (cb) {
            cb(emailsWithSocketIds);
        });

        socket.on('user_logout', function () {
            const user = getUserBySocketId(socket.id);

            if (user) {
                delete emailsWithSocketIds[user.email];
                loginStatusMapping[user.email] = false;
                delete userLocations[user.email];
            }
            if (socket.room) {
                var room = socket.room;
                socket.to(room).emit('leave', socket.id);
                socket.leave(room);
            }
            socket.broadcast.emit('user_disconnected', user);
        });

        socket.on('get_users_by_coords', function (data, cb) {
            let users = [],
                nearbyUserType = null;
            if (data.myType) {
                if (data.myType == 'citizen') {
                    nearbyUserType = 'leo';
                }
            }
            for (var email in userLocations) {
                if (email != data.email && userLocations.hasOwnProperty(email)) {
                    const coords = Object.assign({}, data.coords);
                    coords.lon = coords.lng;
                    delete coords.lng;
                    const dist = geodist(parseCoords(coords), parseCoords(userLocations[email])),
                        uDetail = emailsWithSocketIds[email];
                    if (dist <= data.radius) {
                        if (nearbyUserType) {
                            if (nearbyUserType == uDetail.type) {
                                users.push(uDetail);
                            }
                        } else {
                            users.push(uDetail);
                        }
                    }
                }
            }
            cb(users);
        });

        socket.on('getValueByRoomId', function (data, cb) {
            let userIdsArr = [];
            userIdsArr.push(data.userInfo.from._id, data.userInfo.to._id);
            userIdsArr.sort();
            let roomId = userIdsArr.join('-');
            var conditions = {};
            conditions.roomId = roomId;
            ChatMessageModel.getAllValues(conditions, { time: 1 })
                .then(function (roomData) {
                    cb(roomData);
                })
                .catch(function (err) {
                    console.log('err', err);
                });
        });


        socket.on('saveChatMessage', function (data, cb) {
            let userIdsArr = [];
            userIdsArr.push(data.datavalue.senderId, data.datavalue.receiverId);
            userIdsArr.sort();
            let roomId = userIdsArr.join('-');
            const saveData = {
                "roomId": roomId,
                "senderId": data.datavalue.senderId,
                "senderEmail": data.datavalue.senderEmail,
                "receiverId": data.datavalue.receiverId,
                "receiverEmail": data.datavalue.receiverEmail,
                "message": data.datavalue.message,
                "type": data.datavalue.type,
                "time": data.datavalue.time,
                "localPath": data.datavalue.localPath,
            }
            ChatMessageModel.saveValue(saveData)
                .then(function (results) {
                    var dataArr = {};
                    dataArr.results = results;
                    dataArr.usersInfoToServer = data.usersInfoToServer;
                    if (dataArr.usersInfoToServer.to.deviceInfo) {
                        const deviceInfo = dataArr.usersInfoToServer.to.deviceInfo;
                        let senderName = data.usersInfoToServer.from.fname;
                        if (data.usersInfoToServer.from.type == 'leo' && data.usersInfoToServer.to.type == 'citizen') {
                            senderName = 'LEO';
                        }
                        const title = senderName + ' sent you a message',
                            msg = data.datavalue.message.length > 50 ? data.datavalue.message.substring(0, 50) + '...' : data.datavalue.message;
                        if (deviceInfo.os == 'ios') {
                            notificationsService.sendPushNotificationIOS(deviceInfo.token, null, title + ': ' + msg, { 'screen': 'UserChat', 'params': data.usersInfoToServer.from });
                        } else if (deviceInfo.os == 'android') {
                            notificationsService.sendPushNotificationAndroid(deviceInfo.token, title, msg, { 'screen': 'UserChat', 'params': data.usersInfoToServer.from });
                        }

                    }
                    const toUser = emailsWithSocketIds[saveData.receiverEmail];
                    if (toUser) {
                        const toSocketId = toUser.socketId,
                            to = io.sockets.clients().connected[toSocketId];
                        to.emit('getChatMessage', dataArr);
                        cb(results);
                    }
                })
                .catch(function (err) {
                    console.log('err', err);
                });
        });

        socket.on('send_vmail', function (data) {
            // send push notifications
            const dinf = data.receiver.deviceInfo;
            if (dinf) {
                let senderName = data.sender.name;
                if (data.sender.type == 'leo' && data.receiver.type == 'citizen') {
                    senderName = 'LEO';
                }
                const title = senderName + ' sent you a V-Mail',
                    msg = data.message.length > 50 ? data.message.substring(0, 50) + '...' : data.message;
                if (dinf.os == 'ios') {
                    notificationsService.sendPushNotificationIOS(dinf.token, null, title + ': ' + msg, { 'screen': 'Vmail', 'params': data.sender });
                } else if (dinf.os == 'android') {
                    notificationsService.sendPushNotificationAndroid(dinf.token, title, msg, { 'screen': 'Vmail', 'params': data.sender });
                }
            }
        });

        socket.on('send_audio', function (data) {
            const dinf = data.receiver.deviceInfo;
            if (dinf) {
                let senderName = data.sender.name;
                if (data.sender.type == 'leo' && data.receiver.type == 'citizen') {
                    senderName = 'LEO';
                }
                const title = senderName + ' sent you an audio',
                    msg = 'Tap to listen',
                    params = {
                        sender: data.sender,
                        audioDetail: data.audioDetail
                    };
                if (dinf.os == 'ios') {
                    notificationsService.sendPushNotificationIOS(dinf.token, null, title + ' ' + msg, { 'screen': 'PlayAudio', 'params': params });
                } else if (dinf.os == 'android') {
                    notificationsService.sendPushNotificationAndroid(dinf.token, title, msg, { 'screen': 'PlayAudio', 'params': params });
                }
            }
        });
    });
}