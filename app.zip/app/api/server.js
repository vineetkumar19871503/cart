const { isDev } = require('./src/globals/methods'),
  { port, apiPrefix, mobApiPrefix } = require('./config'),
  express = require('express'),
  app = express(),
  config = require('./config'),
  bodyParser = require('body-parser'),
  expCtrl = require('./src/utilities/routes-generator'),
  path = require('path'),
  paypal = require('paypal-rest-sdk'),
  restResponse = require('express-rest-response'),
  session = require('express-session'),
  server = require('http').createServer(app),
  sharp = require('sharp');

// init socket server
require('./socket_conf')(server);

app.use(require('cors')());

//express-rest-response middleware configuration  
app.use(restResponse({
  showStatusCode: true,
  showDefaultMessage: true
}));

//*******PAYPAL********//

// init paypal
app.use(function (req, res, next) {
  paypal.configure(config.paypal.api);
  req.paypal = paypal
  next();
});


// view engine setup
app.set('views', path.join(__dirname, 'src/views'));
app.set('view engine', 'jade');

/*
For upload file s3 bucket
*/
// var multer = require('multer');
// var multerS3 = require('multer-s3');
// var aws = require('aws-sdk');

// aws.config.update({
//   secretAccessKey: 'JS/XqMiud4K8oXm/5Ea5wCpznR6+fxbon9OYUBuZ',
//   accessKeyId: 'AKIAJDI2IXXPMN4EVTHA',
//   region: 'us-west-1'
// });

//  s3 = new aws.S3();

// var upload = multer({
//   storage: multerS3({
//     s3: s3,
//     bucket: 'sbdevents',
//     key: function (req, file, cb) {
//       var fullPath = 'uploads/et/' + Date.now() + '_' + file.originalname;
//       cb(null, fullPath); //use Date.now() for unique file keys
//     }
//   })
// });

// app.post('/api/v1/upload', upload.any(), function (req, res, next) {
//   res.send({ 'mimetype': req.files[0].mimetype, 'file_path': req.files[0].location });
// });
//Ends here

/*
For upload file with upload folder on server
*/


const multer = require('multer');
// const MulterResizer = require('multer-resizer');
const storage = multer.diskStorage({
  destination: './uploads/audios',
  filename: function (req, file, cb) {
    console.log(file.mimetype);
    ext = '.mp3';
    filenamevar = file.originalname.slice(0, 4) + Date.now() + ext;
    cb(null, filenamevar);
  }
});
const upload = multer({
  storage: storage
});

app.post('/api/v1/upload', upload.single('file'), function (req, res, next) {
  if (req.file && req.file.originalname) {
    console.log(`Received file ${filenamevar}`);
  }

  res.send(filenamevar); // You can send any response to the user here
});

//for upload images
const storageimage = multer.diskStorage({
  destination: './uploads/images',
  filename: function (req, file, cb) {
    switch (file.mimetype) {
      case 'image/jpeg':
        ext = '.jpeg';
        break;
      case 'image/png':
        ext = '.png';
        break;
      case 'image/gif':
        ext = '.gif';
        break;
    }
    filenamevar = file.originalname.slice(0, 4) + Date.now() + ext;
    cb(null, filenamevar);
  }
});
const uploadimages = multer({ storage: storageimage });

app.post('/api/v1/uploadImages', uploadimages.single('file'), function (req, res, next) {
  if (req.file && req.file.originalname) {
    console.log(`Received file ${filenamevar}`);
  }

  res.send(filenamevar); // You can send any response to the user here
});

//Ends here
//for upload attachments
const storageattachments = multer.diskStorage({
  destination: './uploads/attachments',
  filename: function (req, file, cb) {
    console.log('filefilefile', file);
    var ext = file.originalname.split('.').pop();
    filenamevar = file.originalname.slice(0, 4) + Date.now() + '.' + ext;
    cb(null, filenamevar);
  }
});
const uploadattachments = multer({ storage: storageattachments, limits: { fieldSize: 25 * 1024 * 1024 } });

app.post('/api/v1/uploadAttachments', uploadattachments.single('file'), function (req, res, next) {
  if (req.file && req.file.originalname) {
    console.log(`Received file ${filenamevar}`);
  }
  res.send({ 'status': 'upload complete', 'fileName': filenamevar }); // You can send any response to the user here
});


//upload attachments for chat application with create thumbnail

app.post('/api/v1/uploadAttachmentsWithThumb', uploadattachments.single('file'), function (req, res, next) {
  if (req.file && req.file.originalname) {
    console.log(`Received file ${filenamevar}`);
  }

  sharp('./uploads/attachments/' + filenamevar)
    .resize(150, 150)
    .toFile('./uploads/attachments/thumb-' + filenamevar, function (err, res1) {

      res.send({ 'status': 'upload complete', 'fileName': filenamevar });
      console.log('res', res1);
    });
});

//for uploading videos
var videoName;
const storageVideos = multer.diskStorage({
  destination: './uploads/videos',
  filename: function (req, file, cb) {
    var ext = file.originalname.split('.').pop();
    videoName = file.originalname.slice(0, 4) + Date.now() + '.' + ext;
    cb(null, videoName);
  }
});
const uploadVideos = multer({ storage: storageVideos });
app.post('/api/v1.0/uploadVideos', uploadVideos.single('file'), function (req, res, next) {
  if (req.file && req.file.originalname) {
    console.log(`Received file ${videoName}`);
  }
  res.send({ 'status': 'video upload complete', 'fileName': videoName }); // You can send any response to the user here
});


//Ends here
//using express-session middleware
app.use(session({
  cookie: {
    httpOnly: config.expressSessionHttpOnly,
    path: '/',
    maxAge: (7 * 24 * 60 * 60 * 1000), //expires 7 days
    secure: config.expressSessionSecure,
  },
  resave: false,
  saveUninitialized: true,
  secret: '98safhsaf98safklnf'
}));



//using body-parser middlewares
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));




//use cors for Access-Control-Allow-Origin' issue
// if (isDev) {
// app.use(require('cors')());
// }

//check auth and roles using middleware
app.use(require('./src/auth/checkPermissions'));

//defining and using routers
const router = express.Router();
expCtrl.bind(router, __dirname + '/src/controllers/', apiPrefix); // For Api Routing
expCtrl.bind(router, __dirname + '/src/mob-apis/', mobApiPrefix); // For Mobile Api Routing
app.use(router);
//app.use(express.static('./uploads'));
//app.use(express(__dirname + './uploads'));
//console.log(__dirname);
//capture all 404 urls
app.use(express.static(__dirname + '/uploads'));

app.use(function (req, res, next) {
  // respond with json
  if (req.accepts('json')) {
    res.rest.notFound();
    return;
  }
  // default to plain-text. send()
  res.type('txt').send('Not found');
});

//connecting database
require('./src/db/connect')();

server.listen(port, () => {
  console.log('Express App listening on port:', port);
});



























// const { isDev } = require('./src/globals/methods');
// const { port, apiPrefix, mobApiPrefix } = require('./config');
// const config = require('./config');
// const express = require('express'),
//   app = express(),
//   bodyParser = require('body-parser'),
//   // expCtrl = require('express-controllers-routes'),
//   expCtrl = require('./src/utilities/routes-generator'),
//   restResponse = require('express-rest-response'),
//   session = require('express-session');

// app.use(require('cors')());

// //express-rest-response middleware configuration  
// app.use(restResponse({
//   showStatusCode: true,
//   showDefaultMessage: true
// }));



// /*
// For upload file
// */
// // var multer = require('multer');
// // var multerS3 = require('multer-s3');
// // var aws = require('aws-sdk');

// // aws.config.update({
// //   secretAccessKey: 'JS/XqMiud4K8oXm/5Ea5wCpznR6+fxbon9OYUBuZ',
// //   accessKeyId: 'AKIAJDI2IXXPMN4EVTHA',
// //   region: 'us-west-1'
// // });

// // s3 = new aws.S3();

// // var upload = multer({
// //   storage: multerS3({
// //     s3: s3,
// //     bucket: 'sbdevents',
// //     key: function (req, file, cb) {
// //       var fullPath = 'uploads/et/' + Date.now() + '_' + file.originalname;
// //       cb(null, fullPath); //use Date.now() for unique file keys
// //     }
// //   })
// // });

// // app.post('/api/v1/upload', upload.any(), function (req, res, next) {
// //   res.send({ 'mimetype': req.files[0].mimetype, 'file_path': req.files[0].location });
// // });
// //Ends here

// //using express-session middleware
// app.use(session({
//   cookie: {
//     httpOnly: config.expressSessionHttpOnly,
//     path: '/',
//     maxAge: (7 * 24 * 60 * 60 * 1000), //expires 7 days
//     secure: config.expressSessionSecure,
//   },
//   resave: false,
//   saveUninitialized: true,
//   secret: '98safhsaf98safklnf'
// }));



// //using body-parser middlewares
// app.use(bodyParser.json());
// app.use(bodyParser.urlencoded({ extended: true }));




// //use cors for Access-Control-Allow-Origin' issue
// // if (isDev) {
// // app.use(require('cors')());
// // }

// //check auth and roles using middleware
// app.use(require('./src/auth/checkPermissions'));

// //defining and using routers
// const router = express.Router();
// expCtrl.bind(router, __dirname + '/src/controllers/', apiPrefix); // For Api Routing
// expCtrl.bind(router, __dirname + '/src/mob-apis/', mobApiPrefix); // For Mobile Api Routing
// app.use(router);


// //capture all 404 urls
// app.use(function (req, res, next) {
//   // respond with json
//   if (req.accepts('json')) {
//     res.rest.notFound();
//     return;
//   }
//   // default to plain-text. send()
//   res.type('txt').send('Not found');
// });

// //connecting database
// require('./src/db/connect')();

// app.listen(port, () => {
//   console.log('Express App listening on port:', port);
// });
