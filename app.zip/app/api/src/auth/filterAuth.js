//array of routes that are not required to be authenticated or permitted 
module.exports = {
    auth: {
        '/users/login': 1,
        '/users/logout': 1,
       
    },
    permissions: {
        '/users/login': 1,
        '/users/logout': 1,
        

        // for mobileApi
        
        '/assigned_jobs/createTrip': 1,
        '/users/regiser': 1,
        '/users/getSecurityQuestions': 1,
    }
}

