const thisModel = require('../db/models/TicketModel');
var nodemailer = require('nodemailer');
objectId = require('mongoose').Types.ObjectId;

module.exports = {
    name: 'ticket',
    post: {
        add: function (req, res, next) {
            thisModel.saveValue(req.body)
                .then(function (data) {
                    res.rest.success({
                        'data': {},
                        'message': 'Ticket added successfully!'
                    });
                })
                .catch(function (err) {
                    console.log(err);
                    res.rest.serverError({
                        'message': 'Error : ' + err.message
                    });
                });
        }
    }
}