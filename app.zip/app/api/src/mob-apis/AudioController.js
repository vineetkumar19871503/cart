const authHandler = require('../handlers/AuthHandler'),
    audioModel = require('../db/models/AudioModel'),
    objectId = require('mongoose').Types.ObjectId;
module.exports = {
    name: 'audios',
    post: {
        add: function (req, res, next) {
            // authHandler(req, res, next, function () {
            const datavalue = {
                "user_id": objectId(req.body.user_id),
                "filename": req.body.filename,
                "displayname": req.body.displayname,
            }
            audioModel.saveAudio(datavalue)
                .then(function (register) {
                    res.rest.success({
                        'data': register,
                        'message': 'Audio saved successfully!'
                    });
                })
                .catch(function (err) {
                    res.rest.serverError({
                        'message': 'Error : Audio could not be Saved! ' + err.message
                    });
                });
            // });
        },
        delete: function (req, res, next) {
            //  authHandler(req, res, next, function () {
            audioModel.delete({ '_id': req.body.id }, req.body)
                .then(function (users) {
                    res.rest.success({
                        'data': users,
                        'message': 'Audio Delete successfully!'
                    });
                })
                .catch(function (err) {
                    res.rest.serverError({
                        'message': 'Error : Audio could not be Delete! ' + err.message
                    });
                });

            //});
        },
        sendAudio: function (req, res, next) {
            // authHandler(req, res, next, function () {
            const reqData = req.body,
                data = {
                    "sender_id": reqData.sender_id,
                    "receiver_id": reqData.receiver_id,
                    "audio_id": reqData.audio_id
                }
            audioModel.saveSentAudio(data)
                .then(function (register) {
                    res.rest.success({
                        'data': register,
                        'message': 'Audio sent successfully!'
                    });
                })
                .catch(function (err) {
                    res.rest.serverError({
                        'message': 'Error : Audio could not be sent! ' + err.message
                    });
                });
            // });
        }
    },
    get: {

        list: function (req, res, next) {
            // authHandler(req, res, next, function () {
            let conditions = {};
            audioModel.getAudiosList(conditions)
                .then(function (Users) {
                    res.rest.success({
                        'data': Users,
                        'message': 'Audios list!'
                    });
                })
                .catch(function (err) {
                    res.rest.serverError({
                        'message': 'Error : Audios not found! ' + err.message
                    });
                });

            // });
        }


    }
}