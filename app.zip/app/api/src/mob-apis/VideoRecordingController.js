const authHandler = require('../handlers/AuthHandler'),
    VideoRecordingModel = require('../db/models/VideoRecordingModel'),
    objectId = require('mongoose').Types.ObjectId;
module.exports = {
    name: 'video_recording',
    post: {
        add: function (req, res, next) {
            // authHandler(req, res, next, function () {
            const data = {
                "user_id": objectId(req.body.user_id),
                "filename": req.body.filename
            }
            VideoRecordingModel.save(data)
                .then(function (response) {
                    res.rest.success({
                        'data': response,
                        'message': 'Recording saved successfully!'
                    });
                })
                .catch(function (err) {
                    res.rest.serverError({
                        'message': 'Error : Recording could not be Saved! ' + err.message
                    });
                });
            // });
        },

        delete: function (req, res, next) {
            //  authHandler(req, res, next, function () {
            VideoRecordingModel.delete({ '_id': req.body.id }, req.body)
                .then(function (users) {
                    res.rest.success({
                        'data': users,
                        'message': 'Recording deleted successfully!'
                    });
                })
                .catch(function (err) {
                    res.rest.serverError({
                        'message': 'Error : Recording could not be deleted! ' + err.message
                    });
                });
            //});
        }
    },
    get: {
        list: function (req, res, next) {
            // authHandler(req, res, next, function () {
            let conditions = {};
            if (req.query.user_id) {
                conditions.user_id = objectId(req.query.user_id);
            }
            VideoRecordingModel.list(conditions)
                .then(function (recordings) {
                    res.rest.success({
                        'data': recordings,
                        'message': 'Video recordings'
                    });
                })
                .catch(function (err) {
                    res.rest.serverError({
                        'message': 'Error : No data found! ' + err.message
                    });
                });
            // });
        }
    }
}
