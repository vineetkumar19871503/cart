const bcrypt = require('bcrypt'),
    authHandler = require('../handlers/AuthHandler'),
    generateToken = require('../auth/generateToken'),
    { extractToken } = require('../auth/authorize'),
    vmailModel = require('../db/models/VmailModel');
var nodemailer = require('nodemailer');
objectId = require('mongoose').Types.ObjectId;
var transporter = nodemailer.createTransport({
    service: 'Gmail',
    auth: {
        user: 'avinesh.mathur@a3logics.in',
        pass: 'Avinesh1233#'
    }
});

module.exports = {
    name: 'vmails',
    post: {

        sendMsg: function (req, res, next) {
            // authHandler(req, res, next, function () {
            var insertedDocs = [];
            receiverArray = req.body.receiver_id;
            receiverArray.forEach(function (receiver_id) {
                let datavalue = {
                    "sender_id": objectId(req.body.sender_id),
                    "receiver_id": objectId(receiver_id),
                    "subject": req.body.subject,
                    "message": req.body.message,
                }
                if (req.body.location) {
                    datavalue.location = req.body.location;
                }
                insertedDocs.push(datavalue);
            });
            vmailModel.saveMessage(insertedDocs)
                .then(function (register) {
                    res.rest.success({
                        'data': register,
                        'message': 'Message saved successfully!'
                    });
                })
                .catch(function (err) {
                    res.rest.serverError({
                        'message': 'Error : Message could not be Saved! ' + err.message
                    });
                });



            // });
        },

        list: function (req, res, next) {
            // authHandler(req, res, next, function () {
            const conditionsArr = [];
            if (req.body.sender_id) {
                conditionsArr.push({ sender_id: objectId(req.body.sender_id) });
            }
            if (req.body.receiver_id) {
                conditionsArr.push({ receiver_id: objectId(req.body.receiver_id) });
            }
            let conditions = {
                $and: conditionsArr
            }
            vmailModel.getvmailListSenderDetails(conditions)
                .then(function (Users) {
                    res.rest.success({
                        'data': Users,
                        'message': 'vmail list!'
                    });
                })
                .catch(function (err) {
                    res.rest.serverError({
                        'message': 'Error : vmail  not found! ' + err.message
                    });
                });
            // if(req.body.receiver_id)
            // {
            //     vmailModel.getvmailList(conditions)
            //     .then(function (Users) {
            //         res.rest.success({
            //             'data': Users,
            //             'message': 'vmail list!'
            //         });
            //     })
            //     .catch(function (err) {
            //         res.rest.serverError({
            //             'message': 'Error : vmail  not found! ' + err.message
            //         });
            //     });
            // }
            // else
            // {
            //    vmailModel.getvmailListSenderDetails(conditions)
            //     .then(function (Users) {
            //         res.rest.success({
            //             'data': Users,
            //             'message': 'vmail list!'
            //         });
            //     })
            //     .catch(function (err) {
            //         res.rest.serverError({
            //             'message': 'Error : vmail  not found! ' + err.message
            //         });
            //     }); 
            // }


            // });
        },
        getDetailMsg: function (req, res, next) {
            // authHandler(req, res, next, function () {
            //  let conditions = { 'sender_id': objectId(req.body.sender_id), 'receiver_id': objectId(req.body.receiver_id)};
            let conditions = { '_id': objectId(req.body.id) };
            vmailModel.getvmailDetail(conditions, req.body)
                .then(function (Users) {
                    res.rest.success({
                        'data': Users,
                        'message': 'vmail list!'
                    });
                })
                .catch(function (err) {
                    res.rest.serverError({
                        'message': 'Error : vmail  not found! ' + err.message
                    });
                });

            // });
        },

        delete: function (req, res, next) {
            //  authHandler(req, res, next, function () {
            audioModel.delete({ '_id': req.body.id }, req.body)
                .then(function (users) {
                    res.rest.success({
                        'data': users,
                        'message': 'Audio Delete successfully!'
                    });
                })
                .catch(function (err) {
                    res.rest.serverError({
                        'message': 'Error : Audio could not be Delete! ' + err.message
                    });
                });

            //});
        }
    },
    get: {




    }
}