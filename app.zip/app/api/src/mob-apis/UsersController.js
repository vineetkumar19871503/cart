const bcrypt = require('bcrypt'),
    authHandler = require('../handlers/AuthHandler'),
    generateToken = require('../auth/generateToken'),
    { extractToken } = require('../auth/authorize'),
    userModel = require('../db/models/UserModel'),
    securityQuestionModel = require('../db/models/SecurityQuestionModel'),
    nodemailer = require('nodemailer'),
    transporter = nodemailer.createTransport({
        service: 'Gmail',
        auth: {
            user: 'avinesh.mathur@a3logics.in',
            pass: 'Avinesh1233#'
        }
    });
var notificationsService = require('../notifications/');
objectId = require('mongoose').Types.ObjectId;
module.exports = {
    name: 'users',
    post: {
        login: function (req, res, next) {
            var response = { message: 'User not found!', data: { status: false }, checkstatus: false };
            var conditions = {};
            if (req.body.type == 'firstLogin') {
                if (typeof req.body.email != 'undefined' && typeof req.body.password != 'undefined') {
                    conditions.email = req.body.email.toLowerCase();
                    const password = req.body.password;
                    userModel.getUsers(conditions)
                        .then(function (user) {
                            if (user.length && bcrypt.compareSync(password, user[0].password)) {
                                user = user[0];
                                generateToken({ id: user._id, email: user.email, name: user.fname }, function (err, token) {
                                    if (!err) {
                                        //saving user data into session
                                        req.session.userData = JSON.parse(JSON.stringify(user));
                                        req.session.token = token;
                                        // //preparing response
                                        var resUser = JSON.parse(JSON.stringify(user));
                                        response.message = 'Logged in successfully!';
                                        resUser.password = '';
                                        response.data = resUser;
                                        response.data.status = true;
                                        response.token = token;
                                        response.checkstatus = true;
                                        res.rest.success(response);
                                    }
                                });
                            } else {
                                response.message = 'Invalid Details!';
                                res.rest.success(response);
                            }
                        })
                        .catch(function (err) {
                            res.rest.serverError(err.message);
                            return next();
                        });
                }
                else {
                    response.message = 'Invalid Input Data!!';
                    res.rest.success(response);
                }
            }
            else if (req.body.type == 'secondLogin') {
                if (typeof req.body.email != 'undefined' && typeof req.body.password != 'undefined' && typeof req.body.memberId != 'undefined') {
                    conditions.email = req.body.email.toLowerCase();
                    const password = req.body.password;
                    userModel.getUsers(conditions)
                        .then(function (user) {
                            if (user.length && bcrypt.compareSync(password, user[0].password) && req.body.memberId == user[0].memberId) {
                                user = user[0];
                                if (req.body.deviceInfo) {
                                    userModel.update({ '_id': objectId(user._id) }, { deviceInfo: req.body.deviceInfo })
                                        .then(function (values) {

                                        })
                                        .catch(function (err) {
                                            console.log(err)
                                        });
                                }

                                generateToken({ id: user._id, email: user.email, name: user.fname }, function (err, token) {
                                    if (!err) {
                                        //saving user data into session 
                                        req.session.userData = JSON.parse(JSON.stringify(user));
                                        req.session.token = token;
                                        // //preparing response
                                        var resUser = JSON.parse(JSON.stringify(user));
                                        response.message = 'Logged in successfully!';
                                        resUser.password = '';
                                        response.data = resUser;
                                        response.data.status = true;
                                        response.token = token;
                                        response.checkstatus = true;
                                        res.rest.success(response);
                                    }
                                });
                            } else {
                                response.message = 'Invalid Details!';
                                res.rest.success(response);
                            }
                        })
                        .catch(function (err) {
                            res.rest.serverError(err.message);
                            return next();
                        });
                }
                else {
                    response.message = 'Invalid Input Data!';
                    res.rest.success(response);
                }
            }
            else {
                response.message = 'Invalid Input Data!';
                res.rest.success(response);
            }
        },
        register: function (req, res, next) {
            //authHandler(req, res, next, function () {
            var memberId = Math.floor(100000 + Math.random() * 900000);
            const datavalue = {
                "email": req.body.email,
                "name": req.body.username,
                "password": req.body.password,
                "security_question": req.body.question,
                "security_answer": req.body.answer,
                "fname": req.body.fname,
                "lname": req.body.lname,
                "status": 1,
                "memberId": memberId,
                "role_id": "5aba043ff36d282750945886",
                "type": "citizen"
            }
            if (typeof req.body.email != 'undefined') {
                userModel.saveUser(datavalue)
                    .then(function (register) {
                        message = "Hello <b>" + req.body.fname + "</b>,<br><br> You have successfully registered on TWA app. Please use <b>" + memberId + "</b> as TWA Member ID to login.<br><br> Thanks, <br>Team TWA"
                        transporter.sendMail({
                            from: "Twa <noreply@twa.com>", // sender address
                            // to:'avinesh.mathur@a3logics.in', // list of receivers
                            to: req.body.email, // list of receivers
                            subject: "User Registration", // Subject line
                            text: "", // plaintext body
                            html: "<p> " + message + "</p>" // html body
                        });
                        res.rest.success({
                            'data': register,
                            'message': 'User Register successfully!'
                        });
                    })
                    .catch(function (err) {
                        res.rest.serverError({
                            'message': 'Error : User could not be Register! ' + err.message
                        });
                    });
            }
            else {
                res.rest.success({
                    'data': {},
                    'message': 'Invalid Details!'
                });
            }
            // });
        },
        changePassword: function (req, res, next) {
            const email = req.body.email,
                emailid = email.toLowerCase();
            security_question = req.body.security_question;
            security_answer = req.body.security_answer;
            var response = { message: 'User not found!', data: { status: false } };
            if ((email) && (security_question) && (security_answer)) {
                userModel.getUsersByEmail({ 'email': emailid })
                    .then(function (user) {

                        if (user.length) {
                            user = user[0];
                            if ((user.security_question == security_question) && (user.security_answer == security_answer)) {
                                response.message = 'Change Password successfully!';
                                res.rest.success(response);
                            }
                            else {
                                response.message = 'Securtity Details are Invalid!';
                                res.rest.success(response);
                            }

                        } else {
                            res.rest.success(response);
                        }
                    })
                    .catch(function (err) {
                        res.rest.serverError(err.message);
                        return next();
                    });
            }
            else {
                response.message = 'Invalid Inputs';
                res.rest.success(response);
            }

        },
        saveUserContacts: function (req, res, next) {
            // authHandler(req, res, next, function () {

            let conditions = {};
            userModel.saveUserContacts(conditions, req.body)
                .then(function (quesitons) {
                    res.rest.success({
                        'data': {},
                        'message': 'Contact added successfully!'
                    });
                })
                .catch(function (err) {
                    res.rest.serverError({
                        'message': 'Error : Contact are  not found! ' + err.message
                    });
                });


            //});

        },
        getContactList: function (req, res, next) {
            // authHandler(req, res, next, function () {
            // let conditions = {};
            let conditions = { 'user_id': objectId(req.body.user_id) };
            if (req.body.type && req.body.type == 'citizen') {
                conditions['contacts.type'] = 'leo';
                // conditions.type = 'leo';
            }
            // let conditions = {$or:[ {'user_id':objectId(req.body.user_id)}, {'contact_id':objectId(req.body.user_id)} ]};
            userModel.getUserscontacts(conditions)
                .then(function (Users) {
                    res.rest.success({
                        'data': Users,
                        'message': 'Users list!'
                    });
                })
                .catch(function (err) {
                    res.rest.serverError({
                        'message': 'Error : Securtity questions not found! ' + err.message
                    });
                });

            // });
        },
        removeContact: function (req, res, next) {
            // authHandler(req, res, next, function () {
            let conditions = {
                'user_id': objectId(req.body.user_id),
                'contact_id': objectId(req.body.contact_id)

            };
            // let conditions = {$or:[ {'user_id':objectId(req.body.user_id)}, {'contact_id':objectId(req.body.user_id)} ]};
            userModel.deleteContacts(conditions, req.body)
                .then(function (users) {
                    res.rest.success({
                        'data': {},
                        'message': 'Contact removed successfully!'
                    });
                })
                .catch(function (err) {
                    res.rest.serverError({
                        'message': 'Error : Contact could not be removed! ' + err.message
                    });
                });

            // });
        },

        edit: function (req, res, next) {
            // authHandler(req, res, next, function () {
            userModel.update({ '_id': objectId(req.body.id) }, req.body)
                .then(function (users) {
                    res.rest.success({
                        'data': users,
                        'message': 'User updated successfully!'
                    });
                })
                .catch(function (err) {
                    res.rest.serverError({
                        'message': 'Error : User could not be updated! ' + err.message
                    });
                });
            //});
        },
        delete: function (req, res, next) {
            //  authHandler(req, res, next, function () {
            userModel.delete({ '_id': req.body.id }, req.body)
                .then(function (users) {
                    res.rest.success({
                        'data': users,
                        'message': 'User Delete successfully!'
                    });
                })
                .catch(function (err) {
                    res.rest.serverError({
                        'message': 'Error : User could not be Delete! ' + err.message
                    });
                });

            //});
        },
        leoListOfPar: function (req, res, next) {

            // authHandler(req, res, next, function () {
            let conditions = {
                'par_id': req.body.par_id,
                '_id': { $ne: objectId(req.body.user_id) }

            };

            userModel.getUsers(conditions)
                .then(function (Users) {
                    res.rest.success({
                        'data': Users,
                        'message': 'leo list!'
                    });
                })
                .catch(function (err) {
                    res.rest.serverError({
                        'message': 'Error : Leo not found! ' + err.message
                    });
                });

            // });
        },
        getById: function (req, res, next) {
            
            let conditions = {'_id':objectId(req.body.id)};
            userModel.getUsersByEmail(conditions)
                .then(function (users) {
                    res.rest.success({
                        'data': users,
                        'message': 'Users list'
                    });
                })
                .catch(function (err) {
                    res.rest.serverError({
                        'message': 'Error : Securtity questions not found! ' + err.message
                    });
                });
        },
        updateDeviceInfo: function (req, res, next) {
            // authHandler(req, res, next, function () {
            userModel.update({ '_id': objectId(req.body.id) }, req.body)
                .then(function (users) {
                    res.rest.success({
                        'data': users,
                        'message': 'User updated successfully!'
                    });
                })
                .catch(function (err) {
                    res.rest.serverError({
                        'message': 'Error : User could not be updated! ' + err.message
                    });
                });
            //});
        },

    },
    get: {
        logout: function (req, res, next) {
            // if header token is matches the session token then destroy the session
            //if (req.session.token === extractToken(req)) {
            req.session.destroy(function (err) {
                if (err) {
                    res.rest.serverError(err.message);
                } else {
                    res.rest.success('Logged out successfully!');
                }
            });
            // } else {
            //     res.rest.unauthorized('You are not authorized to perform this action.');
            // }
        },
        getSecurityQuestions: function (req, res, next) {

            // authHandler(req, res, next, function () {

            let conditions = {};
            securityQuestionModel.getSecurityQuestion(conditions)
                .then(function (quesitons) {
                    res.rest.success({
                        'data': quesitons,
                        'message': 'Securtity questions!'
                    });
                })
                .catch(function (err) {
                    res.rest.serverError({
                        'message': 'Error : Securtity questions not found! ' + err.message
                    });
                });


            //});

        },
        list: function (req, res, next) {
            // authHandler(req, res, next, function () {
            let conditions = { 'status': 1 };

            userModel.getUsers(conditions)
                .then(function (Users) {
                    res.rest.success({
                        'data': Users,
                        'message': 'Users list'
                    });
                })
                .catch(function (err) {
                    res.rest.serverError({
                        'message': 'Error : Securtity questions not found! ' + err.message
                    });
                });

            // });
        },

        pushTest1: function(){
            notificationsService.sendPushNotificationIOS('318b211f43226f2f27c66895f3a7a285da1d8705d03127fd4790c487a4ba113e', 'test', 'abc');
        },
        pushTest2: function(){
            notificationsService.sendPushNotificationIOS('318b211f43226f2f27c66895f3a7a285da1d8705d03127fd4790c487a4ba113e', 'test1', 'abc1');
        }

        // test1: function (req, res, next) {
        //     notificationsService.sendPushNotificationAndroid("fTAzOheIHV4:APA91bE-Zpd2kYe2fvBg8_KZdgszkDU8wjPz2u61Ohu93l1MM1EVdWXx0zDevrRJmY18G_6w5_fXQyGsueWd51B29znst2hUlg1NjUmz-qGcAl9r8P5Ja7PrtU0pTHTyegdpc7o-6OoGkwNyotStSv7mZfEHiOK0tg", "test", "this is test message", {})
        //         .then(function (response) {
        //             console.log(response);
        //         })
        //         .catch(function (err) {
        //             console.log(err);
        //         });
        // }
    }
}