const thisModel = require('../db/models/ChatMessageModel');
var nodemailer = require('nodemailer');
objectId = require('mongoose').Types.ObjectId;

module.exports = {
    name: 'chat_message',
    post: {
        updateReadStatus: function (req, res, next) {
            let conditions = { receiverId: objectId(req.body.user_id), senderId: objectId(req.body.other_user_id) };
            thisModel.updateReadStatus(conditions, { read: 1 }, true)
                .then(function (data) {
                    console.log(data);
                    res.rest.success({
                        'data': data,
                        'message': 'successfully!'
                    });
                })
                .catch(function (err) {
                    console.log(err);
                    res.rest.serverError({
                        'message': 'Error : Conference could not be Saved! '
                    });
                });
        },
        updateLocalPathAttachment: function (req, res, next) {
            let userId = {};
            userId["localPath." + req.body.user_id] = req.body.path;
            let conditions = { _id: objectId(req.body.id) };
            thisModel.updateLocalPathAttachment(conditions, userId)
                .then(function (data) {

                })
                .catch(function (err) {
                    console.log(err);
                });
        }
        // push: function (req, res, next) {
        //     var options = {
        //         token: {
        //             key: process.env.APN_CERT || __dirname + '/certs/AuthKey_X8U2LHJ587.p8',
        //             keyId: "X8U2LHJ587",
        //             teamId: "N6U4NJ84FG"
        //         },
        //         production: false
        //     };
        //     var apnProvider = new apn.Provider(options);

        //     let deviceToken = "da56cba94ed03595b3a52b599dc30b5d32b164ff8b7e7ce4813fbaecee937358";
        //     var note = new apn.Notification();

        //     note.expiry = Math.floor(Date.now() / 1000) + 3600; // Expires 1 hour from now.
        //     note.badge = 3;
        //     note.sound = "ping.aiff";
        //     note.alert = "\uD83D\uDCE7 \u2709 You have a new message";
        //     note.payload = { 'messageFrom': 'John Appleseed' };
        //     note.topic = "Com.Telecare.TWA";

        //     apnProvider.send(note, deviceToken).then((result) => {
        //         // see documentation for an explanation of result
        //     });

        // }
    }
}