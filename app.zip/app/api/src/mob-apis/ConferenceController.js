
const authHandler = require('../handlers/AuthHandler'),
    ConferenceModel = require('../db/models/ConferenceModel'),
    objectId = require('mongoose').Types.ObjectId;
module.exports = {
    name: 'conference',
    post: {
        add: function (req, res, next) {
            // authHandler(req, res, next, function () {
            const reqData = req.body;
            if (reqData.user_id && reqData.subject && reqData.start_time && reqData.end_time && reqData.participants && reqData.participants.length) {
                const data = {
                    subject: reqData.subject,
                    start_time: reqData.start_time,
                    end_time: reqData.end_time,
                    participants: reqData.participants
                };
                ConferenceModel.save(data)
                    .then(function (response) {
                        res.rest.success({
                            'data': response,
                            'message': 'Conference saved successfully!'
                        });
                    })
                    .catch(function (err) {
                        res.rest.serverError({
                            'message': 'Error : Conference could not be Saved! ' + err.message
                        });
                    });
            } else {
                res.rest.serverError({
                    'message': 'Please provide all the fields to create a conference'
                });
            }
            // });
        },

        delete: function (req, res, next) {
            //  authHandler(req, res, next, function () {
            ConferenceModel.delete({ '_id': req.body.id }, req.body)
                .then(function (users) {
                    res.rest.success({
                        'data': users,
                        'message': 'Conference deleted successfully!'
                    });
                })
                .catch(function (err) {
                    res.rest.serverError({
                        'message': 'Error : Conference could not be deleted! ' + err.message
                    });
                });
            //});
        }
    },
    get: {
        list: function (req, res, next) {
            // authHandler(req, res, next, function () {
            let conditions = {};
            if (req.query.user_id) {
                conditions.user_id = objectId(req.query.user_id);
            }
            ConferenceModel.list(conditions)
                .then(function (conferences) {
                    res.rest.success({
                        'data': conferences,
                        'message': 'Conferences'
                    });
                })
                .catch(function (err) {
                    res.rest.serverError({
                        'message': 'Error : No data found! ' + err.message
                    });
                });
            // });
        }
    }
}
