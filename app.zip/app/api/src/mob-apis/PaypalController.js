const config = require('../../config'),
    authHandler = require('../handlers/AuthHandler'),
    paypalConfig = require('../../config'),
    host = config.isDev === true ? 'http://localhost:3005/' : 'https://twaapi.herokuapp.com/',
    paypalUrl = host + 'api/v1.0/paypal/',
    url = require('url');
module.exports = {
    name: 'paypal',
    get: {
        checkout: function (req, res, next) {
            const response = JSON.stringify({ "title": "Paypal Checkout" });
            res.render('checkout', { url: paypalUrl, response: response });
        },
        cancel: function (req, res, next) {
            const response = JSON.stringify({ "status": "cancel", "message": "You cancelled the transaction" });
            res.render('cancel', { url: paypalUrl, response: response });
        },
        processAgreement: function (req, res, next) {
            var token = req.query.token,
                paypal = req.paypal;
            // console.log(token, 'tokentoken');
            paypal.billingAgreement.execute(token, {}, function (error, billingAgreement) {
                if (error) {
                    const response = JSON.stringify({ "status": "error", "message": "error occurred", "data": error });
                    res.render('error', { url: paypalUrl, response: response });
                } else {
                    const response = JSON.stringify({ "status": "success", "message": "Payment successful", "data": billingAgreement });
                    res.render('success', { url: paypalUrl, response: response });
                }
            });
        }
    },
    post: {
        createAgreement: function (req, res, next) {
            // var d = new Date(Date.now() + 1 * 60 * 1000),
            var d = new Date(),
                paypal = req.paypal;
            // d.setSeconds(d.getSeconds() + 4);
            d.setMonth(d.getMonth() + 1);
            var isDate = d.toISOString(),
                isoDate = isDate.slice(0, 19) + 'Z',
                billingPlanAttributes = {
                    "name": "twa-registration",
                    "description": "TWA Signup Subscription",
                    "merchant_preferences": {
                        "auto_bill_amount": "yes",
                        "cancel_url": paypalUrl + 'cancel',
                        "initial_fail_amount_action": "continue",
                        "max_fail_attempts": "2",
                        "return_url": paypalUrl + 'processAgreement',
                        // "setup_fee": {
                        //     "currency": "USD",
                        //     "value": "25"
                        // }
                    },
                    "payment_definitions": [
                        {
                            "amount": {
                                "currency": "USD",
                                "value": "1"
                            },
                            // "charge_models": [
                            //     {
                            //         "amount": {
                            //             "currency": "USD",
                            //             "value": "10.60"
                            //         },
                            //         "type": "SHIPPING"
                            //     },
                            //     {
                            //         "amount": {
                            //             "currency": "USD",
                            //             "value": "20"
                            //         },
                            //         "type": "TAX"
                            //     }
                            // ],
                            "cycles": "0",
                            "frequency": "MONTH",
                            "frequency_interval": "1",
                            "name": "Regular Fee Cycle",
                            "type": "REGULAR"
                        },
                        // {
                        //     "amount": {
                        //         "currency": "USD",
                        //         "value": "20"
                        //     },
                        //     "charge_models": [
                        //         {
                        //             "amount": {
                        //                 "currency": "USD",
                        //                 "value": "10.60"
                        //             },
                        //             "type": "SHIPPING"
                        //         },
                        //         {
                        //             "amount": {
                        //                 "currency": "USD",
                        //                 "value": "20"
                        //             },
                        //             "type": "TAX"
                        //         }
                        //     ],
                        //     "cycles": "4",
                        //     "frequency": "MONTH",
                        //     "frequency_interval": "1",
                        //     "name": "Trial 1",
                        //     "type": "TRIAL"
                        // }
                    ],
                    "type": "INFINITE"
                };

            var billingPlanUpdateAttributes = [
                {
                    "op": "replace",
                    "path": "/",
                    "value": {
                        "state": "ACTIVE"
                    }
                }
            ];

            var billingAgreementAttributes = {
                "name": "Signup Fee Agreement",
                "description": "Agreement for Signup Fee",
                "start_date": isoDate,
                "plan": {
                    // "id": "P-0NJ10521L3680291SOAQIVTQ"
                    "id": "P-DS9G78DSDLKFD9FDLDF9JF9D"
                },
                "payer": {
                    "payment_method": "paypal"
                },
                "shipping_address": {
                    "line1": "StayBr111idge Suites",
                    "line2": "Cro12ok Street",
                    "city": "San Jose",
                    "state": "CA",
                    "postal_code": "95112",
                    "country_code": "US"
                }
            };

            // Create the billing plan
            paypal.billingPlan.create(billingPlanAttributes, function (error, billingPlan) {
                if (error) {
                    const response = JSON.stringify({ "status": "error", "message": "error occurred", "data": error });
                    res.render('error', { url: paypalUrl, response: response });
                } else {
                    // console.log("Create Billing Plan Response");
                    // console.log(billingPlan);
                    // Activate the plan by changing status to Active
                    paypal.billingPlan.update(billingPlan.id, billingPlanUpdateAttributes, function (error, response) {
                        if (error) {
                            const response = JSON.stringify({ "status": "error", "message": "error occurred", "data": error });
                            res.render('error', { url: paypalUrl, response: response });
                        } else {
                            // console.log("Billing Plan state changed to " + billingPlan.state);
                            billingAgreementAttributes.plan.id = billingPlan.id;
                            // Use activated billing plan to create agreement
                            paypal.billingAgreement.create(billingAgreementAttributes, function (error, billingAgreement) {
                                if (error) {
                                    const response = JSON.stringify({ "status": "error", "message": "error occurred", "data": error });
                                    res.render('error', { url: paypalUrl, response: response });
                                } else {
                                    // console.log("Create Billing Agreement Response");
                                    //console.log(billingAgreement);
                                    for (var index = 0; index < billingAgreement.links.length; index++) {
                                        if (billingAgreement.links[index].rel === 'approval_url') {
                                            var approval_url = billingAgreement.links[index].href;
                                            // console.log("For approving subscription via Paypal, first redirect user to");
                                            // console.log(approval_url);
                                            res.redirect(approval_url);
                                            // console.log("Payment token is");
                                            // console.log(url.parse(approval_url, true).query.token);
                                            // See billing_agreements/execute.js to see example for executing agreement
                                            // after you have payment token
                                        }
                                    }
                                }
                            });
                        }
                    });
                }
            });
        }
    }
}
