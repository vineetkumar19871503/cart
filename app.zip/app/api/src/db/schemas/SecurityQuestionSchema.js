const mongoose = require('mongoose'),
    Schema = mongoose.Schema;

//defining schemas
const schemas = {
    security_question: new Schema({
        question: String
    })
};

//creating models for collections
const models = {
    securityQuestionModel: mongoose.model('security_questions', schemas.security_question)
}

module.exports = {
    schemas,
    models
};