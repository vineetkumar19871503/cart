const mongoose = require('mongoose'),
    Schema = mongoose.Schema;

//defining schemas
const schemas = {
    audios: new Schema({
        user_id: { type: Schema.Types.ObjectId, required: true },
        filename: { type: String },
        displayname: { type: String },
        audio_msg:{ type: String },
        status:{ type: Number, default: 0 },
    }),
    sent_audios: new Schema({
        sender_id: { type: Schema.Types.ObjectId, required: true },
        receiver_id: { type: Schema.Types.ObjectId, required: true },
        audio_id: { type: Schema.Types.ObjectId, required: true },
        time: { type: Date, default: Date.now }
    })
};


//creating models for collections
const models = {
    AudioModel: mongoose.model('audios', schemas.audios),
    SentAudioModel: mongoose.model('sent_audios', schemas.sent_audios),
}

module.exports = {
    schemas,
    models
};