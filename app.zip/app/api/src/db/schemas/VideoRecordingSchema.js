const mongoose = require('mongoose'),
    Schema = mongoose.Schema;

//defining schemas
const schemas = {
    video_recordings: new Schema({
        user_id: { type: Schema.Types.ObjectId, required: true },
        filename: { type: String },
        time: { type: Date, default: Date.now }
    })
};

//creating models for collections
const models = {
    VideoRecordingModel: mongoose.model('video_recordings', schemas.video_recordings),
}

module.exports = {
    schemas,
    models
};