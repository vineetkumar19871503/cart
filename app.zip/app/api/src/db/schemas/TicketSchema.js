const mongoose = require('mongoose'),
    Schema = mongoose.Schema;

//defining schemas
const schemas = {
    tickets: new Schema({
      lastName: { type: String },
      firstName: { type: String },
      mi: { type: String },
      aptNo: { type: String },
      phoneLicShown: { type: String },
      city: { type: String },
      state: { type: String },
      zipCode: { type: String },
      ownerOper: { type: String },
      licClass: { type: String },
      licState: { type: String },
      dateOfBirth: { type: Date },
    //   dateOfBirthPicValue: false,
      vehType: { type: String },
      year: { type: String },
      make: { type: String },
      color: { type: String },
      plateNo: { type: String },
      regState: { type: String },
      regExpires: { type: Date },
    //   regExpiresPicValue: false,
      time: { type: String },
    //   timePicValue: false,
      dateOfOffense: { type: Date },
    //   dateOfOffensePicValue: false,
      inViolationOf: { type: String },
      subSection: { type: String },
      trInf: { type: String },
      mph: { type: String },
      mphZone: { type: String },
      descOfViolance: { type: String },
      cdlVeh: { type: String },
      placeOfOccurance: { type: String },
      hwyNo: { type: String },
      locCode: { type: String },
      ctvName: { type: String },
      country: { type: String },
      hwyType: { type: String },
      nciciori: { type: String },
      dateAffileted: { type: Date },
    //   dateAffiletedPicValue: false,
      file: { type: String },
      onAssign: { type: String },
      arrestType: { type: String },
      badged: { type: String },
      lastName1: { type: String },
      address1: { type: String },
      city1: { type: String },
      state1: { type: String },
      zip1: { type: String },
      date1: { type: Date },
    //   date1PicValue: false,
      time1: { type: String },
    //   time1PicValue: false,
      returnWay: { type: String },
    })
};


//creating models for collections
const models = {
    TicketModel: mongoose.model('tickets', schemas.tickets),
}

module.exports = {
    schemas,
    models
};