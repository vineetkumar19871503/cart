const config = require('../../../config'),
    mongoose = require('mongoose'),
    Schema = mongoose.Schema;

//defining schemas
const schemas = {
    vmails: new Schema({
        sender_id: { type: Schema.Types.ObjectId, required: true },
        receiver_id: { type: Schema.Types.ObjectId, required: true },
        subject: String,
        attachment: String,
        message: String,
        location: {
            address: String,
            coords: {
                lat: Number,
                lng: Number
            }
        },
        doc: { type: Date, default: Date.now }
    })
};


//creating models for collections
const models = {
    VmailModel: mongoose.model('vmails', schemas.vmails),
}

module.exports = {
    schemas,
    models
};