const config = require('../../../config'),
    mongoose = require('mongoose'),
    Schema = mongoose.Schema;

//defining schemas
const schemas = {
    users: new Schema({
        role_id: {
            type: Schema.Types.ObjectId,
            ref: 'roles',
        },
        billing_info: String,
        billing_successful: { type: Boolean, default: false },
        payment: [{
            payment_info: String
        }],
        name: { type: String, required: true },
        fname: { type: String },
        lname: { type: String },
        type: { type: String },
        status: { type: Number, default: 0 },
        email: { type: String, required: true, match: /\S+@\S+\.\S+/ },
        password: { type: String, required: true, minlength: 6 },
        dob: { type: Date, default: Date.now },
        security_question: { type: String, },
        security_answer: { type: String, },
        memberId: { type: String },
        address: { type: String },
        par_title: { type: String },
        office_name: { type: String },
        phone: { type: String },
        fax: { type: String },
        license_number: { type: String },
        country: { type: String },
        state: { type: String },
        par_limit: { type: Number, default: 0 },
        parstatus: { type: String, default: 'Pending' },
        badgeno: { type: String },
        precinct: { type: String },
        rank: { type: String },
        private_code: { type: String },
        filename: { type: String },
        par_id: String,
        deviceInfo:{token:String, os:String}

    }),
    roles: new Schema({
        _id: Schema.Types.ObjectId,
        name: String,
        alias: String,
        permissions: [{
            permission_module_id: {
                type: Schema.Types.ObjectId,
                ref: 'permission_modules'
            },
            add: Number,
            edit: Number,
            view: Number,
            delete: Number
        }]

    }),
    permission_modules: new Schema({
        name: String
    }),
    user_contacts: new Schema({
        user_id: { type: Schema.Types.ObjectId, required: true },
        contact_id: { type: Schema.Types.ObjectId, required: true }
    }),
};


//creating models for collections
const models = {
    roleModel: mongoose.model('roles', schemas.roles),
    userModel: mongoose.model('users', schemas.users),
    permissionModuleModel: mongoose.model('permission_modules', schemas.permission_modules),
    userContactsModel: mongoose.model('user_contacts', schemas.user_contacts),
}

module.exports = {
    schemas,
    models
};