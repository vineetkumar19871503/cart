const mongoose = require('mongoose'),
    Schema = mongoose.Schema;

//defining schemas
const schemas = {
    conferences: new Schema({
        subject: String,
        start_time: Date,
        end_time: Date,
        participants: [{
            user_id: { type: Schema.Types.ObjectId }
        }]
    })
};

//creating models for collections
const models = {
    ConferenceModel: mongoose.model('conferences', schemas.conferences),
}

module.exports = {
    schemas,
    models
};