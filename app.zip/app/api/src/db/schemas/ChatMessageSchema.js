const config = require('../../../config'),
    mongoose = require('mongoose'),
    Schema = mongoose.Schema;

//defining schemas
const schemas = {
    chat_messages: new Schema({
        roomId: { type: String, required: true },
        senderId: {
            type: Schema.Types.ObjectId,
            // ref: 'users',
        },
        receiverId: {
            type: Schema.Types.ObjectId,
            // ref: 'users',
        },
        message: { type: String },
        read: { type: Number, default: 0 },
        senderEmail: { type: String },
        receiverEmail: { type: String },
        type: { type: String },
        time: { type: Date },
        localPath: {},
    })
};


//creating models for collections
const models = {
    ChatMessageModel: mongoose.model('chat_messages', schemas.chat_messages),
}

module.exports = {
    schemas,
    models
};