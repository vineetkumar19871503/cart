const thisSchema = require('../../db/schemas/TicketSchema'),
    thisModel = thisSchema.models.TicketModel;

module.exports = {

    saveValue: function (data) {
        var data = new thisModel(data);
        return new Promise(function (resolve, reject) {
            data.save(function (err, val) {
                err ? reject(err) : resolve(val);
            });
        });
    },
}