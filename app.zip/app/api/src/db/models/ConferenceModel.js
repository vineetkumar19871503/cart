const conferenceSchema = require('../schemas/ConferenceSchema'),
    conferenceModel = conferenceSchema.models.ConferenceModel;

module.exports = {
    list: function (conditions = {}, fields = {}) {
        return new Promise(function (resolve, reject) {
            var query = conferenceModel.find(conditions);
            if (Object.keys(fields).length) {
                query.select(fields);
            }
            query.exec(function (err, question) {
                err ? reject(err) : resolve(question);
            });
        });
    },
    save: function (data) {
        var newConference = new conferenceModel(data);
        return new Promise(function (resolve, reject) {
            newConference.save(function (err, res) {
                err ? reject(err) : resolve(res);
            });
        });
    },
    delete: function (conditions) {
        return new Promise(function (resolve, reject) {
            conferenceModel.remove(conditions, function (err) {
                err ? reject(err) : resolve();
            });
        });
    }
}
