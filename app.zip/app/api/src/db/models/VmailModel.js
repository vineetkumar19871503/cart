const bcrypt = require('bcrypt'),
    config = require('../../../config'),
    vmailSchema = require('../../db/schemas/VmailSchema'),
    vmailModel = vmailSchema.models.VmailModel;
   
module.exports = {
 
    getvmailList: function (conditions ={}, fields = {})
    {
       
        return new Promise(function (resolve, reject) {
            var query = vmailModel.find(conditions);
            if (Object.keys(fields).length) {
                query.select(fields);
            }
            query.exec(function (err, question) {
                err ? reject(err) : resolve(question);
            });
        });
    },
    
     getvmailListSenderDetails: function (conditions ={}, fields = {})
    {
       
        const self = this;
        return new Promise(function (resolve, reject) {
            var query = [
               
                {
                    $lookup: {
                        from: 'users',
                        localField: 'sender_id',
                        foreignField: '_id',
                        as: 'sender'
                    }
                },
                { $unwind: '$sender' },
                {
                    $lookup: {
                        from: 'users',
                        localField: 'receiver_id',
                        foreignField: '_id',
                        as: 'receiver'
                    }
                },
                { $unwind: '$receiver' },
                { $match: conditions }
            ];
            vmailModel.aggregate(query)
                .exec(function (err, users) {
                    err ? reject(err) : resolve(users);
                }); 
        });
    },
  
    saveMessage: function (data) {
        return new Promise(function (resolve, reject) {
            vmailModel.insertMany(data, function (err, user) {
                err ? reject(err) : resolve(user);
            });
        });
    },
   
    getvmailDetail: function (conditions ={}, fields = {})
    {
       
        const self = this;
        return new Promise(function (resolve, reject) {
            var query = [
               
                {
                    $lookup: {
                        from: 'users',
                        localField: 'sender_id',
                        foreignField: '_id',
                        as: 'sender'
                    }
                },
                { $unwind: '$sender' },
                {
                    $lookup: {
                        from: 'users',
                        localField: 'receiver_id',
                        foreignField: '_id',
                        as: 'receiver'
                    }
                },
                { $unwind: '$receiver' },
                { $match: conditions }
            ];
            vmailModel.aggregate(query)
                .exec(function (err, users) {
                    err ? reject(err) : resolve(users);
                }); 
        });
    },
    // update: function (conditions, data, upsert = false) {
    //     return new Promise(function (resolve, reject) {
    //         userModel.update(conditions,
    //             { $set: data },
    //             { upsert },
    //             function (err, res) {
    //                 err ? reject(err) : resolve(res);
    //             })
    //     });
    // },
   
    
    delete: function (conditions) {
        return new Promise(function (resolve, reject) {
            audioModel.remove(conditions, function (err) {
                err ? reject(err) : resolve();
            });
        });  
    },
  
 
 
}