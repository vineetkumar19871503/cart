const bcrypt = require('bcrypt'),
    config = require('../../../config'),
    thisSchema = require('../../db/schemas/ChatMessageSchema'),
    thisModel = thisSchema.models.ChatMessageModel;

module.exports = {

    getAllValues: function (conditions = {}, order = {}, fields = {}) {
        console.log('getAllValuesgetAllValuesgetAllValuesgetAllValues');
        return new Promise(function (resolve, reject) {
            var query = thisModel.find(conditions);
            if (Object.keys(fields).length) {
                query.select(fields);
            }
            if (Object.keys(order).length) {
                query.sort(order);
            }

            query.exec(function (err, data) {

                err ? reject(err) : resolve(data);
            });
        });
    },
    saveValue: function (data) {
        var data = new thisModel(data);
        // newUser.password = bcrypt.hashSync(data.password, config.bcryptSalt);
        return new Promise(function (resolve, reject) {
            data.save(function (err, val) {
                err ? reject(err) : resolve(val);
            });
        });
    },
    updateReadStatus: function (conditions, data, multi = false) {
        return new Promise(function (resolve, reject) {
            thisModel.update(conditions,
                { $set: data },
                { multi: multi },
                function (err, res) {
                    err ? reject(err) : resolve(res);
                })
        });
    },
    updateLocalPathAttachment: function (conditions, data, multi = false) {
        return new Promise(function (resolve, reject) {
            thisModel.update(conditions,
                { $set: data },
                { multi: multi },
                function (err, res) {
                    err ? reject(err) : resolve(res);
                })
        });
    },


}