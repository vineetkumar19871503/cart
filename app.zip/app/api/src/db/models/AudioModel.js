const audioSchema = require('../../db/schemas/AudioSchema'),
    audioModel = audioSchema.models.AudioModel,
    sentAudioModel = audioSchema.models.SentAudioModel;

module.exports = {
    getAudiosList: function (conditions = {}, fields = {}) {
        return new Promise(function (resolve, reject) {
            var query = audioModel.find(conditions);
            if (Object.keys(fields).length) {
                query.select(fields);
            }
            query.exec(function (err, question) {

                err ? reject(err) : resolve(question);
            });
        });
    },
    saveAudio: function (data) {
        var newUser = new audioModel(data);
        return new Promise(function (resolve, reject) {
            newUser.save(function (err, user) {
                err ? reject(err) : resolve(user);
            });
        });
    },
    // update: function (conditions, data, upsert = false) {
    //     return new Promise(function (resolve, reject) {
    //         userModel.update(conditions,
    //             { $set: data },
    //             { upsert },
    //             function (err, res) {
    //                 err ? reject(err) : resolve(res);
    //             })
    //     });
    // },
    delete: function (conditions) {
        return new Promise(function (resolve, reject) {
            audioModel.remove(conditions, function (err) {
                err ? reject(err) : resolve();
            });
        });
    },
    deleteMany: function (conditions) {
        return new Promise(function (resolve, reject) {
            audioModel.deleteMany(conditions, function (err) {
                err ? reject(err) : resolve();
            });
        });
    },
    updateStatus: function (conditions, data, upsert = false) {
        return new Promise(function (resolve, reject) {
            audioModel.update(conditions,
                { $set: data },
                { upsert },
                function (err, res) {
                    err ? reject(err) : resolve(res);
                })
        });
    },


    // sending recorded audio methods
    saveSentAudio: function (data) {
        var newData = new sentAudioModel(data);
        return new Promise(function (resolve, reject) {
            newData.save(function (err, response) {
                err ? reject(err) : resolve(response);
            });
        });
    },
}