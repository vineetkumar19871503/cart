const
    videoRecordingSchema = require('../schemas/VideoRecordingSchema'),
    videoRecordingModel = videoRecordingSchema.models.VideoRecordingModel;

module.exports = {
    list: function (conditions = {}, fields = {}) {
        return new Promise(function (resolve, reject) {
            var query = videoRecordingModel.find(conditions);
            if (Object.keys(fields).length) {
                query.select(fields);
            }
            query.exec(function (err, question) {
                err ? reject(err) : resolve(question);
            });
        });
    },
    save: function (data) {
        var newRecording = new videoRecordingModel(data);
        return new Promise(function (resolve, reject) {
            newRecording.save(function (err, res) {
                err ? reject(err) : resolve(res);
            });
        });
    },
    delete: function (conditions) {
        return new Promise(function (resolve, reject) {
            videoRecordingModel.remove(conditions, function (err) {
                err ? reject(err) : resolve();
            });
        });
    },
    getvideoRecordingSenderDetails: function (conditions ={}, fields = {})
    {
       
        const self = this;
        return new Promise(function (resolve, reject) {
            var query = [
               
                {
                    $lookup: {
                        from: 'users',
                        localField: 'user_id',
                        foreignField: '_id',
                        as: 'sender'
                    }
                },
                { $unwind: '$sender' },
                { $match: conditions }
            ];
            videoRecordingModel.aggregate(query)
                .exec(function (err, users) {
                    err ? reject(err) : resolve(users);
                }); 
        });
    },
}
