const apn = require('apn'),
    https = require('https'),
    isProd = process.env.NODE_ENV && process.env.NODE_ENV == 'production',
    request = require('request'),
    conf = {
        "android": {
            "host": "fcm.googleapis.com",
            "path": "/fcm/send",
            "url": "https://fcm.googleapis.com/fcm/send",
            "server_key": "key=AAAACFPbAdU:APA91bEatsZdeIhrZwn893ODKirxfXAsdYJxF-Dw22OGbxgfjYdywsR_Z66GyxBMqt2tkAhXBHvM02ytcVsmpZLiX-PtOJtidh3WLqqvjcCZWzFpN-56Kx7pkf4XENnskO-ljXGjrrYD5We4Ks-EwBHjjavE8sPxCQ"
        },
        "ios": {
            "dev": {
                "key": process.env.APN_CERT || __dirname + '/certs/AuthKey_X8U2LHJ587.p8',
                "keyId": "X8U2LHJ587",
                "teamId": "N6U4NJ84FG"
            },
            "prod": {
                "key": process.env.APN_CERT || __dirname + '/certs/AuthKey_X8U2LHJ587.p8',
                "keyId": "V6TF3888KP",
                "teamId": "N6U4NJ84FG"
            }
        }
    }
module.exports = {
    sendPushNotificationIOS: function (to, title, body, data, collapseId) {
        return new Promise(function (resolve, reject) {
            var options = {
                token: isProd ? conf.ios.prod : conf.ios.dev,
                production: true
            },
                apnProvider = new apn.Provider(options),
                deviceToken = to,
                note = new apn.Notification();

            //if we want to update the notification then use collapse id
            if (collapseId) {
                note.collapseId = collapseId;
            }
            note.expiry = Math.floor(Date.now() / 1000) + 3600; // Expires 1 hour from now.
            note.badge = '';
            note.sound = "ping.aiff";
            note.alert = "\uD83D\uDCE7 " + body;
            note.payload = data;
            note.topic = "Com.Telecare.TWA";
            apnProvider.send(note, to)
                .then((result) => {
                    resolve(result);
                })
                .catch(function (err) {
                    reject(err);
                });
        });
    },
    sendPushNotificationAndroid: function (to, title, body, data, tag) {
        return new Promise(function (resolve, reject) {
            var postData = {
                "to": to,
                "notification": {
                    "sound": "default",
                    "title": title,
                    "body": body
                },
                "data": { "data": data }
            };
            if (tag) {
                postData.notification.tag = tag;
            }
            request.post({
                url: conf.android.url,
                body: postData,
                json: true,
                headers: {
                    'Content-Type': 'application/json; charset=UTF-8',
                    "Authorization": conf.android.server_key
                }
            }, function (error, response, body) {
                if (!error && response.statusCode == 200) {
                    resolve(body);
                } else {
                    reject('error')
                }
            });
        });
    }
}