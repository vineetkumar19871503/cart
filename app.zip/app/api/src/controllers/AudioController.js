const bcrypt = require('bcrypt'),
    authHandler = require('../handlers/AuthHandler'),
    generateToken = require('../auth/generateToken'),
    { extractToken } = require('../auth/authorize'),
    audioModel = require('../db/models/AudioModel');
var nodemailer = require('nodemailer');  
objectId = require('mongoose').Types.ObjectId;
var transporter = nodemailer.createTransport({
    service: 'Gmail',
    auth: {
        user: 'avinesh.mathur@a3logics.in',
        pass: 'Avinesh1233#'
    }
});

module.exports = {
    name: 'audios',
    post: {
      
        add: function (req, res, next) {
            // authHandler(req, res, next, function () {
            const datavalue = {
                "user_id": objectId(req.body.user_id),
                "filename": req.body.filename,
                "displayname": req.body.displayname,
            }

            audioModel.saveAudio(datavalue)
                .then(function (register) {
                    res.rest.success({
                        'data': register,
                        'message': 'Audio saved successfully!'
                    });
                })
                .catch(function (err) {
                    res.rest.serverError({
                        'message': 'Error : Audio could not be Saved! ' + err.message
                    });
                });
            // });
        },

        delete: function (req, res, next) {
            //  authHandler(req, res, next, function () {
            audioModel.delete({ '_id': req.body.id }, req.body)
                .then(function (users) {
                    res.rest.success({
                        'data': users,
                        'message': 'Audio Delete successfully!'
                    });
                })
                .catch(function (err) {
                    res.rest.serverError({
                        'message': 'Error : Audio could not be Delete! ' + err.message
                    });
                });

            //});
        },
        deleteMany: function (req, res, next) {
            //  authHandler(req, res, next, function () {
            audioModel.deleteMany({ '_id': { $in: req.body.id} }, req.body)
                .then(function (users) {
                    res.rest.success({
                        'data': users,
                        'message': 'Audio Delete successfully!'
                    });
                })
                .catch(function (err) {
                    res.rest.serverError({
                        'message': 'Error : Audio could not be Delete! ' + err.message
                    });
                });

            //});
        },
         updateStatus: function (req, res, next) {
            // authHandler(req, res, next, function () {
            console.log(req.body);
            audioModel.updateStatus({ '_id': req.body.id }, req.body)
                .then(function (users) {
                    res.rest.success({
                        'data': users,
                        'message': 'Audio Update successfully!'
                    });
                })
                .catch(function (err) {
                    res.rest.serverError({
                        'message': 'Error : Audio could not be Updated! ' + err.message
                    });
                });
            //});
        },
    },
    get: {
       
        list: function (req, res, next) {
            // authHandler(req, res, next, function () {

            let conditions = {};
            if (typeof req.query.status != 'undefined') {
                conditions = { 'status': req.query.status };
            }
            else
            {
             conditions = { 'status': 0 };
            }
            audioModel.getAudiosList(conditions)
                .then(function (Users) {
                    res.rest.success({
                        'data': Users,
                        'message': 'Audios list!'
                    });
                })
                .catch(function (err) {
                    res.rest.serverError({
                        'message': 'Error : Audios not found! ' + err.message
                    });
                });

            // });
        }
       

    }
}